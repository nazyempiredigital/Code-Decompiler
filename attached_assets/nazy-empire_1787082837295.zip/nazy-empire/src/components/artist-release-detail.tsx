import { useState } from "react";
import {
  X, Music, Hash, Barcode, Store, BookOpen, User, Calendar, Copy, Check,
} from "lucide-react";
import { type Release } from "@/lib/api";

const RELEASE_STATUS: Record<string, { label: string; color: string }> = {
  draft:             { label: "Draft",             color: "bg-white/10 text-white/50 border-white/10" },
  pending_review:    { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  changes_requested: { label: "Changes Requested", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  approved:          { label: "Approved",          color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  rejected:          { label: "Rejected",          color: "bg-red-500/10 text-red-400 border-red-500/20" },
  live:              { label: "Live",              color: "bg-green-500/10 text-green-400 border-green-500/20" },
};

function MetaField({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div>
      <div className="text-white/35 text-xs uppercase tracking-wider mb-1">{label}</div>
      <div className="text-white/80 text-sm">{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
      <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-4">{title}</div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-4">{children}</div>
    </div>
  );
}

function CopyField({ label, value, icon: Icon, placeholder }: { label: string; value?: string | null; icon: React.ElementType; placeholder: string }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard access denied — silently ignore, value is still visible to select/copy manually
    }
  }

  return (
    <div>
      <label className="text-white/35 text-xs uppercase tracking-wider block mb-1.5">{label}</label>
      <div className="relative">
        <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/25 pointer-events-none" />
        <input
          readOnly
          value={value ?? ""}
          placeholder={placeholder}
          onFocus={(e) => e.target.select()}
          className="w-full bg-input border border-border rounded-lg pl-9 pr-10 py-2 text-white text-sm font-mono placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {value && (
          <button
            type="button"
            onClick={copy}
            title="Copy to clipboard"
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-white/30 hover:text-white hover:bg-white/10 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>
    </div>
  );
}

interface Props {
  release: Release;
  onClose: () => void;
}

export function ArtistReleaseDetail({ release, onClose }: Props) {
  const s = RELEASE_STATUS[release.status] ?? RELEASE_STATUS.draft;
  const displayTitle = release.releaseType !== "single" && release.releaseTitle
    ? release.releaseTitle
    : release.title;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 backdrop-blur-sm px-4 py-8 overflow-y-auto" onClick={onClose}>
      <div
        className="w-full max-w-2xl bg-[#0b0b0b] border border-white/10 rounded-2xl p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-4">
          <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${s.color}`}>
            {s.label}
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hero */}
        <div className="flex gap-5">
          {release.artworkUrl ? (
            <img
              src={release.artworkUrl}
              alt={displayTitle}
              className="w-28 h-28 rounded-xl object-cover ring-1 ring-white/10 shrink-0"
            />
          ) : (
            <div className="w-28 h-28 rounded-xl bg-white/5 border border-white/8 flex items-center justify-center shrink-0">
              <Music className="w-8 h-8 text-white/20" />
            </div>
          )}
          <div className="flex-1 min-w-0 pt-1">
            <div className="flex items-start gap-2 flex-wrap">
              <h2 className="font-bold text-xl text-white leading-tight">{displayTitle}</h2>
              {release.version && (
                <span className="text-xs bg-white/8 text-white/40 px-2 py-0.5 rounded border border-white/8 self-center capitalize">
                  {release.version}
                </span>
              )}
              <span className="text-xs bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded self-center capitalize">
                {release.releaseType}
              </span>
              {release.explicitContent && (
                <span className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded self-center">E</span>
              )}
            </div>
            <div className="text-white/50 text-sm mt-1">
              {release.mainArtists}
              {release.featuredArtists ? ` ft. ${release.featuredArtists}` : ""}
            </div>
            <div className="text-white/30 text-xs mt-0.5">{release.genre} · {release.language}</div>
            <div className="flex items-center flex-wrap gap-3 mt-2.5">
              <span className="text-white/25 text-xs flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                Submitted {new Date(release.createdAt).toLocaleDateString("en-GB", {
                  day: "numeric", month: "short", year: "numeric",
                })}
              </span>
            </div>
          </div>
        </div>

        {/* Tracks (EP/Album) */}
        {release.releaseType !== "single" && release.tracks && release.tracks.length > 0 && (
          <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
            <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3">
              Tracks · {release.tracks.length}
            </div>
            <div className="space-y-2">
              {release.tracks.map((t, i) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                  <span className="text-white/25 text-xs w-5 text-right shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <span className="text-white/70 text-sm">{t.title}</span>
                    {t.version && <span className="text-white/30 text-xs ml-2">{t.version}</span>}
                    {t.explicitContent && <span className="text-xs text-red-400 ml-2">E</span>}
                  </div>
                  {t.isrc ? (
                    <span className="text-white/30 text-xs font-mono shrink-0">{t.isrc}</span>
                  ) : (
                    <span className="text-white/20 text-xs shrink-0">No ISRC</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Identifiers */}
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
          <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-4">
            Identifiers
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <CopyField label="ISRC" value={release.isrc} icon={Hash} placeholder="Not yet assigned" />
            <CopyField label="UPC / EAN" value={release.upc} icon={Barcode} placeholder="Not yet assigned" />
          </div>
        </div>

        {/* Release Info */}
        <Section title="Release Info">
          <MetaField label="Release Date" value={release.releaseDate} />
          <MetaField label="Original Release Date" value={release.originalReleaseDate} />
          <MetaField label="Copyright Date of Release" value={release.copyright} />
          <MetaField label="Copyright Date of Recording" value={release.copyrightRecordingYear} />
          <MetaField label="Publisher / Label" value={release.publisher} />
          <MetaField label="Territory" value={
            release.territory === "worldwide"
              ? "Worldwide"
              : release.selectedCountries?.length
                ? `Selected (${release.selectedCountries.length} countries)`
                : release.territory ?? "—"
          } />
          <MetaField label="Language" value={release.language} />
        </Section>

        {/* Credits */}
        <Section title="Credits">
          <MetaField label="Main Artist(s)" value={release.mainArtists} />
          <MetaField label="Featured Artist(s)" value={release.featuredArtists} />
          <MetaField label="Composer" value={release.composer} />
          <MetaField label="Songwriter" value={release.songwriter} />
          <MetaField label="Producer" value={release.producer} />
        </Section>

        {/* Platforms */}
        {release.stores && release.stores.length > 0 && (
          <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
            <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3">
              Target Platforms · {release.stores.length}
            </div>
            <div className="flex flex-wrap gap-2">
              {release.stores.map((store) => (
                <span
                  key={store}
                  className="flex items-center gap-1.5 text-xs bg-white/5 border border-white/8 text-white/55 px-3 py-1 rounded-full"
                >
                  <Store className="w-3 h-3 text-white/25" />{store}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Lyrics */}
        {release.lyrics && (
          <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
            <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3 flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5" /> Lyrics
            </div>
            <pre className="text-white/55 text-sm font-sans whitespace-pre-wrap leading-relaxed">
              {release.lyrics}
            </pre>
          </div>
        )}

        {release.adminNotes && (release.status === "changes_requested" || release.status === "rejected") && (
          <div className="p-4 bg-orange-500/10 border border-orange-500/25 rounded-xl">
            <div className="text-orange-400 text-xs uppercase tracking-widest font-semibold mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" /> Note from the team
            </div>
            <p className="text-orange-300/90 text-sm">{release.adminNotes}</p>
          </div>
        )}
      </div>
    </div>
  );
}
