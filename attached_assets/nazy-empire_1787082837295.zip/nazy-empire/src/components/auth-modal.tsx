import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/lib/auth";
import { Link, useLocation } from "wouter";

interface AuthModalProps {
  mode: "login" | "register";
  onClose: () => void;
  onSwitch: (mode: "login" | "register") => void;
}

export function AuthModal({ mode, onClose, onSwitch }: AuthModalProps) {
  const { login, register } = useAuth();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [agreed, setAgreed] = useState(false);

  const [form, setForm] = useState({
    name: "", email: "", password: "", phone: "", company: "", country: "",
  });

  function handleChange(key: string, val: string) {
    setForm((f) => ({ ...f, [key]: val }));
    setError("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (mode === "register" && !agreed) {
      setError("You must agree to the Terms of Service and Privacy Policy to continue");
      return;
    }
    setLoading(true);
    setError("");
    try {
      if (mode === "login") {
        await login(form.email, form.password);
        onClose();
        setLocation("/dashboard");
      } else {
        await register({
          name: form.name, email: form.email, password: form.password,
          phone: form.phone || undefined, company: form.company || undefined,
          country: form.country || undefined,
        });
        onClose();
        setLocation("/dashboard");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          {mode === "register" && (
            <div className="space-y-1">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name" placeholder="John Doe" value={form.name}
                onChange={(e) => handleChange("name", e.target.value)} required
              />
            </div>
          )}

          <div className="space-y-1">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email" type="email" placeholder="you@example.com" value={form.email}
              onChange={(e) => handleChange("email", e.target.value)} required
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password" type="password" placeholder="••••••••" value={form.password}
              onChange={(e) => handleChange("password", e.target.value)} required
              minLength={6}
            />
          </div>

          {mode === "register" && (
            <>
              <div className="space-y-1">
                <Label htmlFor="phone">Phone (optional)</Label>
                <Input
                  id="phone" placeholder="+234 800 000 0000" value={form.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="company">Company (optional)</Label>
                  <Input
                    id="company" placeholder="Acme Inc." value={form.company}
                    onChange={(e) => handleChange("company", e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country" placeholder="Nigeria" value={form.country}
                    onChange={(e) => handleChange("country", e.target.value)}
                  />
                </div>
              </div>
            </>
          )}

          {mode === "register" && (
            <div className="flex items-start gap-2 pt-1">
              <Checkbox
                id="modal-agree"
                checked={agreed}
                onCheckedChange={(v) => { setAgreed(v === true); setError(""); }}
                className="mt-0.5"
              />
              <Label htmlFor="modal-agree" className="text-white/60 text-xs font-normal leading-relaxed cursor-pointer">
                I agree to the{" "}
                <Link href="/terms" target="_blank" className="text-primary hover:underline">Terms of Service</Link>
                {", "}
                <Link href="/privacy" target="_blank" className="text-primary hover:underline">Privacy Policy</Link>
                {", and "}
                <Link href="/terms-of-sale" target="_blank" className="text-primary hover:underline">Terms of Sale</Link>
              </Label>
            </div>
          )}

          {error && <p className="text-destructive text-sm">{error}</p>}

          <Button
            type="submit"
            disabled={loading || (mode === "register" && !agreed)}
            className="w-full bg-primary text-black hover:bg-primary/90 font-semibold disabled:opacity-50"
          >
            {loading ? "Please wait..." : mode === "login" ? "Login" : "Create Account"}
          </Button>
        </form>

        <p className="text-center text-sm text-white/50 mt-2">
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => onSwitch(mode === "login" ? "register" : "login")}
            className="text-primary hover:underline"
          >
            {mode === "login" ? "Sign up" : "Login"}
          </button>
        </p>
      </DialogContent>
    </Dialog>
  );
}
