import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

/**
 * Catches render errors anywhere in the tree below it so a problem on one
 * page (or triggered by a browser quirk) shows a friendly fallback instead
 * of a blank screen or a crashed app shell.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Unhandled UI error:", error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-black px-4 text-center">
          <div>
            <h1 className="font-display text-3xl text-white mb-3">Something went wrong</h1>
            <p className="text-white/60 mb-6">
              This page hit a snag on your browser. Please reload, or try a different browser.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-primary text-black font-semibold rounded-md"
            >
              Reload page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
