import { useState } from "react";
import { X, Loader2 } from "lucide-react";
import { api, type ArtistPaymentRequest } from "@/lib/api";

const MIN_AMOUNT = 10_000;
const MAX_AMOUNT = 50_000_000;

interface Props {
  availableBalanceNgn: number;
  onClose: () => void;
  onCreated: (r: ArtistPaymentRequest) => void;
}

export function PaymentRequestForm({ availableBalanceNgn, onClose, onCreated }: Props) {
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) { setError("Enter a valid amount"); return; }
    if (value < MIN_AMOUNT) { setError(`Minimum withdrawal is ₦${MIN_AMOUNT.toLocaleString("en-NG")}`); return; }
    if (value > MAX_AMOUNT) { setError(`Maximum withdrawal is ₦${MAX_AMOUNT.toLocaleString("en-NG")}`); return; }
    if (value > availableBalanceNgn) { setError("Amount exceeds your available balance"); return; }

    setSubmitting(true);
    try {
      const created = await api.paymentRequests.create(value);
      onCreated(created);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit request");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 backdrop-blur-sm px-4 py-8 overflow-y-auto" onClick={onClose}>
      <form
        onSubmit={handleSubmit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#0b0b0b] border border-white/10 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">Request Payment</h2>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-white/40 text-xs">
          Available balance: <span className="text-primary font-bold">₦{availableBalanceNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </p>

        <div>
          <label className="text-white/70 text-sm font-medium block mb-1.5">Amount (₦)</label>
          <input
            type="number"
            min={MIN_AMOUNT}
            max={MAX_AMOUNT}
            step="0.01"
            required
            placeholder={`Between ₦${MIN_AMOUNT.toLocaleString("en-NG")} and ₦${MAX_AMOUNT.toLocaleString("en-NG")}`}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-input border border-border rounded-lg px-3.5 py-2.5 text-white text-sm placeholder:text-white/25 focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <p className="text-white/30 text-xs mt-1.5">Minimum ₦{MIN_AMOUNT.toLocaleString("en-NG")} · Maximum ₦{MAX_AMOUNT.toLocaleString("en-NG")}</p>
        </div>

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-border text-white/60 text-sm font-medium hover:border-white/20 transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={submitting} className="flex-1 py-2.5 rounded-lg bg-primary text-black text-sm font-bold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            Request
          </button>
        </div>
      </form>
    </div>
  );
}
