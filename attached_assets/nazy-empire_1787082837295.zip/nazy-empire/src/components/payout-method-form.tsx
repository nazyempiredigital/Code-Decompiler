import { useState } from "react";
import { X, Wallet, Building2, Loader2 } from "lucide-react";
import { api, type PayoutMethod } from "@/lib/api";

type Method = "paypal" | "bank_transfer";
type Currency = "NGN" | "USD";
type BankDetailType = "ach" | "wire" | "swift";

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="text-white/70 text-sm font-medium block mb-1.5">{children}</label>;
}

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className="w-full bg-input border border-border rounded-lg px-3.5 py-2.5 text-white text-sm placeholder:text-white/25 focus:outline-none focus:ring-2 focus:ring-primary"
    />
  );
}

function Select({ value, onChange, options, placeholder }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; placeholder?: string }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-input border border-border rounded-lg px-3.5 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary appearance-none"
    >
      {placeholder && <option value="" disabled>{placeholder}</option>}
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

interface Props {
  existing: PayoutMethod | null;
  onClose: () => void;
  onSaved: (m: PayoutMethod) => void;
}

export function PayoutMethodForm({ existing, onClose, onSaved }: Props) {
  const [method, setMethod] = useState<Method>(existing?.method ?? "paypal");
  const [currency, setCurrency] = useState<Currency>((existing?.currency as Currency) ?? "NGN");
  const [bankDetailType, setBankDetailType] = useState<BankDetailType>((existing?.bankDetailType as BankDetailType) ?? "ach");
  const [fields, setFields] = useState<Record<string, string>>(existing?.details ?? {});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function setField(key: string, value: string) {
    setFields((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const payload: Record<string, unknown> =
        method === "paypal"
          ? { method: "paypal", details: { email: fields.email ?? "" } }
          : currency === "NGN"
          ? { method: "bank_transfer", currency: "NGN", bankDetailType: "naira", details: { bankName: fields.bankName ?? "", accountNumber: fields.accountNumber ?? "", accountName: fields.accountName ?? "" } }
          : { method: "bank_transfer", currency: "USD", bankDetailType, details: fields };
      const saved = await api.payoutMethod.save(payload);
      onSaved(saved);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save payment method");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 backdrop-blur-sm px-4 py-8 overflow-y-auto" onClick={onClose}>
      <form
        onSubmit={handleSubmit}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#0b0b0b] border border-white/10 rounded-2xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">{existing ? "Change Payment Method" : "Add Payment Method"}</h2>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method selector */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setMethod("paypal")}
            className={`flex items-center gap-2 justify-center rounded-xl border py-3 text-sm font-medium transition-colors ${method === "paypal" ? "border-primary bg-primary/10 text-primary" : "border-border text-white/60 hover:border-white/20"}`}
          >
            <Wallet className="w-4 h-4" /> PayPal
          </button>
          <button
            type="button"
            onClick={() => setMethod("bank_transfer")}
            className={`flex items-center gap-2 justify-center rounded-xl border py-3 text-sm font-medium transition-colors ${method === "bank_transfer" ? "border-primary bg-primary/10 text-primary" : "border-border text-white/60 hover:border-white/20"}`}
          >
            <Building2 className="w-4 h-4" /> Bank Transfer
          </button>
        </div>

        {method === "paypal" && (
          <div>
            <FieldLabel>PayPal Email</FieldLabel>
            <TextInput type="email" required placeholder="you@example.com" value={fields.email ?? ""} onChange={(e) => setField("email", e.target.value)} />
          </div>
        )}

        {method === "bank_transfer" && (
          <div className="space-y-4">
            <div>
              <FieldLabel>Currency</FieldLabel>
              <Select
                value={currency}
                onChange={(v) => setCurrency(v as Currency)}
                options={[{ value: "NGN", label: "Nigerian Naira" }, { value: "USD", label: "US Dollar" }]}
              />
            </div>

            {currency === "NGN" && (
              <>
                <div>
                  <FieldLabel>Bank Name</FieldLabel>
                  <TextInput required placeholder="e.g. GTBank" value={fields.bankName ?? ""} onChange={(e) => setField("bankName", e.target.value)} />
                </div>
                <div>
                  <FieldLabel>Bank Account Number</FieldLabel>
                  <TextInput required placeholder="0123456789" value={fields.accountNumber ?? ""} onChange={(e) => setField("accountNumber", e.target.value)} />
                </div>
                <div>
                  <FieldLabel>Name on Account</FieldLabel>
                  <TextInput required placeholder="Enter account name" value={fields.accountName ?? ""} onChange={(e) => setField("accountName", e.target.value)} />
                </div>
              </>
            )}

            {currency === "USD" && (
              <>
                <div>
                  <FieldLabel>Receiver Bank Details</FieldLabel>
                  <Select
                    value={bankDetailType}
                    onChange={(v) => setBankDetailType(v as BankDetailType)}
                    options={[{ value: "ach", label: "ACH" }, { value: "wire", label: "Wire" }, { value: "swift", label: "SWIFT" }]}
                  />
                </div>
                <div>
                  <FieldLabel>Receiver Type</FieldLabel>
                  <Select
                    value={fields.receiverType ?? ""}
                    onChange={(v) => setField("receiverType", v)}
                    placeholder="Select receiver type"
                    options={[{ value: "individual", label: "Individual" }, { value: "company", label: "Company / Business" }]}
                  />
                </div>

                {bankDetailType === "ach" && (
                  <>
                    <div>
                      <FieldLabel>ACH Routing Number</FieldLabel>
                      <TextInput required placeholder="Enter ACH routing number" value={fields.routingNumber ?? ""} onChange={(e) => setField("routingNumber", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>Account Number</FieldLabel>
                      <TextInput required placeholder="Enter account number" value={fields.accountNumber ?? ""} onChange={(e) => setField("accountNumber", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>Account Type</FieldLabel>
                      <Select
                        value={fields.accountType ?? ""}
                        onChange={(v) => setField("accountType", v)}
                        placeholder="Select account type"
                        options={[{ value: "checking", label: "Checking" }, { value: "savings", label: "Savings" }]}
                      />
                    </div>
                    <div>
                      <FieldLabel>Account Name</FieldLabel>
                      <TextInput required placeholder="Enter account name" value={fields.accountName ?? ""} onChange={(e) => setField("accountName", e.target.value)} />
                    </div>
                  </>
                )}

                {bankDetailType === "wire" && (
                  <>
                    <div>
                      <FieldLabel>Routing Number</FieldLabel>
                      <TextInput required placeholder="Enter routing number" value={fields.routingNumber ?? ""} onChange={(e) => setField("routingNumber", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>Account Number</FieldLabel>
                      <TextInput required placeholder="Enter account number" value={fields.accountNumber ?? ""} onChange={(e) => setField("accountNumber", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>Account Name</FieldLabel>
                      <TextInput required placeholder="Enter account name" value={fields.accountName ?? ""} onChange={(e) => setField("accountName", e.target.value)} />
                    </div>
                  </>
                )}

                {bankDetailType === "swift" && (
                  <>
                    <div>
                      <FieldLabel>SWIFT / BIC Code</FieldLabel>
                      <TextInput required placeholder="BUKBGB22" value={fields.swiftBicCode ?? ""} onChange={(e) => setField("swiftBicCode", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>IBAN / Account Number</FieldLabel>
                      <TextInput required placeholder="Enter account number" value={fields.accountNumber ?? ""} onChange={(e) => setField("accountNumber", e.target.value)} />
                    </div>
                    <div>
                      <FieldLabel>Account Name</FieldLabel>
                      <TextInput required placeholder="Enter account name" value={fields.accountName ?? ""} onChange={(e) => setField("accountName", e.target.value)} />
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        )}

        {error && <p className="text-red-400 text-sm">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-border text-white/60 text-sm font-medium hover:border-white/20 transition-colors">
            Cancel
          </button>
          <button type="submit" disabled={saving} className="flex-1 py-2.5 rounded-lg bg-primary text-black text-sm font-bold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            {existing ? "Save Changes" : "Save Payment Method"}
          </button>
        </div>
      </form>
    </div>
  );
}
