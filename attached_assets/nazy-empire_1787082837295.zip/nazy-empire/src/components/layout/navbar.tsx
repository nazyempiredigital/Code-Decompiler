import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { NotificationBell } from "@/components/notification-bell";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { BrandLockup } from "@/components/mic-logo";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Website & App Development", href: "/web-development" },
  { label: "Domains", href: "/domains" },
  { label: "Hosting", href: "/hosting" },
  { label: "Music Distribution", href: "/music-distribution" },
  { label: "Contact", href: "/contact" },
];

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileProfileOpen, setMobileProfileOpen] = useState(false);
  const { user } = useAuth();
  const [location] = useLocation();

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-white/10">
        {/* 3-column grid: logo | nav links | right actions — prevents any section from crowding another */}
        <div className="container mx-auto px-4 h-16 grid grid-cols-[auto_1fr_auto] items-center gap-4">

          {/* ── Col 1: Logo ── */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <BrandLockup iconSize="w-7 h-8" textSize="text-2xl" />
          </Link>

          {/* ── Col 2: Desktop nav links (centered) ── */}
          <div className="hidden lg:flex items-center justify-center gap-5">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-primary whitespace-nowrap ${
                  location === link.href ? "text-primary" : "text-white/70"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* ── Col 3: Right actions ── */}
          <div className="flex items-center justify-end gap-2">
            {/* Desktop — logged in */}
            {user && (
              <div className="hidden lg:flex items-center gap-2">
                <NotificationBell />
                <ProfileDropdown
                  open={profileOpen}
                  onClose={() => setProfileOpen(false)}
                  onToggle={() => setProfileOpen((v) => !v)}
                />
              </div>
            )}

            {/* Desktop — guest */}
            {!user && (
              <div className="hidden lg:flex items-center gap-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                    Login
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button size="sm" className="bg-primary text-black hover:bg-primary/90 font-semibold">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile — notification + profile + hamburger */}
            <div className="lg:hidden flex items-center gap-2">
              {user && <NotificationBell />}
              {user && (
                <ProfileDropdown
                  open={mobileProfileOpen}
                  onClose={() => setMobileProfileOpen(false)}
                  onToggle={() => setMobileProfileOpen((v) => !v)}
                />
              )}
              <button
                className="text-white/70 hover:text-white"
                onClick={() => setMenuOpen(!menuOpen)}
              >
                {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile drawer */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden border-t border-white/10 bg-black/95 px-4 py-4 flex flex-col gap-3"
            >
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className={`text-sm font-medium py-2 transition-colors hover:text-primary ${
                    location === link.href ? "text-primary" : "text-white/70"
                  }`}
                >
                  {link.label}
                </Link>
              ))}

              {!user && (
                <div className="flex flex-col gap-2 pt-2 border-t border-white/10">
                  <Link href="/login" onClick={() => setMenuOpen(false)}>
                    <Button variant="ghost" size="sm" className="w-full">Login</Button>
                  </Link>
                  <Link href="/signup" onClick={() => setMenuOpen(false)}>
                    <Button size="sm" className="w-full bg-primary text-black hover:bg-primary/90">
                      Get Started
                    </Button>
                  </Link>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}
