import { Link } from "wouter";
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Lock, BadgePercent, Globe, Shield, HeadphonesIcon } from "lucide-react";
import { BrandLockup } from "@/components/mic-logo";

export function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 pt-16 pb-8">
      <div className="container mx-auto px-4">

        {/* Main grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">

          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="mb-4">
              <BrandLockup iconSize="w-6 h-7" textSize="text-xl" />
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-4">
              Africa's premier technology & entertainment company. Building the future, one project at a time.
            </p>
            <p className="text-white/25 text-xs leading-relaxed mb-4">
              NAZY EMPIRE DIGITAL<br />
              CAC BN 9657494 · Enugu, Nigeria
            </p>
            <div className="flex gap-4">
              <a href="https://facebook.com/nazyempiredigital" target="_blank" rel="noopener noreferrer" aria-label="Nazy Empire on Facebook" className="text-white/40 hover:text-primary transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="https://twitter.com/nazyempire" target="_blank" rel="noopener noreferrer" aria-label="Nazy Empire on Twitter / X" className="text-white/40 hover:text-primary transition-colors"><Twitter className="w-4 h-4" /></a>
              <a href="https://instagram.com/nazyempiredigital" target="_blank" rel="noopener noreferrer" aria-label="Nazy Empire on Instagram" className="text-white/40 hover:text-primary transition-colors"><Instagram className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Services</h4>
            <ul className="space-y-2.5">
              {[
                { label: "Website & App Development", href: "/web-development" },
                { label: "Domain Registration", href: "/domains" },
                { label: "Web Hosting", href: "/hosting" },
                { label: "Music Distribution", href: "/music-distribution" },
                { label: "All Services", href: "/services" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-white/50 hover:text-primary text-sm transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Company</h4>
            <ul className="space-y-2.5">
              {[
                { label: "About Us", href: "/about" },
                { label: "Our Ecosystem", href: "/ecosystem" },
                { label: "Our Work", href: "/projects" },
                { label: "Blog", href: "/blog" },
                { label: "FAQ", href: "/faq" },
                { label: "Contact", href: "/contact" },
                { label: "Start a Project", href: "/order" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-white/50 hover:text-primary text-sm transition-colors">{l.label}</Link>
                </li>
              ))}
              <li>
                <Link href="/affiliate" className="inline-flex items-center gap-1.5 text-sm font-semibold text-amber-400 hover:text-amber-300 transition-colors">
                  <BadgePercent className="w-3.5 h-3.5" />
                  Affiliate Programme
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Legal</h4>
            <ul className="space-y-2.5">
              {[
                { label: "Terms & Conditions", href: "/terms" },
                { label: "Privacy Policy", href: "/privacy" },
                { label: "Terms of Sale", href: "/terms-of-sale" },
                { label: "Cookie Policy", href: "/cookie-policy" },
                { label: "DMCA / Takedown", href: "/dmca" },
                { label: "Accessibility", href: "/accessibility" },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-white/50 hover:text-primary text-sm transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-white/50 text-sm">
                <Mail className="w-4 h-4 text-primary shrink-0" />
                <a href="mailto:info@nazyempire.com" className="hover:text-primary transition-colors">info@nazyempire.com</a>
              </li>
              <li className="flex items-center gap-2 text-white/50 text-sm">
                <Phone className="w-4 h-4 text-primary shrink-0" />
                +234 706 049 9236
              </li>
              <li className="flex items-start gap-2 text-white/50 text-sm">
                <MapPin className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                Enugu, Nigeria
              </li>
            </ul>
          </div>
        </div>

        {/* Trust Badges + App Store */}
        <div className="border-t border-white/10 pt-8 pb-6">
          <p className="text-center text-white/30 text-[11px] uppercase tracking-widest mb-5 font-medium">Trusted, Certified & Secure</p>

          {/* Badge grid — colorful & professional, responsive */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 max-w-xs sm:max-w-lg lg:max-w-4xl mx-auto mb-5">

            {/* ICANN */}
            <div className="relative overflow-hidden rounded-xl border border-blue-600/40 bg-gradient-to-br from-blue-700/30 to-blue-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center mb-2">
                <Globe className="w-4 h-4 text-white" />
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">ICANN</p>
              <p className="text-blue-300/70 text-[9px] leading-tight">Accredited Registrar</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-blue-400" />
            </div>

            {/* CAC */}
            <div className="relative overflow-hidden rounded-xl border border-emerald-600/40 bg-gradient-to-br from-emerald-700/30 to-emerald-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center mb-2">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">CAC Reg.</p>
              <p className="text-emerald-300/70 text-[9px] leading-tight">BN 9657494 · Nigeria</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </div>

            {/* SSL */}
            <div className="relative overflow-hidden rounded-xl border border-green-500/40 bg-gradient-to-br from-green-600/25 to-green-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center mb-2">
                <Lock className="w-4 h-4 text-white" />
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">SSL Secure</p>
              <p className="text-green-300/70 text-[9px] leading-tight">256-bit Encrypted</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-green-400" />
            </div>

            {/* Paystack */}
            <div className="relative overflow-hidden rounded-xl border border-cyan-500/40 bg-gradient-to-br from-cyan-700/25 to-cyan-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-cyan-500 flex items-center justify-center mb-2">
                <span className="text-white font-black text-sm leading-none">P</span>
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">Paystack</p>
              <p className="text-cyan-300/70 text-[9px] leading-tight">Secure Payments</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-cyan-400" />
            </div>

            {/* NDPR */}
            <div className="relative overflow-hidden rounded-xl border border-purple-500/40 bg-gradient-to-br from-purple-700/25 to-purple-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center mb-2">
                <span className="text-white font-black text-[10px] leading-none">NDPR</span>
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">NDPR</p>
              <p className="text-purple-300/70 text-[9px] leading-tight">Data Compliant</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-purple-400" />
            </div>

            {/* Support Team */}
            <div className="relative overflow-hidden rounded-xl border border-amber-500/40 bg-gradient-to-br from-amber-600/25 to-amber-900/20 px-3 py-3 flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center mb-2">
                <HeadphonesIcon className="w-4 h-4 text-white" />
              </div>
              <p className="text-white font-bold text-[11px] leading-tight">Support Team</p>
              <p className="text-amber-300/70 text-[9px] leading-tight">Always Here to Help</p>
              <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-400" />
            </div>

          </div>

          {/* App Store buttons */}
          <div className="flex flex-wrap justify-center gap-3 mb-5">
            <a href="#" className="flex items-center gap-2.5 bg-white/5 border border-white/15 hover:bg-white/10 transition-colors rounded-xl px-5 py-2.5">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white shrink-0"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
              <div>
                <p className="text-white/50 text-[9px] leading-none">Download on the</p>
                <p className="text-white font-semibold text-sm leading-tight">App Store</p>
              </div>
            </a>
            <a href="#" className="flex items-center gap-2.5 bg-white/5 border border-white/15 hover:bg-white/10 transition-colors rounded-xl px-5 py-2.5">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white shrink-0"><path d="M3.18 23.76c.38.21.82.22 1.2.03L16.7 12 4.38.21C4 .02 3.56.03 3.18.24 2.42.66 2 1.47 2 2.42v19.16c0 .95.42 1.76 1.18 2.18z"/><path d="M20.43 10.45l-2.7-1.55L14.6 12l3.13 3.1 2.7-1.55c.77-.44 1.22-1.15 1.22-2.05s-.45-1.61-1.22-2.05z"/><path d="M4.38 23.79l11.56-11.56L4.38.21"/></svg>
              <div>
                <p className="text-white/50 text-[9px] leading-none">Get it on</p>
                <p className="text-white font-semibold text-sm leading-tight">Google Play</p>
              </div>
            </a>
          </div>

          <p className="text-center text-white/30 text-xs">Trusted by businesses across Africa and beyond.</p>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/30 text-sm">
            © {new Date().getFullYear()} NAZY EMPIRE DIGITAL. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center gap-x-4 gap-y-1">
            {[
              { label: "Privacy", href: "/privacy" },
              { label: "Terms", href: "/terms" },
              { label: "Cookies", href: "/cookie-policy" },
              { label: "Accessibility", href: "/accessibility" },
            ].map((l) => (
              <Link key={l.href} href={l.href} className="text-white/30 hover:text-white/60 text-xs transition-colors">
                {l.label}
              </Link>
            ))}
          </div>
        </div>

      </div>
    </footer>
  );
}
