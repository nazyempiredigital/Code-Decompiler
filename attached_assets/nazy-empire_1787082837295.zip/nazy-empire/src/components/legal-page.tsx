import type { ReactNode } from "react";

interface Section {
  heading: string;
  content: ReactNode;
}

interface LegalPageProps {
  title: string;
  subtitle?: string;
  effectiveDate: string;
  lastReviewed: string;
  sections: Section[];
}

export function LegalPage({ title, subtitle, effectiveDate, lastReviewed, sections }: LegalPageProps) {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="bg-zinc-950 py-16 border-b border-white/10">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="font-display text-4xl md:text-5xl text-white mb-3">{title}</h1>
          {subtitle && <p className="text-white/50 text-base mb-4 max-w-2xl">{subtitle}</p>}
          <div className="flex flex-wrap gap-6 text-xs text-white/30 mt-2">
            <span>Effective date: <span className="text-white/50">{effectiveDate}</span></span>
            <span>Last reviewed: <span className="text-white/50">{lastReviewed}</span></span>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="py-16 bg-black">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="prose prose-invert max-w-none
            prose-h2:font-display prose-h2:text-2xl prose-h2:text-white prose-h2:mt-10 prose-h2:mb-3 prose-h2:tracking-wide
            prose-h3:text-white/90 prose-h3:text-lg prose-h3:mt-6 prose-h3:mb-2
            prose-p:text-white/60 prose-p:leading-relaxed
            prose-li:text-white/60 prose-li:leading-relaxed
            prose-strong:text-white/80
            prose-a:text-primary prose-a:no-underline hover:prose-a:underline
            prose-hr:border-white/10 prose-hr:my-8">
            {sections.map((s, i) => (
              <div key={i}>
                <h2>{s.heading}</h2>
                {s.content}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
