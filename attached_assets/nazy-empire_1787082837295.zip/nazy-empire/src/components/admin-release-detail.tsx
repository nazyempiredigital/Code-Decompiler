import { useState } from "react";
import {
  ArrowLeft, Music, FileAudio, Image, Download, Play, ExternalLink,
  CheckCircle, XCircle, AlertCircle, Globe, Hash, Barcode, Store,
  BookOpen, User, Calendar, Save, Loader2, AlertTriangle, Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { api, type Release } from "@/lib/api";

const RELEASE_STATUS: Record<string, { label: string; color: string }> = {
  draft:             { label: "Draft",             color: "bg-white/10 text-white/50 border-white/10" },
  pending_review:    { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  changes_requested: { label: "Changes Requested", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  approved:          { label: "Approved",          color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  rejected:          { label: "Rejected",          color: "bg-red-500/10 text-red-400 border-red-500/20" },
  live:              { label: "Live",              color: "bg-green-500/10 text-green-400 border-green-500/20" },
};

function MetaField({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div>
      <div className="text-white/35 text-xs uppercase tracking-wider mb-1">{label}</div>
      <div className="text-white/80 text-sm">{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
      <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-4">{title}</div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-4">{children}</div>
    </div>
  );
}

interface Props {
  release: Release;
  onBack: () => void;
  onUpdated: (r: Release) => void;
  onDeleted: (id: number) => void;
}

export function AdminReleaseDetail({ release: initialRelease, onBack, onUpdated, onDeleted }: Props) {
  const [release, setRelease] = useState<Release>(initialRelease);
  const [adminNotes, setAdminNotes] = useState(initialRelease.adminNotes ?? "");
  const [isrc, setIsrc] = useState(initialRelease.isrc ?? "");
  const [upc, setUpc] = useState(initialRelease.upc ?? "");
  const [saving, setSaving] = useState<string | null>(null);
  const [identifiersSaved, setIdentifiersSaved] = useState(false);
  const [takedownConfirm, setTakedownConfirm] = useState(false);
  const [takedownInput, setTakedownInput] = useState("");

  const s = RELEASE_STATUS[release.status] ?? RELEASE_STATUS.draft;
  const displayTitle = release.releaseType !== "single" && release.releaseTitle
    ? release.releaseTitle
    : release.title;

  async function act(status: string) {
    if (saving) return;
    setSaving(status);
    try {
      const updated = await api.releases.update(release.id, {
        status: status as Release["status"],
        adminNotes: adminNotes || undefined,
      });
      setRelease(updated);
      onUpdated(updated);
    } catch {}
    setSaving(null);
  }

  async function saveIdentifiers() {
    if (saving) return;
    setSaving("identifiers");
    try {
      const updated = await api.releases.update(release.id, {
        isrc: isrc || undefined,
        upc: upc || undefined,
      });
      setRelease(updated);
      onUpdated(updated);
      setIdentifiersSaved(true);
      setTimeout(() => setIdentifiersSaved(false), 3000);
    } catch {}
    setSaving(null);
  }

  async function takedown() {
    if (saving) return;
    setSaving("takedown");
    try {
      await api.releases.delete(release.id);
      onDeleted(release.id);
      onBack();
    } catch {}
    setSaving(null);
  }

  const canAct = release.status !== "live" && release.status !== "rejected";

  return (
    <div className="space-y-5">
      {/* Back + title bar */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-white/40 hover:text-white/70 text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> All Releases
        </button>
        <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${s.color}`}>
          {s.label}
        </span>
      </div>

      {/* Hero */}
      <div className="flex gap-5">
        {release.artworkUrl ? (
          <img
            src={release.artworkUrl}
            alt={displayTitle}
            className="w-28 h-28 rounded-xl object-cover ring-1 ring-white/10 shrink-0"
          />
        ) : (
          <div className="w-28 h-28 rounded-xl bg-white/5 border border-white/8 flex items-center justify-center shrink-0">
            <Music className="w-8 h-8 text-white/20" />
          </div>
        )}
        <div className="flex-1 min-w-0 pt-1">
          <div className="flex items-start gap-2 flex-wrap">
            <h2 className="font-bold text-xl text-white leading-tight">{displayTitle}</h2>
            {release.version && (
              <span className="text-xs bg-white/8 text-white/40 px-2 py-0.5 rounded border border-white/8 self-center capitalize">
                {release.version}
              </span>
            )}
            <span className="text-xs bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded self-center capitalize">
              {release.releaseType}
            </span>
            {release.explicitContent && (
              <span className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded self-center">E</span>
            )}
          </div>
          <div className="text-white/50 text-sm mt-1">
            {release.mainArtists}
            {release.featuredArtists ? ` ft. ${release.featuredArtists}` : ""}
          </div>
          <div className="text-white/30 text-xs mt-0.5">{release.genre} · {release.language}</div>
          <div className="flex items-center flex-wrap gap-3 mt-2.5">
            {release.userName && (
              <span className="text-white/25 text-xs flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />{release.userName}
              </span>
            )}
            {release.userEmail && (
              <span className="text-white/25 text-xs">{release.userEmail}</span>
            )}
            <span className="text-white/25 text-xs flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              Submitted {new Date(release.createdAt).toLocaleDateString("en-GB", {
                day: "numeric", month: "short", year: "numeric",
              })}
            </span>
          </div>
        </div>
      </div>

      {/* Files */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Audio */}
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <FileAudio className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white/70 text-sm font-medium">Audio File</div>
            {release.audioUrl ? (
              <div className="text-white/30 text-xs truncate">{release.audioUrl.split("/").pop()}</div>
            ) : (
              <div className="text-white/25 text-xs">No file uploaded</div>
            )}
          </div>
          {release.audioUrl && (
            <div className="flex gap-1.5 shrink-0">
              <a
                href={release.audioUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors"
                title="Open in new tab"
              >
                <Play className="w-4 h-4" />
              </a>
              <a
                href={release.audioUrl}
                download
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </a>
            </div>
          )}
        </div>

        {/* Artwork */}
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0">
            <Image className="w-5 h-5 text-blue-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white/70 text-sm font-medium">Cover Artwork</div>
            {release.artworkUrl ? (
              <div className="text-white/30 text-xs truncate">{release.artworkUrl.split("/").pop()}</div>
            ) : (
              <div className="text-white/25 text-xs">No artwork uploaded</div>
            )}
          </div>
          {release.artworkUrl && (
            <div className="flex gap-1.5 shrink-0">
              <a
                href={release.artworkUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors"
                title="View full size"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
              <a
                href={release.artworkUrl}
                download
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-colors"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Tracks (EP/Album) */}
      {release.releaseType !== "single" && release.tracks && release.tracks.length > 0 && (
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
          <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3">
            Tracks · {release.tracks.length}
          </div>
          <div className="space-y-2">
            {release.tracks.map((t, i) => (
              <div key={i} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                <span className="text-white/25 text-xs w-5 text-right shrink-0">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <span className="text-white/70 text-sm">{t.title}</span>
                  {t.version && <span className="text-white/30 text-xs ml-2">{t.version}</span>}
                  {t.explicitContent && <span className="text-xs text-red-400 ml-2">E</span>}
                </div>
                {t.isrc ? (
                  <span className="text-white/30 text-xs font-mono shrink-0">{t.isrc}</span>
                ) : (
                  <span className="text-white/20 text-xs shrink-0">No ISRC</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ISRC / UPC */}
      <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
        <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-4">
          Identifiers
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="text-white/35 text-xs uppercase tracking-wider block mb-1.5">ISRC</label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/25 pointer-events-none" />
              <input
                value={isrc}
                onChange={(e) => setIsrc(e.target.value)}
                placeholder="e.g. NGABCD2600001"
                className="w-full bg-input border border-border rounded-lg pl-9 pr-3 py-2 text-white text-sm font-mono placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <p className="text-white/20 text-xs mt-1">International Standard Recording Code. Required for distribution.</p>
          </div>
          <div>
            <label className="text-white/35 text-xs uppercase tracking-wider block mb-1.5">UPC / EAN</label>
            <div className="relative">
              <Barcode className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/25 pointer-events-none" />
              <input
                value={upc}
                onChange={(e) => setUpc(e.target.value)}
                placeholder="e.g. 123456789012"
                className="w-full bg-input border border-border rounded-lg pl-9 pr-3 py-2 text-white text-sm font-mono placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <p className="text-white/20 text-xs mt-1">Universal Product Code. Leave blank to auto-assign.</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button
            size="sm"
            onClick={saveIdentifiers}
            disabled={saving === "identifiers"}
            className="bg-white/10 hover:bg-white/15 text-white border border-white/10"
          >
            {saving === "identifiers" ? (
              <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> Saving…</>
            ) : (
              <><Save className="w-3.5 h-3.5 mr-1.5" /> Save Identifiers</>
            )}
          </Button>
          {identifiersSaved && (
            <span className="text-green-400 text-xs flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Saved
            </span>
          )}
        </div>
      </div>

      {/* Release Info */}
      <Section title="Release Info">
        <MetaField label="Release Date" value={release.releaseDate} />
        <MetaField label="Original Release Date" value={release.originalReleaseDate} />
        <MetaField label="Copyright" value={release.copyright} />
        <MetaField label="Publisher / Label" value={release.publisher} />
        <MetaField label="Territory" value={
          release.territory === "worldwide"
            ? "Worldwide"
            : release.selectedCountries?.length
              ? `Selected (${release.selectedCountries.length} countries)`
              : release.territory ?? "—"
        } />
        <MetaField label="Language" value={release.language} />
      </Section>

      {/* Credits */}
      <Section title="Credits">
        <MetaField label="Main Artist(s)" value={release.mainArtists} />
        <MetaField label="Featured Artist(s)" value={release.featuredArtists} />
        <MetaField label="Composer" value={release.composer} />
        <MetaField label="Songwriter" value={release.songwriter} />
        <MetaField label="Producer" value={release.producer} />
      </Section>

      {/* Platforms */}
      {release.stores && release.stores.length > 0 && (
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
          <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3">
            Target Platforms · {release.stores.length}
          </div>
          <div className="flex flex-wrap gap-2">
            {release.stores.map((store) => (
              <span
                key={store}
                className="flex items-center gap-1.5 text-xs bg-white/5 border border-white/8 text-white/55 px-3 py-1 rounded-full"
              >
                <Store className="w-3 h-3 text-white/25" />{store}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Lyrics */}
      {release.lyrics && (
        <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5">
          <div className="text-white/40 text-xs uppercase tracking-widest font-semibold mb-3 flex items-center gap-2">
            <BookOpen className="w-3.5 h-3.5" /> Lyrics
          </div>
          <pre className="text-white/55 text-sm font-sans whitespace-pre-wrap leading-relaxed">
            {release.lyrics}
          </pre>
        </div>
      )}

      {/* Admin Action Panel */}
      <div className="bg-white/[0.03] border border-white/8 rounded-xl p-5 space-y-4">
        <div className="text-white/40 text-xs uppercase tracking-widest font-semibold">Admin Actions</div>

        {release.adminNotes && !canAct && (
          <div className="p-3 bg-white/5 border border-white/8 rounded-lg text-white/50 text-sm">
            <span className="text-white/30 text-xs uppercase tracking-wider block mb-1">Previous Note</span>
            {release.adminNotes}
          </div>
        )}

        {canAct && (
          <>
            <div>
              <label className="text-white/35 text-xs uppercase tracking-wider block mb-1.5">Note to Artist</label>
              <textarea
                rows={3}
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                placeholder="Required when requesting changes or declining. The artist will see this message."
                className="w-full bg-input border border-border rounded-lg px-3 py-2.5 text-white text-sm placeholder:text-white/20 resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div className="flex flex-wrap gap-2.5">
              <Button
                onClick={() => act("approved")}
                disabled={!!saving}
                size="sm"
                className="bg-green-600 hover:bg-green-700 text-white font-bold"
              >
                {saving === "approved"
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Approving…</>
                  : <><CheckCircle className="w-3.5 h-3.5 mr-1.5" />Approve</>}
              </Button>
              <Button
                onClick={() => act("live")}
                disabled={!!saving}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold"
              >
                {saving === "live"
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Setting live…</>
                  : <><Globe className="w-3.5 h-3.5 mr-1.5" />Set Live</>}
              </Button>
              <Button
                onClick={() => act("changes_requested")}
                disabled={!!saving}
                size="sm"
                variant="outline"
                className="border-orange-500/30 text-orange-400 hover:bg-orange-500/10"
              >
                {saving === "changes_requested"
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Sending…</>
                  : <><AlertCircle className="w-3.5 h-3.5 mr-1.5" />Request Changes</>}
              </Button>
              <Button
                onClick={() => act("rejected")}
                disabled={!!saving}
                size="sm"
                variant="outline"
                className="border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                {saving === "rejected"
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Declining…</>
                  : <><XCircle className="w-3.5 h-3.5 mr-1.5" />Decline</>}
              </Button>
            </div>
          </>
        )}

        {!canAct && (
          <div className={`flex items-center gap-2 text-sm px-3 py-2.5 rounded-lg border ${RELEASE_STATUS[release.status]?.color}`}>
            <CheckCircle className="w-4 h-4 shrink-0" />
            This release is marked as <strong>{RELEASE_STATUS[release.status]?.label}</strong>. No further action needed.
          </div>
        )}
      </div>

      {/* Danger Zone — takedown (live releases only) */}
      {release.status === "live" && (
        <div className="bg-red-950/20 border border-red-500/25 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="text-red-400 text-xs uppercase tracking-widest font-semibold">Danger Zone</span>
          </div>

          <div>
            <p className="text-white/70 text-sm font-medium">Takedown this release</p>
            <p className="text-white/35 text-xs mt-0.5">
              This will permanently delete the release and all its data from the platform. This action cannot be undone.
            </p>
          </div>

          {!takedownConfirm ? (
            <Button
              size="sm"
              variant="outline"
              onClick={() => setTakedownConfirm(true)}
              className="border-red-500/40 text-red-400 hover:bg-red-500/10 hover:border-red-500/60"
            >
              <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Initiate Takedown
            </Button>
          ) : (
            <div className="space-y-3 bg-red-900/20 border border-red-500/30 rounded-lg p-4">
              <p className="text-red-300 text-sm font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                Are you absolutely sure?
              </p>
              <p className="text-white/50 text-xs leading-relaxed">
                Type <span className="font-mono text-red-400 font-bold">TAKEDOWN</span> below to confirm. This will permanently erase <strong className="text-white/70">{displayTitle}</strong> and cannot be reversed.
              </p>
              <input
                value={takedownInput}
                onChange={(e) => setTakedownInput(e.target.value)}
                placeholder="Type TAKEDOWN to confirm"
                className="w-full bg-black/30 border border-red-500/30 rounded-lg px-3 py-2 text-red-300 text-sm font-mono placeholder:text-white/15 focus:outline-none focus:ring-2 focus:ring-red-500/50"
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={takedown}
                  disabled={takedownInput !== "TAKEDOWN" || saving === "takedown"}
                  className="bg-red-600 hover:bg-red-700 text-white font-bold disabled:opacity-40"
                >
                  {saving === "takedown"
                    ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Taking down…</>
                    : <><Trash2 className="w-3.5 h-3.5 mr-1.5" />Confirm Takedown</>}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => { setTakedownConfirm(false); setTakedownInput(""); }}
                  disabled={saving === "takedown"}
                  className="border-white/15 text-white/50 hover:bg-white/5"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
