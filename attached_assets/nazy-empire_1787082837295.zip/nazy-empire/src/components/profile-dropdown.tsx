import { useRef, useEffect } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { LogOut, LayoutDashboard, Music, ShieldCheck, User } from "lucide-react";
import { useAuth } from "@/lib/auth";

interface Props {
  open: boolean;
  onClose: () => void;
  onToggle: () => void;
}

export function ProfileDropdown({ open, onClose, onToggle }: Props) {
  const { user, logout } = useAuth();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    }
    if (open) document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open, onClose]);

  if (!user) return null;

  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const items = [
    ...(user.role === "admin" || user.role === "moderator"
      ? [{ label: "Admin Panel", href: "/admin", icon: ShieldCheck }]
      : []),
    { label: "My Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ...(user.role === "verified_artist" || user.role === "admin"
      ? [{ label: "Artist Studio", href: "/artist-dashboard", icon: Music }]
      : []),
  ];

  return (
    <div ref={ref} className="relative">
      {/* Trigger */}
      <button
        onClick={onToggle}
        className="w-9 h-9 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center hover:bg-primary/30 transition-colors"
        aria-label="Account menu"
      >
        <span className="text-primary font-bold text-xs">{initials}</span>
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full mt-2 w-60 bg-zinc-950 border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50"
          >
            {/* User info */}
            <div className="px-4 py-3 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                  <span className="text-primary font-bold text-sm">{initials}</span>
                </div>
                <div className="min-w-0">
                  <div className="text-white font-semibold text-sm truncate">{user.name}</div>
                  <div className="text-white/40 text-xs truncate">{user.email}</div>
                </div>
              </div>
            </div>

            {/* Dashboard links */}
            <div className="py-1">
              {items.map(({ label, href, icon: Icon }) => (
                <Link key={href} href={href} onClick={onClose}>
                  <div className="flex items-center gap-3 px-4 py-2.5 text-white/70 hover:text-white hover:bg-white/5 transition-colors cursor-pointer text-sm">
                    <Icon className="w-4 h-4 text-primary/70" />
                    {label}
                  </div>
                </Link>
              ))}
            </div>

            {/* Logout */}
            <div className="border-t border-white/10 py-1">
              <button
                onClick={() => { logout(); onClose(); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-white/50 hover:text-red-400 hover:bg-red-500/5 transition-colors text-sm"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
