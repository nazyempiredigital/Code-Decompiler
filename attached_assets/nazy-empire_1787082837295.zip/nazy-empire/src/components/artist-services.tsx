import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Music2, Image as ImageIcon, Radio, ChevronRight, ArrowLeft,
  CheckCircle, Clock, AlertCircle, XCircle, Upload, Download,
  Loader2, ExternalLink, Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { api, type Release } from "@/lib/api";
import type { ArtistOrder } from "@/lib/api";

// ─── Types ───────────────────────────────────────────────────────────────────

type ServiceType = "mixing_mastering" | "cover_art" | "playlist_pitching";
type View = "home" | "form" | "orders" | "detail";

const SERVICE_INFO: Record<ServiceType, {
  label: string;
  price: number;
  icon: React.ElementType;
  color: string;
  tagline: string;
  description: string;
}> = {
  mixing_mastering: {
    label: "Mixing & Mastering",
    price: 30000,
    icon: Music2,
    color: "from-purple-500/20 to-purple-900/10 border-purple-500/20",
    tagline: "Professional-grade sound, engineered for impact",
    description: "Send us your stems and our engineers will mix and master your track to industry standard, ready for streaming and radio.",
  },
  cover_art: {
    label: "Professional Cover Art",
    price: 10000,
    icon: ImageIcon,
    color: "from-amber-500/20 to-amber-900/10 border-amber-500/20",
    tagline: "Visuals that stop the scroll",
    description: "Our design team creates eye-catching cover art that represents your sound and stands out across all platforms.",
  },
  playlist_pitching: {
    label: "Playlist Pitching",
    price: 10000,
    icon: Radio,
    color: "from-green-500/20 to-green-900/10 border-green-500/20",
    tagline: "Get your music in front of the right audience",
    description: "We pitch your track to playlist curators and content creators who reach your target audience on Spotify, Apple Music and beyond.",
  },
};

const ORDER_STATUS: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pending_payment: { label: "Awaiting Payment", color: "bg-orange-500/10 text-orange-400 border-orange-500/20", icon: Clock },
  paid:            { label: "Paid — In Queue",  color: "bg-blue-500/10 text-blue-400 border-blue-500/20",     icon: Clock },
  in_progress:     { label: "In Progress",       color: "bg-blue-500/10 text-blue-400 border-blue-500/20",     icon: Loader2 },
  confirmed:       { label: "Confirmed",          color: "bg-green-500/10 text-green-400 border-green-500/20", icon: CheckCircle },
  delivered:       { label: "Delivered",          color: "bg-primary/10 text-primary border-primary/20",       icon: CheckCircle },
};

const inputCls = "w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:border-primary/40 placeholder:text-white/25 transition-colors";
const selectCls = `${inputCls} appearance-none cursor-pointer`;

function fmt(n: number) {
  return "₦" + n.toLocaleString("en-NG");
}

// ─── Mixing Form ──────────────────────────────────────────────────────────────

interface MixingFormData {
  songTitle: string;
  bpm: string;
  songKey: string;
  stemsLink: string;
  referenceTrack: string;
  specialInstructions: string;
  checklist: {
    exportedWav: boolean;
    dryStems: boolean;
    consolidated: boolean;
    labeled: boolean;
    referenceMix: boolean;
  };
  demoMixUrl: string;
}

const BLANK_MIXING: MixingFormData = {
  songTitle: "", bpm: "", songKey: "", stemsLink: "", referenceTrack: "", specialInstructions: "",
  checklist: { exportedWav: false, dryStems: false, consolidated: false, labeled: false, referenceMix: false },
  demoMixUrl: "",
};

function CheckItem({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group p-3 rounded-lg hover:bg-white/3 transition-colors">
      <div
        onClick={() => onChange(!checked)}
        className={`mt-0.5 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${checked ? "bg-primary border-primary" : "border-white/30 group-hover:border-white/50"}`}
      >
        {checked && <svg className="w-3 h-3 text-black" fill="none" viewBox="0 0 12 10" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M1 5l4 4 6-8"/></svg>}
      </div>
      <div>
        <span className="text-white/80 text-sm font-medium leading-snug">{label}</span>
        {hint && <p className="text-white/35 text-xs mt-0.5 leading-relaxed">{hint}</p>}
      </div>
    </label>
  );
}

function MixingForm({ onSubmit, loading }: { onSubmit: (data: MixingFormData, demoFile: File | null) => void; loading: boolean }) {
  const [form, setForm] = useState<MixingFormData>({ ...BLANK_MIXING });
  const [demoFile, setDemoFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (k: keyof MixingFormData) => (v: string) => setForm((f) => ({ ...f, [k]: v }));
  const setCheck = (k: keyof MixingFormData["checklist"]) => (v: boolean) =>
    setForm((f) => ({ ...f, checklist: { ...f.checklist, [k]: v } }));

  const allChecked = Object.values(form.checklist).every(Boolean);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.songTitle.trim()) { setError("Song title is required."); return; }
    if (!form.stemsLink.trim()) { setError("Please provide a stems link or upload location."); return; }
    if (!allChecked) { setError("Please confirm all checklist items before submitting."); return; }
    setError(null);
    onSubmit(form, demoFile);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Song Details */}
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Song Details</h3>
        </div>
        <div className="p-5 grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Song Title <span className="text-primary">*</span></label>
            <input className={inputCls} value={form.songTitle} onChange={(e) => set("songTitle")(e.target.value)} placeholder="e.g. Last Last" />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Tempo / BPM</label>
            <input className={inputCls} value={form.bpm} onChange={(e) => set("bpm")(e.target.value)} placeholder="e.g. 112 BPM" />
          </div>
          <div className="sm:col-span-2 space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Song Key</label>
            <input className={inputCls} value={form.songKey} onChange={(e) => set("songKey")(e.target.value)} placeholder="e.g. F Minor" />
          </div>
        </div>
      </div>

      {/* Upload Checklist */}
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3 flex items-center gap-2">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Upload Checklist</h3>
          <span className="text-xs text-white/40">— All items must be confirmed</span>
        </div>
        <div className="p-3 space-y-0.5">
          <CheckItem checked={form.checklist.exportedWav} onChange={setCheck("exportedWav")}
            label="Export Stems in WAV format"
            hint="24-bit, 44.1kHz or higher" />
          <CheckItem checked={form.checklist.dryStems} onChange={setCheck("dryStems")}
            label="All stems are dry"
            hint="Turn off reverb, delay, and heavy processing unless they are creative effects crucial to the sound" />
          <CheckItem checked={form.checklist.consolidated} onChange={setCheck("consolidated")}
            label="All tracks are consolidated"
            hint="They all start at the exact same timestamp (0:00)" />
          <CheckItem checked={form.checklist.labeled} onChange={setCheck("labeled")}
            label="Files are clearly labeled"
            hint="e.g. Lead_Vocals.wav, Kick.wav, Bass_Synth.wav" />
          <CheckItem checked={form.checklist.referenceMix} onChange={setCheck("referenceMix")}
            label="Include original demo mix as reference" />
        </div>
      </div>

      {/* File Submission */}
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">File Submission</h3>
        </div>
        <div className="p-5 space-y-4">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Stems ZIP — Google Drive or WeTransfer Link <span className="text-primary">*</span></label>
            <p className="text-xs text-white/35">Share a link to your ZIP file. Make sure the link allows access (Anyone with link).</p>
            <input className={inputCls} value={form.stemsLink} onChange={(e) => set("stemsLink")(e.target.value)} placeholder="https://drive.google.com/..." />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Upload Demo / Rough Mix</label>
            <div
              onClick={() => fileRef.current?.click()}
              className="border-2 border-dashed border-white/15 rounded-xl p-5 text-center cursor-pointer hover:border-primary/40 hover:bg-primary/3 transition-all group"
            >
              <input ref={fileRef} type="file" accept="audio/*" className="hidden" onChange={(e) => setDemoFile(e.target.files?.[0] ?? null)} />
              <Upload className="w-6 h-6 text-white/25 group-hover:text-primary/50 mx-auto mb-2 transition-colors" />
              {demoFile ? (
                <p className="text-white/70 text-sm font-medium">{demoFile.name}</p>
              ) : (
                <p className="text-white/35 text-sm">Click to upload your demo mix (MP3, WAV)</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Creative Brief */}
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Creative Brief</h3>
        </div>
        <div className="p-5 space-y-4">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Reference Track</label>
            <p className="text-xs text-white/35">Tell us how you want the mix to feel — name an artist and song.</p>
            <input className={inputCls} value={form.referenceTrack} onChange={(e) => set("referenceTrack")(e.target.value)} placeholder={"e.g. \"I want the vocals to sit like Burna Boy's Last Last\""} />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Special Instructions / Notes</label>
            <textarea className={inputCls} rows={4} value={form.specialInstructions} onChange={(e) => set("specialInstructions")(e.target.value)} placeholder="Anything else the engineer should know..." />
          </div>
        </div>
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3">{error}</p>}

      <Button type="submit" disabled={loading} className="w-full bg-primary text-black hover:bg-primary/90 font-bold py-3 text-base">
        {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <>Proceed to Payment — {fmt(30000)}</>}
      </Button>
    </form>
  );
}

// ─── Cover Art Form ───────────────────────────────────────────────────────────

interface CoverArtFormData {
  artistNames: string;
  exactTitle: string;
  releaseType: "single" | "ep" | "album";
  visualConcept: string;
  colorPalette: string;
  referenceFiles: string[];
}

const BLANK_COVER: CoverArtFormData = {
  artistNames: "", exactTitle: "", releaseType: "single", visualConcept: "", colorPalette: "", referenceFiles: [],
};

function CoverArtForm({ onSubmit, loading }: { onSubmit: (data: CoverArtFormData, refs: File[]) => void; loading: boolean }) {
  const [form, setForm] = useState<CoverArtFormData>({ ...BLANK_COVER });
  const [refFiles, setRefFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (k: keyof CoverArtFormData) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []).slice(0, 3 - refFiles.length);
    setRefFiles((prev) => [...prev, ...files].slice(0, 3));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.artistNames.trim()) { setError("Artist name is required."); return; }
    if (!form.exactTitle.trim()) { setError("Track/release title is required."); return; }
    if (!form.visualConcept.trim()) { setError("Please describe your visual concept."); return; }
    setError(null);
    onSubmit(form, refFiles);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Release Details</h3>
        </div>
        <div className="p-5 grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Artist Name(s) to Display on Cover <span className="text-primary">*</span></label>
            <input className={inputCls} value={form.artistNames} onChange={(e) => set("artistNames")(e.target.value)} placeholder="e.g. Burna Boy ft. WizKid" />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Exact Title to Display on Cover <span className="text-primary">*</span></label>
            <input className={inputCls} value={form.exactTitle} onChange={(e) => set("exactTitle")(e.target.value)} placeholder="e.g. City Boys" />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Release Type</label>
            <div className="relative">
              <select className={selectCls} value={form.releaseType} onChange={(e) => set("releaseType")(e.target.value)}>
                <option value="single" className="bg-[#111]">Single</option>
                <option value="ep" className="bg-[#111]">EP</option>
                <option value="album" className="bg-[#111]">Album</option>
              </select>
              <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-white/30">▾</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Visual Brief</h3>
        </div>
        <div className="p-5 space-y-4">
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Visual Concept & Vibe <span className="text-primary">*</span></label>
            <p className="text-xs text-white/35">Describe the mood, aesthetic, and feeling you want the cover to convey.</p>
            <textarea className={inputCls} rows={4} value={form.visualConcept} onChange={(e) => set("visualConcept")(e.target.value)}
              placeholder='e.g. "Dark, moody, vintage aesthetic with neon purple lights. Late-night and introspective."' />
          </div>
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Color Palette Preferences</label>
            <input className={inputCls} value={form.colorPalette} onChange={(e) => set("colorPalette")(e.target.value)} placeholder='e.g. "Warm tones, browns, golds" or "Cool blues and greys"' />
          </div>
        </div>
      </div>

      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Reference Images / Photos</h3>
          <p className="text-white/40 text-xs mt-0.5">Upload up to 3 files — artist photos or covers you like</p>
        </div>
        <div className="p-5">
          <div
            onClick={() => refFiles.length < 3 && fileRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-5 text-center transition-all ${refFiles.length < 3 ? "cursor-pointer border-white/15 hover:border-primary/40 hover:bg-primary/3" : "border-white/8 opacity-50"}`}
          >
            <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFileChange} />
            <Upload className="w-6 h-6 text-white/25 mx-auto mb-2" />
            <p className="text-white/35 text-sm">{refFiles.length < 3 ? "Click to upload reference images (PNG, JPG)" : "Maximum 3 files reached"}</p>
          </div>
          {refFiles.length > 0 && (
            <div className="mt-3 space-y-2">
              {refFiles.map((f, i) => (
                <div key={i} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
                  <span className="text-white/70 text-sm truncate">{f.name}</span>
                  <button type="button" onClick={() => setRefFiles((prev) => prev.filter((_, j) => j !== i))} className="text-white/30 hover:text-red-400 transition-colors ml-2">
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3">{error}</p>}

      <Button type="submit" disabled={loading} className="w-full bg-primary text-black hover:bg-primary/90 font-bold py-3 text-base">
        {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <>Proceed to Payment — {fmt(10000)}</>}
      </Button>
    </form>
  );
}

// ─── Playlist Pitching Form ───────────────────────────────────────────────────

interface PlaylistFormData {
  trackTitle: string;
  releaseId: string;
  upc: string;
  isrc: string;
  primaryGenre: string;
  campaignStartDate: string;
  targetAudience: string[];
}

const BLANK_PLAYLIST: PlaylistFormData = {
  trackTitle: "", releaseId: "", upc: "", isrc: "", primaryGenre: "", campaignStartDate: "", targetAudience: [],
};

const GENRES = ["Afrobeats", "Amapiano", "Afro-Fusion", "Street-Pop", "Afro-Adura", "Highlife", "Gospel", "Afropop", "Other"];
const AUDIENCE_VIBES = ["Dance & Choreography", "Slow-mo & Lifestyle", "Comedy & Memes", "Relatable & Emotional"];

function PlaylistForm({ releases, onSubmit, loading }: { releases: Release[]; onSubmit: (data: PlaylistFormData) => void; loading: boolean }) {
  const [form, setForm] = useState<PlaylistFormData>({ ...BLANK_PLAYLIST });
  const [error, setError] = useState<string | null>(null);

  const set = (k: keyof PlaylistFormData) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  // Min date: 7 days from now
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 7);
  const minDateStr = minDate.toISOString().split("T")[0];

  function selectRelease(releaseId: string) {
    const r = releases.find((r) => String(r.id) === releaseId);
    setForm((f) => ({
      ...f,
      releaseId,
      trackTitle: r?.title ?? f.trackTitle,
      upc: r?.upc ?? f.upc ?? "",
      isrc: r?.isrc ?? f.isrc ?? "",
    }));
  }

  function toggleAudience(v: string) {
    setForm((f) => ({
      ...f,
      targetAudience: f.targetAudience.includes(v)
        ? f.targetAudience.filter((a) => a !== v)
        : [...f.targetAudience, v],
    }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.trackTitle.trim()) { setError("Track title is required."); return; }
    if (!form.primaryGenre) { setError("Please select a primary genre."); return; }
    if (!form.campaignStartDate) { setError("Please select a campaign start date."); return; }
    if (form.campaignStartDate < minDateStr) { setError("Campaign must be scheduled at least 7 days in advance."); return; }
    if (form.targetAudience.length === 0) { setError("Please select at least one target audience."); return; }
    setError(null);
    onSubmit(form);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Track Selection</h3>
        </div>
        <div className="p-5 space-y-4">
          {releases.length > 0 && (
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">Select from My Distributed Tracks</label>
              <div className="relative">
                <select className={selectCls} value={form.releaseId} onChange={(e) => selectRelease(e.target.value)}>
                  <option value="" className="bg-[#111]">— Select a track —</option>
                  {releases.filter((r) => r.status === "live" || r.status === "approved").map((r) => (
                    <option key={r.id} value={String(r.id)} className="bg-[#111]">{r.title}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-white/30">▾</div>
              </div>
            </div>
          )}
          <div className="space-y-1.5">
            <label className="block text-sm font-medium text-white/70">Track Title <span className="text-primary">*</span></label>
            <input className={inputCls} value={form.trackTitle} onChange={(e) => set("trackTitle")(e.target.value)} placeholder="Enter track title" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">UPC Code</label>
              <input className={inputCls} value={form.upc} onChange={(e) => set("upc")(e.target.value)} placeholder="Auto-filled from track" />
            </div>
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">ISRC Code</label>
              <input className={inputCls} value={form.isrc} onChange={(e) => set("isrc")(e.target.value)} placeholder="Auto-filled from track" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white/3 border border-white/8 rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-white/8 bg-white/3">
          <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Campaign Details</h3>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">Primary Genre <span className="text-primary">*</span></label>
              <div className="relative">
                <select className={selectCls} value={form.primaryGenre} onChange={(e) => set("primaryGenre")(e.target.value)}>
                  <option value="" className="bg-[#111]">Select genre</option>
                  {GENRES.map((g) => <option key={g} value={g} className="bg-[#111]">{g}</option>)}
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-white/30">▾</div>
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">Campaign Start Date <span className="text-primary">*</span></label>
              <input type="date" min={minDateStr} className={inputCls} value={form.campaignStartDate} onChange={(e) => set("campaignStartDate")(e.target.value)} />
              <p className="text-xs text-white/35">Must be at least 7 days from today</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-white/70">Target Audience / Vibes <span className="text-primary">*</span></label>
            <div className="grid grid-cols-2 gap-2">
              {AUDIENCE_VIBES.map((v) => (
                <label key={v} className="flex items-center gap-2.5 cursor-pointer group p-2.5 rounded-lg border border-white/8 hover:border-white/20 transition-colors">
                  <div
                    onClick={() => toggleAudience(v)}
                    className={`w-4 h-4 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                      form.targetAudience.includes(v) ? "bg-primary border-primary" : "border-white/30"
                    }`}
                  >
                    {form.targetAudience.includes(v) && <svg className="w-2.5 h-2.5 text-black" fill="none" viewBox="0 0 12 10" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M1 5l4 4 6-8"/></svg>}
                  </div>
                  <span className="text-white/70 text-xs leading-snug">{v}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3">{error}</p>}

      <Button type="submit" disabled={loading} className="w-full bg-primary text-black hover:bg-primary/90 font-bold py-3 text-base">
        {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <>Proceed to Payment — {fmt(10000)}</>}
      </Button>
    </form>
  );
}

// ─── Payment Modal ────────────────────────────────────────────────────────────

function PaymentModal({
  order, onClose, onPaid,
}: {
  order: ArtistOrder;
  onClose: () => void;
  onPaid: (updated: ArtistOrder) => void;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [initiated, setInitiated] = useState(false);

  async function handlePay() {
    setLoading(true);
    setError(null);
    try {
      const data = await api.artistOrders.initPayment(order.id);
      setInitiated(true);
      // Open Paystack popup
      if ((window as any).PaystackPop) {
        const handler = (window as any).PaystackPop.setup({
          key: data.publicKey,
          email: data.email,
          amount: data.amountKobo,
          ref: data.reference,
          callback: async (response: { reference: string }) => {
            try {
              await api.artistOrders.verifyPayment(order.id, response.reference);
              const updated = await api.artistOrders.get(order.id);
              onPaid(updated);
            } catch {
              setError("Payment verification failed. Please contact support.");
            }
          },
          onClose: () => { setInitiated(false); },
        });
        handler.openIframe();
      } else {
        // Fallback: redirect to authorization URL
        window.location.href = data.authorizationUrl;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to initialize payment");
    }
    setLoading(false);
  }

  const price = { mixing_mastering: 30000, cover_art: 10000, playlist_pitching: 10000 }[order.serviceType] ?? 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm px-4" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md bg-[#0b0b0b] border border-white/10 rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-bold text-lg">Complete Payment</h2>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors">
            <XCircle className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-black/30 border border-border rounded-xl p-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-white/50">Service</span>
            <span className="text-white font-medium">{SERVICE_INFO[order.serviceType as ServiceType]?.label}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-white/50">Order ID</span>
            <span className="text-white/70 font-mono text-xs">{order.orderId}</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-white/8">
            <span className="text-white/50 text-sm">Total</span>
            <span className="text-primary font-bold text-xl">{fmt(price)}</span>
          </div>
        </div>

        {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3">{error}</p>}

        <div className="flex gap-3">
          <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-border text-white/60 text-sm font-medium hover:border-white/20 transition-colors">
            Cancel
          </button>
          <Button onClick={handlePay} disabled={loading} className="flex-1 bg-primary text-black hover:bg-primary/90 font-bold">
            {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...</> : "Pay Now"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Order Card ───────────────────────────────────────────────────────────────

function OrderCard({ order, onClick }: { order: ArtistOrder; onClick: () => void }) {
  const info = SERVICE_INFO[order.serviceType as ServiceType];
  const status = ORDER_STATUS[order.status] ?? ORDER_STATUS.pending_payment;
  const StatusIcon = status.icon;
  const Icon = info?.icon ?? Music2;

  return (
    <button onClick={onClick} className="w-full text-left bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-all group">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5 text-primary/70" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <p className="text-white font-semibold text-sm truncate">{info?.label}</p>
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium whitespace-nowrap shrink-0 ${status.color}`}>
              <StatusIcon className="w-3 h-3" />{status.label}
            </span>
          </div>
          <p className="text-white/40 text-xs font-mono">{order.orderId}</p>
          <p className="text-white/30 text-xs mt-1">{new Date(order.createdAt).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })}</p>
        </div>
        <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-colors shrink-0 mt-1" />
      </div>
    </button>
  );
}

// ─── Order Detail ─────────────────────────────────────────────────────────────

function OrderDetail({ order: initialOrder, onBack, onUpdate }: {
  order: ArtistOrder;
  onBack: () => void;
  onUpdate: (o: ArtistOrder) => void;
}) {
  const [order, setOrder] = useState(initialOrder);
  const [payModal, setPayModal] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState(false);
  const [uploadLoading, setUploadLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const info = SERVICE_INFO[order.serviceType as ServiceType];
  const status = ORDER_STATUS[order.status] ?? ORDER_STATUS.pending_payment;
  const StatusIcon = status.icon;
  const hasResult = (order.resultFiles?.length ?? 0) > 0;
  const canDownload = hasResult && order.status !== "pending_payment";
  const needsFiles = order.serviceType === "mixing_mastering";

  async function handleDownload() {
    setDownloadLoading(true);
    try {
      const data = await api.artistOrders.acknowledgeDownload(order.id);
      const updated = { ...order, status: "delivered" as const, resultFiles: data.resultFiles };
      setOrder(updated);
      onUpdate(updated);
      // Open each result file
      for (const url of data.resultFiles) {
        window.open(url.startsWith("/api") ? url : `/api${url}`, "_blank");
      }
    } catch {}
    setDownloadLoading(false);
  }

  async function handleArtistFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadLoading(true);
    try {
      const result = await api.artistOrders.uploadFile(order.id, file);
      const updated = { ...order, artistFiles: [...(order.artistFiles ?? []), result.url] };
      setOrder(updated);
      onUpdate(updated);
    } catch {}
    setUploadLoading(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  const fd = order.formData as Record<string, unknown>;

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-1.5 text-white/50 hover:text-white text-sm mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Orders
      </button>

      <div className="space-y-5">
        {/* Header */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
              {info?.icon && <info.icon className="w-6 h-6 text-primary/70" />}
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-white font-bold text-lg">{info?.label}</h2>
              <p className="text-white/40 text-xs font-mono mt-0.5">{order.orderId}</p>
              <div className="mt-2">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-medium ${status.color}`}>
                  <StatusIcon className="w-3.5 h-3.5" />{status.label}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Payment CTA */}
        {order.status === "pending_payment" && (
          <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-5 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-orange-400 font-semibold">Payment Required</p>
              <p className="text-orange-400/70 text-sm mt-0.5">Your order is reserved. Complete payment to proceed.</p>
            </div>
            <Button onClick={() => setPayModal(true)} className="bg-primary text-black hover:bg-primary/90 font-bold shrink-0">
              Pay {fmt({ mixing_mastering: 30000, cover_art: 10000, playlist_pitching: 10000 }[order.serviceType] ?? 0)}
            </Button>
          </div>
        )}

        {/* Result files: download */}
        {canDownload && (
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-5">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <p className="text-green-400 font-semibold">
                  {order.status === "delivered" ? "Files Downloaded" : "Your Result is Ready!"}
                </p>
                <p className="text-green-400/70 text-sm mt-0.5">
                  {order.status === "delivered"
                    ? "You can re-download your files anytime below."
                    : "Download your completed files. Delivery will be confirmed on first download."}
                </p>
              </div>
              <Button onClick={handleDownload} disabled={downloadLoading} className="bg-green-500 text-black hover:bg-green-400 font-bold shrink-0">
                {downloadLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Download className="w-4 h-4 mr-1.5" />Download Files</>}
              </Button>
            </div>
            {order.resultFiles && order.resultFiles.length > 1 && (
              <div className="mt-3 space-y-1.5">
                {order.resultFiles.map((url, i) => (
                  <a key={i} href={url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-green-400/70 hover:text-green-400 text-sm transition-colors">
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{url.split("/").pop()}</span>
                  </a>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Artist file uploads (only for mixing after payment) */}
        {needsFiles && order.status !== "pending_payment" && (
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="text-white font-semibold text-sm mb-3">Your Uploaded Files</h3>
            {(order.artistFiles ?? []).length > 0 ? (
              <div className="space-y-2 mb-3">
                {(order.artistFiles ?? []).map((url, i) => (
                  <a key={i} href={url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-white/60 hover:text-white text-sm transition-colors">
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{url.split("/").pop()}</span>
                  </a>
                ))}
              </div>
            ) : (
              <p className="text-white/30 text-sm mb-3">No files uploaded yet.</p>
            )}
            {order.status !== "delivered" && (
              <>
                <input ref={fileRef} type="file" className="hidden" onChange={handleArtistFileUpload} />
                <Button onClick={() => fileRef.current?.click()} disabled={uploadLoading} variant="outline" size="sm" className="border-border text-white/60 hover:text-white">
                  {uploadLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <Upload className="w-3.5 h-3.5 mr-1" />}
                  Upload Additional File
                </Button>
              </>
            )}
          </div>
        )}

        {/* Submission details */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider">Order Details</h3>
          <div className="space-y-2.5">
            {Object.entries(fd)
              .filter(([k]) => k !== "checklist" && k !== "referenceFiles" && k !== "demoMixUrl")
              .map(([k, v]) => (
                <div key={k} className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-white/40 capitalize">{k.replace(/([A-Z])/g, " $1").trim()}</span>
                  <span className="text-white/80 break-words">{Array.isArray(v) ? v.join(", ") : String(v ?? "—")}</span>
                </div>
              ))}
            {fd.checklist && typeof fd.checklist === "object" && (
              <div className="pt-2 border-t border-white/8">
                <span className="text-white/40 text-sm">Checklist Confirmed</span>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {Object.entries(fd.checklist as Record<string, boolean>).filter(([, v]) => v).map(([k]) => (
                    <span key={k} className="text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full">✓ {k}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Admin notes */}
        {order.adminNotes && (
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-5 flex gap-3">
            <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-blue-400 font-semibold text-sm mb-1">Note from Nazy Empire</p>
              <p className="text-blue-400/80 text-sm leading-relaxed">{order.adminNotes}</p>
            </div>
          </div>
        )}
      </div>

      {payModal && (
        <PaymentModal
          order={order}
          onClose={() => setPayModal(false)}
          onPaid={(updated) => {
            setOrder(updated);
            onUpdate(updated);
            setPayModal(false);
          }}
        />
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

interface ArtistServicesProps {
  user: { id: number; email: string; name: string };
  releases: Release[];
}

export function ArtistServices({ user, releases }: ArtistServicesProps) {
  const [view, setView] = useState<View>("home");
  const [selectedService, setSelectedService] = useState<ServiceType | null>(null);
  const [orders, setOrders] = useState<ArtistOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<ArtistOrder | null>(null);
  const [loading, setLoading] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successOrder, setSuccessOrder] = useState<ArtistOrder | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadingFilesRef = useRef<File[]>([]);

  useEffect(() => {
    loadOrders();
    // Inject Paystack script
    if (!document.getElementById("paystack-js")) {
      const s = document.createElement("script");
      s.id = "paystack-js";
      s.src = "https://js.paystack.co/v1/inline.js";
      document.head.appendChild(s);
    }
  }, []);

  async function loadOrders() {
    setLoading(true);
    try { setOrders(await api.artistOrders.list()); } catch {}
    setLoading(false);
  }

  async function submitMixing(formData: MixingFormData, demoFile: File | null) {
    setFormLoading(true);
    setError(null);
    try {
      const order = await api.artistOrders.create("mixing_mastering", formData);
      // Upload demo file if present
      if (demoFile) {
        try { await api.artistOrders.uploadFile(order.id, demoFile); } catch {}
      }
      setOrders((prev) => [order, ...prev]);
      setSuccessOrder(order);
      setView("detail");
      setSelectedOrder(order);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit order");
    }
    setFormLoading(false);
  }

  async function submitCoverArt(formData: CoverArtFormData, refFiles: File[]) {
    setFormLoading(true);
    setError(null);
    try {
      const order = await api.artistOrders.create("cover_art", formData);
      // Upload reference files
      for (const file of refFiles) {
        try { await api.artistOrders.uploadFile(order.id, file); } catch {}
      }
      setOrders((prev) => [order, ...prev]);
      setSuccessOrder(order);
      setView("detail");
      setSelectedOrder(order);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit order");
    }
    setFormLoading(false);
  }

  async function submitPlaylist(formData: PlaylistFormData) {
    setFormLoading(true);
    setError(null);
    try {
      const order = await api.artistOrders.create("playlist_pitching", formData);
      setOrders((prev) => [order, ...prev]);
      setSuccessOrder(order);
      setView("detail");
      setSelectedOrder(order);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit order");
    }
    setFormLoading(false);
  }

  // ── HOME ──────────────────────────────────────────────────────────────────
  if (view === "home") {
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white font-bold text-xl">Artist Services</h2>
            <p className="text-white/40 text-sm mt-0.5">Professional services to elevate your music</p>
          </div>
          {orders.length > 0 && (
            <Button onClick={() => setView("orders")} variant="outline" size="sm" className="border-border text-white/60 hover:text-white">
              My Orders ({orders.length})
            </Button>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-3 mb-8">
          {(Object.entries(SERVICE_INFO) as [ServiceType, typeof SERVICE_INFO[ServiceType]][]).map(([type, info]) => {
            const Icon = info.icon;
            return (
              <motion.button
                key={type}
                whileHover={{ y: -2 }}
                onClick={() => { setSelectedService(type); setView("form"); setError(null); }}
                className={`text-left p-5 rounded-2xl border bg-gradient-to-br ${info.color} hover:scale-[1.01] transition-transform`}
              >
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-white font-bold text-base mb-1">{info.label}</p>
                <p className="text-white/50 text-xs leading-relaxed mb-4">{info.tagline}</p>
                <div className="flex items-center justify-between">
                  <span className="text-primary font-bold text-lg">{fmt(info.price)}</span>
                  <span className="text-white/30 text-xs">per track</span>
                </div>
              </motion.button>
            );
          })}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-white/30 animate-spin" />
          </div>
        ) : orders.length > 0 ? (
          <div>
            <h3 className="text-white/60 text-sm font-medium uppercase tracking-wider mb-3">Recent Orders</h3>
            <div className="space-y-2">
              {orders.slice(0, 3).map((o) => (
                <OrderCard key={o.id} order={o} onClick={() => { setSelectedOrder(o); setView("detail"); }} />
              ))}
              {orders.length > 3 && (
                <button onClick={() => setView("orders")} className="w-full py-2.5 text-white/40 hover:text-white text-sm transition-colors">
                  View all {orders.length} orders →
                </button>
              )}
            </div>
          </div>
        ) : null}
      </div>
    );
  }

  // ── FORM ──────────────────────────────────────────────────────────────────
  if (view === "form" && selectedService) {
    const info = SERVICE_INFO[selectedService];
    return (
      <div>
        <button onClick={() => { setView("home"); setError(null); }} className="flex items-center gap-1.5 text-white/50 hover:text-white text-sm mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <div className="mb-6">
          <h2 className="text-white font-bold text-xl">{info.label}</h2>
          <p className="text-white/40 text-sm mt-0.5">{info.description}</p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={selectedService} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {selectedService === "mixing_mastering" && (
              <MixingForm onSubmit={submitMixing} loading={formLoading} />
            )}
            {selectedService === "cover_art" && (
              <CoverArtForm onSubmit={submitCoverArt} loading={formLoading} />
            )}
            {selectedService === "playlist_pitching" && (
              <PlaylistForm releases={releases} onSubmit={submitPlaylist} loading={formLoading} />
            )}
          </motion.div>
        </AnimatePresence>

        {error && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-4 py-3 mt-4">{error}</p>}
      </div>
    );
  }

  // ── ORDERS LIST ───────────────────────────────────────────────────────────
  if (view === "orders") {
    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <button onClick={() => setView("home")} className="flex items-center gap-1.5 text-white/50 hover:text-white text-sm mb-2 transition-colors">
              <ArrowLeft className="w-4 h-4" /> Back
            </button>
            <h2 className="text-white font-bold text-xl">My Orders</h2>
          </div>
          <Button onClick={() => setView("home")} className="bg-primary text-black hover:bg-primary/90 font-bold">
            + New Order
          </Button>
        </div>
        {orders.length === 0 ? (
          <div className="text-center py-16 text-white/30">
            <Music2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>No orders yet. Order a service above to get started.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {orders.map((o) => (
              <OrderCard key={o.id} order={o} onClick={() => { setSelectedOrder(o); setView("detail"); }} />
            ))}
          </div>
        )}
      </div>
    );
  }

  // ── ORDER DETAIL ──────────────────────────────────────────────────────────
  if (view === "detail" && selectedOrder) {
    return (
      <OrderDetail
        order={selectedOrder}
        onBack={() => setView(orders.length > 3 ? "orders" : "home")}
        onUpdate={(updated) => {
          setSelectedOrder(updated);
          setOrders((prev) => prev.map((o) => o.id === updated.id ? updated : o));
        }}
      />
    );
  }

  return null;
}
