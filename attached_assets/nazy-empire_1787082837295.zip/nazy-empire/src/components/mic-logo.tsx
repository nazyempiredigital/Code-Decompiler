/** Gold microphone icon matching the Nazy Empire brand image */
export function MicIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 52 62"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="gold-grad" x1="0%" y1="0%" x2="60%" y2="100%">
          <stop offset="0%"  stopColor="#F7DC6F" />
          <stop offset="40%" stopColor="#D4AC0D" />
          <stop offset="100%" stopColor="#9A7D0A" />
        </linearGradient>
        <linearGradient id="gold-arm" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%"  stopColor="#E8C83B" />
          <stop offset="100%" stopColor="#A67C00" />
        </linearGradient>
      </defs>

      {/* Mic body — pill / capsule */}
      <rect x="13" y="2" width="26" height="36" rx="13" fill="url(#gold-grad)" />

      {/* Grille lines (three horizontal bars across the body) */}
      <rect x="13" y="16" width="26" height="3" rx="1" fill="rgba(0,0,0,0.42)" />
      <rect x="13" y="22" width="26" height="3" rx="1" fill="rgba(0,0,0,0.42)" />
      <rect x="13" y="28" width="26" height="3" rx="1" fill="rgba(0,0,0,0.42)" />

      {/* Left arm */}
      <rect x="0" y="19" width="13" height="4.5" rx="2" fill="url(#gold-arm)" />
      {/* Right arm */}
      <rect x="39" y="19" width="13" height="4.5" rx="2" fill="url(#gold-arm)" />

      {/* U-shaped neck/yoke */}
      <path
        d="M17 38 L17 46 Q17 56 26 56 Q35 56 35 46 L35 38"
        fill="none"
        stroke="url(#gold-grad)"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Horizontal base foot */}
      <line x1="16" y1="59" x2="36" y2="59" stroke="url(#gold-grad)" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
}

/** Full lockup: mic icon + wordmark */
export function BrandLockup({ iconSize = "w-8 h-9", textSize = "text-2xl" }: { iconSize?: string; textSize?: string }) {
  return (
    <span className="flex items-center gap-2.5">
      <MicIcon className={iconSize} />
      <span className={`font-display ${textSize} tracking-wider text-white leading-none`}>
        NAZY <span className="text-primary">EMPIRE</span>
      </span>
    </span>
  );
}
