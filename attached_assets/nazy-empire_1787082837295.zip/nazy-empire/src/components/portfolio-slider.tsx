import { useEffect, useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { api, type PortfolioProject } from "@/lib/api";

export function PortfolioSlider({ limit }: { limit?: number }) {
  const [projects, setProjects] = useState<PortfolioProject[]>([]);
  const [current, setCurrent] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [direction, setDirection] = useState(1);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    api.portfolio
      .list()
      .then((data) => {
        // Newest-first, then apply optional cap
        const sorted = [...data].sort((a, b) => b.id - a.id);
        setProjects(limit ? sorted.slice(0, limit) : sorted);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, [limit]);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setDirection(1);
      setCurrent((c) => (c + 1) % Math.max(projects.length, 1));
    }, 5000);
  }, [projects.length]);

  useEffect(() => {
    if (projects.length > 1) {
      startTimer();
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [projects.length, startTimer]);

  function go(dir: number) {
    setDirection(dir);
    setCurrent((c) => (c + dir + projects.length) % projects.length);
    startTimer();
  }

  if (isLoading) {
    return (
      <div className="h-[480px] bg-zinc-900 rounded-2xl animate-pulse flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (projects.length === 0) return null;

  const project = projects[current];

  const variants = {
    enter: (d: number) => ({ x: d > 0 ? "100%" : "-100%", opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d: number) => ({ x: d > 0 ? "-100%" : "100%", opacity: 0 }),
  };

  return (
    <div className="relative overflow-hidden rounded-2xl group">
      <AnimatePresence mode="wait" custom={direction}>
        <motion.div
          key={project.id}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ type: "tween", duration: 0.5, ease: "easeInOut" }}
          className="relative"
        >
          {/* Image */}
          <div className="relative h-[520px] overflow-hidden rounded-2xl">
            <img
              src={project.imageUrl}
              alt={project.title}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80";
              }}
            />
            {/* Deep gradient so text is always legible */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />

            {/* Content */}
            <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className="max-w-2xl"
              >
                <span className="inline-block px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-primary text-xs font-semibold tracking-wide mb-4">
                  {project.category}
                </span>

                <h3 className="font-display text-2xl md:text-4xl text-white mb-3 leading-tight">
                  {project.title}
                </h3>

                <p className="text-white/75 text-sm md:text-base leading-relaxed mb-5">
                  {project.description}
                </p>

                {project.link ? (
                  <a
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-black text-sm font-bold rounded-lg hover:bg-primary/90 transition-colors"
                  >
                    Learn More <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                ) : (
                  <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/10 border border-white/20 text-white/40 text-sm font-bold rounded-lg cursor-not-allowed select-none">
                    Learn More <ExternalLink className="w-3.5 h-3.5" />
                  </span>
                )}
              </motion.div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation arrows */}
      {projects.length > 1 && (
        <>
          <button
            onClick={() => go(-1)}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 border border-white/10 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70 backdrop-blur-sm"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => go(1)}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 border border-white/10 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/70 backdrop-blur-sm"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Dot indicators */}
      {projects.length > 1 && (
        <div className="absolute bottom-4 right-6 flex gap-1.5">
          {projects.map((_, i) => (
            <button
              key={i}
              onClick={() => { setDirection(i > current ? 1 : -1); setCurrent(i); startTimer(); }}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === current ? "bg-primary w-6" : "bg-white/30 w-1.5 hover:bg-white/50"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
