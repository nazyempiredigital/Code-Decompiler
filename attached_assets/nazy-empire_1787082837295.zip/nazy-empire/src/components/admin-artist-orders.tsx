import { useState, useEffect, useRef } from "react";
import {
  Music2, Image as ImageIcon, Radio, ChevronRight, ArrowLeft,
  CheckCircle, Clock, AlertCircle, Loader2, Upload, Download,
  ExternalLink, XCircle, Search, Filter, User,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import type { ArtistOrder } from "@/lib/api";

const SERVICE_LABELS: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  mixing_mastering:  { label: "Mixing & Mastering",    icon: Music2,     color: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
  cover_art:         { label: "Cover Art",              icon: ImageIcon,  color: "text-amber-400 bg-amber-500/10 border-amber-500/20" },
  playlist_pitching: { label: "Playlist Pitching",      icon: Radio,      color: "text-green-400 bg-green-500/10 border-green-500/20" },
};

const ORDER_STATUS: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pending_payment: { label: "Awaiting Payment", color: "bg-orange-500/10 text-orange-400 border-orange-500/20", icon: Clock },
  paid:            { label: "Paid — In Queue",  color: "bg-blue-500/10 text-blue-400 border-blue-500/20",     icon: Clock },
  in_progress:     { label: "In Progress",       color: "bg-blue-500/10 text-blue-400 border-blue-500/20",     icon: Loader2 },
  confirmed:       { label: "Confirmed",          color: "bg-green-500/10 text-green-400 border-green-500/20", icon: CheckCircle },
  delivered:       { label: "Delivered",          color: "bg-primary/10 text-primary border-primary/20",       icon: CheckCircle },
};

const VALID_STATUSES = [
  { value: "pending_payment", label: "Awaiting Payment" },
  { value: "paid",            label: "Paid — In Queue" },
  { value: "in_progress",     label: "In Progress" },
  { value: "confirmed",       label: "Confirmed" },
  { value: "delivered",       label: "Delivered" },
];

function fmt(n: number | string) {
  return "₦" + parseFloat(String(n)).toLocaleString("en-NG");
}

// ─── Order List Row ───────────────────────────────────────────────────────────

function OrderRow({ order, onClick }: { order: ArtistOrder; onClick: () => void }) {
  const svc = SERVICE_LABELS[order.serviceType];
  const status = ORDER_STATUS[order.status] ?? ORDER_STATUS.pending_payment;
  const StatusIcon = status.icon;
  const Icon = svc?.icon ?? Music2;

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all group flex items-center gap-4"
    >
      <div className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${svc?.color ?? "bg-white/5"}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-white font-medium text-sm truncate">{svc?.label}</span>
          <span className={`shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium ${status.color}`}>
            <StatusIcon className="w-3 h-3" />{status.label}
          </span>
        </div>
        <div className="flex items-center gap-3 text-xs text-white/40">
          <span className="font-mono">{order.orderId}</span>
          <span>·</span>
          <span className="flex items-center gap-1"><User className="w-3 h-3" />{order.artistName}</span>
          <span>·</span>
          <span>{new Date(order.createdAt).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })}</span>
        </div>
      </div>
      {order.paymentStatus === "unpaid" && (
        <span className="text-orange-400 text-xs font-medium shrink-0">Unpaid</span>
      )}
      <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-colors shrink-0" />
    </button>
  );
}

// ─── Order Detail ─────────────────────────────────────────────────────────────

function AdminOrderDetail({ order: initialOrder, onBack, onUpdate }: {
  order: ArtistOrder;
  onBack: () => void;
  onUpdate: (o: ArtistOrder) => void;
}) {
  const [order, setOrder] = useState(initialOrder);
  const [status, setStatus] = useState(order.status);
  const [adminNotes, setAdminNotes] = useState(order.adminNotes ?? "");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [confirmingPayment, setConfirmingPayment] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const svc = SERVICE_LABELS[order.serviceType];
  const statusInfo = ORDER_STATUS[order.status] ?? ORDER_STATUS.pending_payment;
  const StatusIcon = statusInfo.icon;
  const fd = order.formData as Record<string, unknown>;

  // Playlist pitching: can only confirm or deliver (no file upload needed)
  const isPlaylist = order.serviceType === "playlist_pitching";
  const needsFile = !isPlaylist;

  async function saveStatus() {
    setSaving(true);
    setError(null);
    try {
      const updated = await api.artistOrders.adminUpdateStatus(order.id, { status, adminNotes });
      setOrder(updated);
      onUpdate(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save");
    }
    setSaving(false);
  }

  async function confirmPayment() {
    setConfirmingPayment(true);
    try {
      const updated = await api.artistOrders.adminConfirmPayment(order.id);
      setOrder(updated);
      setStatus(updated.status);
      onUpdate(updated);
    } catch {}
    setConfirmingPayment(false);
  }

  async function handleResultUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const result = await api.artistOrders.adminUploadResult(order.id, file);
      setOrder(result.order);
      onUpdate(result.order);
    } catch {
      setError("Upload failed. Please try again.");
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-1.5 text-white/50 hover:text-white text-sm mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Orders
      </button>

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Main column */}
        <div className="lg:col-span-2 space-y-5">
          {/* Header */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-start gap-4">
              {svc && (
                <div className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${svc.color}`}>
                  <svc.icon className="w-5 h-5" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h2 className="text-white font-bold text-lg">{svc?.label}</h2>
                <p className="text-white/40 text-xs font-mono mt-0.5">{order.orderId}</p>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-medium ${statusInfo.color}`}>
                    <StatusIcon className="w-3.5 h-3.5" />{statusInfo.label}
                  </span>
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-medium ${
                    order.paymentStatus === "paid"
                      ? "bg-green-500/10 text-green-400 border-green-500/20"
                      : "bg-orange-500/10 text-orange-400 border-orange-500/20"
                  }`}>
                    {order.paymentStatus === "paid" ? "✓ Paid" : "⚠ Unpaid"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Artist Files */}
          {(order.artistFiles?.length ?? 0) > 0 && (
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="text-white font-semibold text-sm mb-3 uppercase tracking-wider">Files from Artist</h3>
              <div className="space-y-2">
                {order.artistFiles!.map((url, i) => (
                  <a
                    key={i}
                    href={url}
                    target="_blank"
                    rel="noreferrer"
                    download
                    className="flex items-center gap-3 p-3 rounded-lg bg-white/3 hover:bg-white/6 border border-white/8 hover:border-white/15 transition-all group"
                  >
                    <Download className="w-4 h-4 text-primary/60 group-hover:text-primary shrink-0 transition-colors" />
                    <span className="text-white/70 text-sm truncate flex-1 group-hover:text-white transition-colors">
                      {url.split("/").pop()}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-white/20 group-hover:text-white/50 shrink-0 transition-colors" />
                  </a>
                ))}
              </div>
              {order.serviceType === "mixing_mastering" && (fd.stemsLink as string) && (
                <div className="mt-3 pt-3 border-t border-white/8">
                  <p className="text-white/40 text-xs mb-1">Stems Link</p>
                  <a href={fd.stemsLink as string} target="_blank" rel="noreferrer" className="text-primary/70 hover:text-primary text-sm transition-colors break-all">
                    {fd.stemsLink as string}
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Stems link (even if no uploaded files) */}
          {order.serviceType === "mixing_mastering" && (fd.stemsLink as string) && (order.artistFiles?.length ?? 0) === 0 && (
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="text-white font-semibold text-sm mb-2 uppercase tracking-wider">Stems / Files</h3>
              <p className="text-white/40 text-xs mb-1">Google Drive / WeTransfer Link</p>
              <a href={fd.stemsLink as string} target="_blank" rel="noreferrer" className="text-primary/70 hover:text-primary text-sm transition-colors break-all">
                {fd.stemsLink as string}
              </a>
            </div>
          )}

          {/* Result files */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Result Files</h3>
              {!isPlaylist && (
                <>
                  <input ref={fileRef} type="file" className="hidden" onChange={handleResultUpload} />
                  <Button
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    size="sm"
                    className="bg-primary text-black hover:bg-primary/90 font-bold"
                  >
                    {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <Upload className="w-3.5 h-3.5 mr-1" />}
                    Upload Result
                  </Button>
                </>
              )}
            </div>

            {(order.resultFiles?.length ?? 0) === 0 ? (
              <p className="text-white/30 text-sm">
                {isPlaylist ? "No files needed for playlist pitching." : "No result files uploaded yet."}
              </p>
            ) : (
              <div className="space-y-2">
                {order.resultFiles!.map((url, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-white/3 border border-white/8">
                    <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />
                    <span className="text-white/70 text-sm truncate flex-1">{url.split("/").pop()}</span>
                    <a href={url} target="_blank" rel="noreferrer" className="text-white/30 hover:text-white transition-colors">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            )}

            {order.firstDownloadAt && (
              <p className="mt-3 text-white/30 text-xs">
                First downloaded by artist: {new Date(order.firstDownloadAt).toLocaleString("en-NG")}
              </p>
            )}
          </div>

          {/* Submission Details */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="text-white font-semibold text-sm mb-4 uppercase tracking-wider">Submission Details</h3>
            <div className="space-y-2.5">
              {Object.entries(fd)
                .filter(([k]) => k !== "checklist" && k !== "referenceFiles" && k !== "demoMixUrl")
                .map(([k, v]) => (
                  <div key={k} className="grid grid-cols-2 gap-2 text-sm">
                    <span className="text-white/40 capitalize">{k.replace(/([A-Z])/g, " $1").trim()}</span>
                    <span className="text-white/80 break-words">{Array.isArray(v) ? v.join(", ") : String(v ?? "—")}</span>
                  </div>
                ))}
              {fd.checklist && typeof fd.checklist === "object" && (
                <div className="pt-3 border-t border-white/8">
                  <span className="text-white/40 text-sm block mb-2">Upload Checklist</span>
                  <div className="space-y-1">
                    {Object.entries(fd.checklist as Record<string, boolean>).map(([k, v]) => (
                      <div key={k} className="flex items-center gap-2 text-sm">
                        {v
                          ? <CheckCircle className="w-3.5 h-3.5 text-green-400 shrink-0" />
                          : <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                        }
                        <span className={v ? "text-white/70" : "text-white/30"}>{k.replace(/([A-Z])/g, " $1").trim()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar: Admin Actions */}
        <div className="space-y-5">
          {/* Artist info */}
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="text-white font-semibold text-sm mb-3 uppercase tracking-wider">Artist</h3>
            <p className="text-white font-medium">{order.artistName}</p>
            <p className="text-white/50 text-sm mt-0.5">{order.artistEmail}</p>
            <p className="text-white/30 text-xs mt-2 font-mono">{order.orderId}</p>
            <p className="text-white/30 text-xs mt-1">
              Submitted {new Date(order.createdAt).toLocaleDateString("en-NG", { day: "numeric", month: "long", year: "numeric" })}
            </p>
          </div>

          {/* Confirm payment (if unpaid) */}
          {order.paymentStatus === "unpaid" && (
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-5 space-y-3">
              <p className="text-orange-400 font-semibold text-sm">Payment Not Yet Confirmed</p>
              <p className="text-orange-400/70 text-xs leading-relaxed">
                If you've received payment outside of Paystack (e.g. bank transfer), confirm it manually here.
              </p>
              <Button
                onClick={confirmPayment}
                disabled={confirmingPayment}
                className="w-full bg-orange-500 hover:bg-orange-400 text-black font-bold"
              >
                {confirmingPayment ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                Confirm Payment
              </Button>
            </div>
          )}

          {/* Status update */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider">Update Order</h3>

            <div className="space-y-1.5">
              <label className="text-white/50 text-xs uppercase tracking-wider">Status</label>
              <div className="relative">
                <select
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/60 appearance-none cursor-pointer"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                >
                  {VALID_STATUSES.map((s) => (
                    <option key={s.value} value={s.value} className="bg-[#111]">{s.label}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-white/30">▾</div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-white/50 text-xs uppercase tracking-wider">Notes to Artist</label>
              <textarea
                rows={4}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/60 resize-none placeholder:text-white/25"
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                placeholder="Optional message visible to the artist..."
              />
            </div>

            {error && <p className="text-red-400 text-xs">{error}</p>}
            {saveSuccess && <p className="text-green-400 text-xs">✓ Saved successfully</p>}

            <Button onClick={saveStatus} disabled={saving} className="w-full bg-primary text-black hover:bg-primary/90 font-bold">
              {saving ? <><Loader2 className="w-4 h-4 animate-spin mr-1" /> Saving...</> : "Save Changes"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Admin Artist Orders Component ──────────────────────────────────────

export function AdminArtistOrders() {
  const [orders, setOrders] = useState<ArtistOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<ArtistOrder | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [serviceFilter, setServiceFilter] = useState("all");
  const [search, setSearch] = useState("");

  useEffect(() => { loadOrders(); }, []);

  async function loadOrders() {
    setLoading(true);
    try { setOrders(await api.artistOrders.adminList()); } catch {}
    setLoading(false);
  }

  const filtered = orders.filter((o) => {
    if (statusFilter !== "all" && o.status !== statusFilter) return false;
    if (serviceFilter !== "all" && o.serviceType !== serviceFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!o.orderId.toLowerCase().includes(q) &&
          !o.artistName.toLowerCase().includes(q) &&
          !o.artistEmail.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  // Summary counts
  const counts = {
    pending_payment: orders.filter((o) => o.status === "pending_payment").length,
    paid: orders.filter((o) => o.status === "paid").length,
    in_progress: orders.filter((o) => o.status === "in_progress").length,
    confirmed: orders.filter((o) => o.status === "confirmed").length,
    delivered: orders.filter((o) => o.status === "delivered").length,
  };

  if (selectedOrder) {
    return (
      <AdminOrderDetail
        order={selectedOrder}
        onBack={() => setSelectedOrder(null)}
        onUpdate={(updated) => {
          setSelectedOrder(updated);
          setOrders((prev) => prev.map((o) => o.id === updated.id ? updated : o));
        }}
      />
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-4xl text-white">ARTIST ORDERS</h1>
        <Button onClick={loadOrders} variant="outline" size="sm" className="border-border text-white/50 hover:text-white">
          Refresh
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        {[
          { label: "Awaiting Payment", value: counts.pending_payment, color: "text-orange-400" },
          { label: "Paid / In Queue",  value: counts.paid,            color: "text-blue-400" },
          { label: "In Progress",      value: counts.in_progress,     color: "text-blue-400" },
          { label: "Confirmed",        value: counts.confirmed,        color: "text-green-400" },
          { label: "Delivered",        value: counts.delivered,        color: "text-primary" },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-card border border-border rounded-xl p-3 text-center">
            <p className={`text-xl font-bold ${color}`}>{value}</p>
            <p className="text-white/40 text-xs mt-0.5 leading-tight">{label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <input
            className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/60 placeholder:text-white/25"
            placeholder="Search by order ID or artist..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="relative">
          <select
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm appearance-none cursor-pointer focus:outline-none pr-8"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all" className="bg-[#111]">All Statuses</option>
            {VALID_STATUSES.map((s) => <option key={s.value} value={s.value} className="bg-[#111]">{s.label}</option>)}
          </select>
          <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-white/30">▾</div>
        </div>
        <div className="relative">
          <select
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm appearance-none cursor-pointer focus:outline-none pr-8"
            value={serviceFilter}
            onChange={(e) => setServiceFilter(e.target.value)}
          >
            <option value="all" className="bg-[#111]">All Services</option>
            <option value="mixing_mastering" className="bg-[#111]">Mixing & Mastering</option>
            <option value="cover_art" className="bg-[#111]">Cover Art</option>
            <option value="playlist_pitching" className="bg-[#111]">Playlist Pitching</option>
          </select>
          <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-white/30">▾</div>
        </div>
      </div>

      {/* Order list */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-6 h-6 text-white/30 animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-white/30">
          <Music2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p>{orders.length === 0 ? "No artist service orders yet." : "No orders match your filters."}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((o) => (
            <OrderRow key={o.id} order={o} onClick={() => setSelectedOrder(o)} />
          ))}
        </div>
      )}
    </div>
  );
}
