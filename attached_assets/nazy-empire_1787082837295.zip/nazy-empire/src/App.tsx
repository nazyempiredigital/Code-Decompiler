import { Switch, Route, useLocation } from "wouter";
import { useEffect } from "react";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { AuthProvider } from "@/lib/auth";
import { ErrorBoundary } from "@/components/error-boundary";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import Home from "@/pages/home";
import WebDevelopment from "@/pages/web-development";
import Domains from "@/pages/domains";
import Hosting from "@/pages/hosting";
import MusicDistribution from "@/pages/music-distribution";
import Contact from "@/pages/contact";
import About from "@/pages/about";
import Terms from "@/pages/terms";
import Privacy from "@/pages/privacy";
import TermsOfSale from "@/pages/terms-of-sale";
import CookiePolicy from "@/pages/cookie-policy";
import DMCA from "@/pages/dmca";
import Accessibility from "@/pages/accessibility";
import Login from "@/pages/login";
import Signup from "@/pages/signup";
import Order from "@/pages/order";
import Dashboard from "@/pages/dashboard";
import Admin from "@/pages/admin";
import ArtistDashboard from "@/pages/artist-dashboard";
import ApplyArtist from "@/pages/apply-artist";
import ThankYou from "@/pages/thank-you";
import Services from "@/pages/services";
import Ecosystem from "@/pages/ecosystem";
import Projects from "@/pages/projects";
import FAQ from "@/pages/faq";
import Blog from "@/pages/blog";
import BlogPost from "@/pages/blog-post";
import Affiliate from "@/pages/affiliate";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [location]);
  return null;
}

function AppShell() {
  return (
    <>
      <ScrollToTop />
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/order" component={Order} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/admin" component={Admin} />
        <Route path="/artist-dashboard" component={ArtistDashboard} />
        <Route path="/apply-artist" component={ApplyArtist} />
        <Route path="/thank-you" component={ThankYou} />
        <Route>
          {() => (
            <>
              <Navbar />
              <main>
                <Switch>
                  <Route path="/" component={Home} />
                  <Route path="/web-development" component={WebDevelopment} />
                  <Route path="/domains" component={Domains} />
                  <Route path="/hosting" component={Hosting} />
                  <Route path="/music-distribution" component={MusicDistribution} />
                  <Route path="/services" component={Services} />
                  <Route path="/contact" component={Contact} />
                  <Route path="/about" component={About} />
                  <Route path="/terms" component={Terms} />
                  <Route path="/privacy" component={Privacy} />
                  <Route path="/terms-of-sale" component={TermsOfSale} />
                  <Route path="/cookie-policy" component={CookiePolicy} />
                  <Route path="/dmca" component={DMCA} />
                  <Route path="/accessibility" component={Accessibility} />
                  <Route path="/ecosystem" component={Ecosystem} />
                  <Route path="/projects" component={Projects} />
                  <Route path="/faq" component={FAQ} />
                  <Route path="/blog" component={Blog} />
                  <Route path="/blog/:slug" component={BlogPost} />
                  <Route path="/affiliate" component={Affiliate} />
                  <Route component={NotFound} />
                </Switch>
              </main>
              <Footer />
            </>
          )}
        </Route>
      </Switch>
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <AppShell />
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
