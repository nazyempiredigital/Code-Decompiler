import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Globe, Shield, Search, ArrowRight } from "lucide-react";

const TLDS = [
  { tld: ".com",    price: "₦16,067.31/yr" },
  { tld: ".ng",     price: "₦9,855.27/yr"  },
  { tld: ".net",    price: "₦31,065.53/yr" },
  { tld: ".com.ng", price: "₦3,213.68/yr"  },
  { tld: ".edu.ng", price: "₦16,711.11/yr" },
  { tld: ".org",    price: "₦18,103.70/yr" },
  { tld: ".biz",    price: "₦51,472.36/yr" },
  { tld: ".xyz",    price: "₦36,957.26/yr" },
];

export default function Domains() {
  return (
    <div className="pt-16">
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24 text-center">
        <div className="container mx-auto px-4">
          <Globe className="w-16 h-16 text-primary mx-auto mb-6" />
          <h1 className="font-display text-6xl md:text-7xl text-white mb-4">DOMAIN REGISTRATION</h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Secure your brand's online identity. Register your domain today and build your digital empire.
          </p>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-12">POPULAR EXTENSIONS</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
            {TLDS.map((t, i) => (
              <motion.div
                key={t.tld}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="bg-card border border-border rounded-xl p-4 text-center hover:border-primary/40 transition-colors"
              >
                <div className="font-display text-3xl text-primary mb-1">{t.tld}</div>
                <div className="text-white/50 text-sm">{t.price}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { icon: Search, title: "Instant Availability Check", description: "Search millions of domain names in seconds." },
              { icon: Shield, title: "WHOIS Privacy", description: "Keep your personal information private with free WHOIS privacy protection." },
              { icon: Globe, title: "Easy Management", description: "Manage all your domains from a simple, intuitive dashboard." },
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-card border border-border rounded-xl p-6 text-center"
                >
                  <Icon className="w-8 h-8 text-primary mx-auto mb-4" />
                  <h3 className="text-white font-semibold mb-2">{f.title}</h3>
                  <p className="text-white/50 text-sm">{f.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary/5 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-5xl text-white mb-4">REGISTER YOUR DOMAIN</h2>
          <p className="text-white/50 mb-8">Include domain registration with your website order, or contact us to register a domain standalone.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/order">
              <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold">
                Order Website + Domain <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
