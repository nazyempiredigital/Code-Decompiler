import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Globe, Music, Upload, List, DollarSign, BarChart2,
  CheckCircle, Clock, AlertCircle, XCircle, Send, Plus, ArrowRight,
  Pencil, Trash2, AlertTriangle, ChevronRight, Image as ImageIcon,
  Settings2, Eye, Mic2, Users, FileMusic, Play, Pause,
  LifeBuoy, MessageCircle, ArrowLeft, Tag, Wallet, Building2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { AuthModal } from "@/components/auth-modal";
import { NotificationBell } from "@/components/notification-bell";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { BrandLockup } from "@/components/mic-logo";
import { ArtistReleaseDetail } from "@/components/artist-release-detail";
import { PayoutMethodForm } from "@/components/payout-method-form";
import { PaymentRequestForm } from "@/components/payment-request-form";
import { ArtistServices } from "@/components/artist-services";
import { api, type Release, type TrackInfo, type ArtistAnalytics, type ArtistEarnings, type PayoutMethod, type ArtistPaymentRequest, type SupportTicket, type TicketMessage } from "@/lib/api";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

type ArtistTab = "releases" | "upload" | "earnings" | "analytics" | "support" | "services";
type UploadStep = 1 | 2 | 3 | 4 | 5;

interface FormTrackInfo extends TrackInfo {
  aiMaterials: string;
  isAlternativeVersion: boolean;
  trackFeaturedArtists: string;
  trackLyrics: string;
  trackLanguage: string;
  explicitOption: string;
  audioFile?: File | null;
  audioUploading?: boolean;
  audioError?: string;
}

// Accepted audio formats and size limit for release audio uploads
const ACCEPTED_AUDIO_EXTENSIONS = [".wav", ".flac", ".mp3"];
const MAX_AUDIO_SIZE_BYTES = 200 * 1024 * 1024; // 200 MB

function validateAudioFile(file: File): string | null {
  const ext = "." + (file.name.split(".").pop() ?? "").toLowerCase();
  if (!ACCEPTED_AUDIO_EXTENSIONS.includes(ext)) {
    return "Unsupported format. Please upload a WAV, FLAC, or MP3 file.";
  }
  if (file.size > MAX_AUDIO_SIZE_BYTES) {
    return "File too large. Maximum size is 200 MB.";
  }
  return null;
}

// Strips form-only fields from a track before sending it to the API.
function buildTrackPayload(tracks: FormTrackInfo[]): TrackInfo[] {
  return tracks.map((t) => {
    const { audioFile, audioUploading, audioError, aiMaterials, isAlternativeVersion, trackLyrics, trackLanguage, explicitOption, ...rest } = t;
    return rest as TrackInfo;
  });
}

// ── Upload progress persistence ─────────────────────────────────────────────
// Remembers which wizard step an artist last reached on a given (draft) release,
// so re-opening it — after a refresh, closed tab, or navigating away — resumes
// where they left off instead of forcing them back to step 1. Keyed per user
// since a browser may be shared, scoped to localStorage since it's purely a
// same-browser convenience layer on top of the real autosaved draft in the DB.
function stepMapKey(userId: number) {
  return `nazy_upload_step_map_${userId}`;
}
function getStepForRelease(userId: number, releaseId: number): UploadStep | null {
  try {
    const raw = localStorage.getItem(stepMapKey(userId));
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, UploadStep>;
    return map[releaseId] ?? null;
  } catch {
    return null;
  }
}
function setStepForRelease(userId: number, releaseId: number, step: UploadStep) {
  try {
    const raw = localStorage.getItem(stepMapKey(userId));
    const map = raw ? (JSON.parse(raw) as Record<string, UploadStep>) : {};
    map[releaseId] = step;
    localStorage.setItem(stepMapKey(userId), JSON.stringify(map));
  } catch {
    // best-effort only
  }
}
function clearStepForRelease(userId: number, releaseId: number) {
  try {
    const raw = localStorage.getItem(stepMapKey(userId));
    if (!raw) return;
    const map = JSON.parse(raw) as Record<string, UploadStep>;
    delete map[releaseId];
    localStorage.setItem(stepMapKey(userId), JSON.stringify(map));
  } catch {
    // best-effort only
  }
}

const GENRES = ["Afrobeats","Afropop","Amapiano","Highlife","Afro-Soul","Afro-Fusion","Hip Hop","R&B","Gospel","Trap","Reggae","Dancehall","Pop","Jazz","Classical","Alternative","Electronic","Folk","Neo-Soul","Other"];
const SECONDARY_GENRES = ["", "Alternative","Ambient","Blues","Classical","Contemporary","Electronic","Folk","Funk","Gospel","Indie","Jazz","Lo-Fi","Neo-Soul","New Age","Opera","Spoken Word","World Music","Other"];
const LANGUAGES = ["English","Yoruba","Igbo","Hausa","Pidgin","French","Portuguese","Swahili","Arabic","Spanish","Other"];
const TIMEZONES = ["(GMT+0) UTC / London","(GMT+1) West Africa Time","(GMT+2) Central Africa Time","(GMT+3) East Africa Time","(GMT+1) Central European Time","(GMT+2) Eastern European Time","(GMT-5) Eastern Time (US)","(GMT-6) Central Time (US)","(GMT-8) Pacific Time (US)","(GMT+5:30) India Standard Time","(GMT+8) China Standard Time"];
const PRICING_OPTIONS = ["HIGH","STANDARD","LOW","FREE"];
const AI_MATERIALS_OPTIONS = ["No AI — entirely human-created","AI-assisted lyrics","AI-assisted composition","AI-assisted vocal performance","AI-generated music (with human creative direction)","Fully AI-generated"];
const ALL_STORES = [
  "Spotify","Apple Music, iTunes","YouTube Music","Amazon Music","Tidal Music","Deezer",
  "SoundCloud","Boomplay","Anghami","KKBOX","JioSaavn (previously Saavn)",
  "Pandora (DSP)","iHeart Radio","Snap","NetEase Cloud Music","QQ Music","KuGou","JOOX",
  "VK Music","Yandex.Music","ACR Cloud","MediaNet","Taobao","Trebel Music","Peloton",
  "Soundtrack Your Brand","Kuaishou","Audible Magic","WeSing","Zvuk","FLO (DSP)","ROXI",
];

const ALL_COUNTRIES = [
  // Africa
  "Algeria","Angola","Benin","Botswana","Burkina Faso","Burundi","Cabo Verde","Cameroon",
  "Central African Republic","Chad","Comoros","Congo","DR Congo","Djibouti","Egypt",
  "Equatorial Guinea","Eritrea","Eswatini","Ethiopia","Gabon","Gambia","Ghana","Guinea",
  "Guinea-Bissau","Ivory Coast","Kenya","Lesotho","Liberia","Libya","Madagascar","Malawi",
  "Mali","Mauritania","Mauritius","Morocco","Mozambique","Namibia","Niger","Nigeria",
  "Rwanda","São Tomé & Príncipe","Senegal","Seychelles","Sierra Leone","Somalia",
  "South Africa","South Sudan","Sudan","Tanzania","Togo","Tunisia","Uganda","Zambia","Zimbabwe",
  // Americas
  "Antigua & Barbuda","Argentina","Bahamas","Barbados","Belize","Bolivia","Brazil","Canada",
  "Chile","Colombia","Costa Rica","Cuba","Dominica","Dominican Republic","Ecuador",
  "El Salvador","Grenada","Guatemala","Guyana","Haiti","Honduras","Jamaica","Mexico",
  "Nicaragua","Panama","Paraguay","Peru","Saint Kitts & Nevis","Saint Lucia",
  "Saint Vincent & the Grenadines","Suriname","Trinidad & Tobago","United States","Uruguay",
  "Venezuela",
  // Asia
  "Afghanistan","Armenia","Azerbaijan","Bahrain","Bangladesh","Bhutan","Brunei","Cambodia",
  "China","Cyprus","Georgia","India","Indonesia","Iran","Iraq","Israel","Japan","Jordan",
  "Kazakhstan","Kuwait","Kyrgyzstan","Laos","Lebanon","Malaysia","Maldives","Mongolia",
  "Myanmar","Nepal","North Korea","Oman","Pakistan","Palestine","Philippines","Qatar",
  "Saudi Arabia","Singapore","Sri Lanka","Syria","Taiwan","Tajikistan","Thailand",
  "Timor-Leste","Turkey","Turkmenistan","United Arab Emirates","Uzbekistan","Vietnam","Yemen",
  // Europe
  "Albania","Andorra","Austria","Belarus","Belgium","Bosnia & Herzegovina","Bulgaria",
  "Croatia","Czech Republic","Denmark","Estonia","Finland","France","Germany","Greece",
  "Hungary","Iceland","Ireland","Italy","Kosovo","Latvia","Liechtenstein","Lithuania",
  "Luxembourg","Malta","Moldova","Monaco","Montenegro","Netherlands","North Macedonia",
  "Norway","Poland","Portugal","Romania","Russia","San Marino","Serbia","Slovakia",
  "Slovenia","Spain","Sweden","Switzerland","Ukraine","United Kingdom","Vatican City",
  // Oceania
  "Australia","Fiji","Kiribati","Marshall Islands","Micronesia","Nauru","New Zealand",
  "Palau","Papua New Guinea","Samoa","Solomon Islands","Tonga","Tuvalu","Vanuatu",
  // Territories & Regions
  "American Samoa","Anguilla","Aruba","Bermuda","Bonaire","British Virgin Islands",
  "Cayman Islands","Christmas Island","Cocos (Keeling) Islands","Cook Islands","Curaçao",
  "Faroe Islands","Falkland Islands","French Guiana","French Polynesia","Gibraltar",
  "Greenland","Guadeloupe","Guam","Guernsey","Hong Kong","Isle of Man","Jersey",
  "Macau","Martinique","Mayotte","Montserrat","New Caledonia","Niue","Norfolk Island",
  "Northern Mariana Islands","Puerto Rico","Réunion","Sint Maarten","Saint Helena",
  "South Georgia","Tokelau","Turks & Caicos Islands","US Virgin Islands",
].sort();

const STATUS_MAP: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  draft:             { label: "Draft",             color: "bg-white/10 text-white/50 border-white/10",            icon: Clock },
  pending_review:    { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20", icon: Clock },
  changes_requested: { label: "Changes Requested", color: "bg-orange-500/10 text-orange-400 border-orange-500/20", icon: AlertCircle },
  approved:          { label: "Approved",          color: "bg-blue-500/10 text-blue-400 border-blue-500/20",       icon: CheckCircle },
  rejected:          { label: "Rejected",          color: "bg-red-500/10 text-red-400 border-red-500/20",          icon: XCircle },
  live:              { label: "Live",              color: "bg-green-500/10 text-green-400 border-green-500/20",    icon: CheckCircle },
};

const BLANK_TRACK: FormTrackInfo = {
  title: "", version: "", isrc: "", explicitContent: false,
  aiMaterials: "", isAlternativeVersion: false, trackFeaturedArtists: "",
  trackLyrics: "", trackLanguage: "English", explicitOption: "", audioFile: null,
  audioUrl: undefined, audioUploading: false, audioError: "",
};

const BLANK_FORM = {
  releaseType: "single" as "single" | "ep" | "album",
  releaseTitle: "",
  title: "", version: "",
  isVariousArtists: false,
  mainArtists: "", featuredArtists: "",
  genre: "", secondaryGenre: "", language: "English",
  label: "",
  copyright: "", copyrightRecordingYear: "",
  hasOwnUpc: false, upc: "", isrc: "", explicitContent: false,
  releaseDate: "", originalReleaseDate: "", hasOriginalReleaseDate: false,
  releaseTime: "00:00", releaseTimezone: "(GMT+1) West Africa Time",
  preOrder: false, noPreviewsDuringPreOrder: false,
  pricing: "HIGH",
  territory: "worldwide", stores: [] as string[], selectedCountries: [] as string[],
  lyrics: "",
  publisher: "", composer: "", songwriter: "", producer: "",
  tracks: [{ ...BLANK_TRACK }] as FormTrackInfo[],
};

// ── Shared field components ───────────────────────────────────────────────────

function Field({ label, hint, required, children }: { label: string; hint?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label className="block text-sm font-medium text-white/70">
        {label} {required && <span className="text-primary">*</span>}
      </label>
      {hint && <p className="text-xs text-white/35 leading-relaxed">{hint}</p>}
      {children}
    </div>
  );
}

const inputCls = "w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:border-primary/40 placeholder:text-white/25 transition-colors";
const selectCls = `${inputCls} appearance-none cursor-pointer`;

function TextInput({ value, onChange, placeholder, type = "text" }: { value: string; onChange: (v: string) => void; placeholder?: string; type?: string }) {
  return <input type={type} className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />;
}

function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) {
  return (
    <div className="relative">
      <select className={selectCls} value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => <option key={o.value} value={o.value} className="bg-[#111]">{o.label}</option>)}
      </select>
      <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-white/30">▾</div>
    </div>
  );
}

function Check({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-start gap-2.5 cursor-pointer group">
      <div
        onClick={() => onChange(!checked)}
        className={`mt-0.5 w-4 h-4 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${checked ? "bg-primary border-primary" : "border-white/30 group-hover:border-white/50"}`}
      >
        {checked && <svg className="w-2.5 h-2.5 text-black" fill="currentColor" viewBox="0 0 12 10"><path d="M1 5l4 4 6-8" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
      </div>
      <span className="text-white/60 text-sm leading-snug">{label}</span>
    </label>
  );
}

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="bg-white/3 border-b border-white/8 px-6 py-4 rounded-t-xl">
      <h3 className="text-white font-semibold text-sm uppercase tracking-wider">{title}</h3>
      {subtitle && <p className="text-white/40 text-xs mt-0.5">{subtitle}</p>}
    </div>
  );
}

// ── Step Wizard Header ────────────────────────────────────────────────────────

const STEPS = [
  { id: 1, key: "album-info",    label: "Album Info",              icon: Music },
  { id: 2, key: "track-upload",  label: "Track Upload",            icon: FileMusic },
  { id: 3, key: "album-art",     label: "Album Art",               icon: ImageIcon },
  { id: 4, key: "distribution",  label: "Distribution Preferences",icon: Settings2 },
  { id: 5, key: "preview",       label: "Preview / Distribute",    icon: Eye },
];

function StepWizard({ currentStep, onStep }: { currentStep: UploadStep; onStep: (s: UploadStep) => void }) {
  return (
    <div className="flex items-center overflow-x-auto pb-1 gap-0">
      {STEPS.map((step, i) => {
        const done = currentStep > step.id;
        const active = currentStep === step.id;
        return (
          <div key={step.id} className="flex items-center shrink-0">
            <button
              onClick={() => done ? onStep(step.id as UploadStep) : undefined}
              disabled={!done && !active}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors text-center ${
                active ? "text-primary" : done ? "text-white/60 hover:text-white cursor-pointer" : "text-white/25"
              }`}
            >
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
                done ? "bg-primary/20 border-primary text-primary" :
                active ? "bg-primary border-primary text-black" :
                "border-white/15 text-white/25"
              }`}>
                {done ? <CheckCircle className="w-3.5 h-3.5" /> : step.id}
              </div>
              <span className={`text-[10px] font-semibold uppercase tracking-wide whitespace-nowrap ${active ? "text-primary" : done ? "text-white/50" : "text-white/20"}`}>
                {step.label}
              </span>
            </button>
            {i < STEPS.length - 1 && (
              <div className={`h-px w-6 mx-1 transition-colors ${done ? "bg-primary/40" : "bg-white/10"}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Step 1: Album Info ────────────────────────────────────────────────────────

function Step1AlbumInfo({ form, setF, lockedUpc }: { form: typeof BLANK_FORM; setF: (k: string, v: unknown) => void; lockedUpc?: string }) {
  const year = new Date().getFullYear();
  const artistName = form.mainArtists.split(",")[0]?.trim() || "Your Name";
  const copyrightPlaceholder = `${year} ${artistName}`;

  return (
    <div className="space-y-6">
      {/* Release Type */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Release Type" />
        <div className="p-6">
          <div className="grid grid-cols-3 gap-3">
            {(["single", "ep", "album"] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setF("releaseType", t)}
                className={`py-3 rounded-xl text-sm font-bold border-2 capitalize transition-all ${
                  form.releaseType === t
                    ? "bg-primary/10 border-primary text-primary"
                    : "border-white/10 text-white/40 hover:border-white/30 hover:text-white"
                }`}
              >
                {t === "single" ? "Single" : t === "ep" ? "EP" : "Album"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Metadata */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Metadata" subtitle="Original release information — all fields required unless noted otherwise" />
        <div className="p-6 space-y-5">
          <Field label={form.releaseType === "single" ? "Title of a Single" : `Title of ${form.releaseType === "ep" ? "an EP" : "an Album"}`} required>
            <TextInput
              value={form.releaseType === "single" ? form.title : form.releaseTitle}
              onChange={(v) => setF(form.releaseType === "single" ? "title" : "releaseTitle", v)}
              placeholder={form.releaseType === "single" ? "Official song title" : `Enter ${form.releaseType} title`}
            />
          </Field>

          <Check
            checked={form.isVariousArtists}
            onChange={(v) => setF("isVariousArtists", v)}
            label="Various Artists — select if this is a compilation with 5 or more different main artists"
          />

          {!form.isVariousArtists && (
            <Field label="Primary Artist or Band Name" required hint="This artist will appear on every track. Use comma-separated names for multiple primary artists.">
              <TextInput
                value={form.mainArtists}
                onChange={(v) => setF("mainArtists", v)}
                placeholder="e.g. Hestrova"
              />
            </Field>
          )}

          {form.releaseType === "single" && (
            <Field label="Featured Artists" hint="Optional — comma-separated names of featured artists for this single">
              <TextInput
                value={form.featuredArtists}
                onChange={(v) => setF("featuredArtists", v)}
                placeholder="Artist Name, Another Artist"
              />
            </Field>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Main Genre" required>
              <Select
                value={form.genre}
                onChange={(v) => setF("genre", v)}
                options={[{ value: "", label: "Select Genre" }, ...GENRES.map((g) => ({ value: g, label: g }))]}
              />
            </Field>
            <Field label="Secondary Genre">
              <Select
                value={form.secondaryGenre}
                onChange={(v) => setF("secondaryGenre", v)}
                options={[{ value: "", label: "Select Secondary Genre" }, ...SECONDARY_GENRES.filter(Boolean).map((g) => ({ value: g, label: g }))]}
              />
            </Field>
          </div>

          <Field label="Language" hint="Language of the album, album title, and track titles" required>
            <Select
              value={form.language}
              onChange={(v) => setF("language", v)}
              options={LANGUAGES.map((l) => ({ value: l, label: l }))}
            />
          </Field>
        </div>
      </div>

      {/* Copyright Info */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Copyright Info" subtitle="All fields are required unless noted otherwise" />
        <div className="p-6 space-y-5">
          <Field label="Label" hint="If you are an independent artist, you may use your artist name as the label.">
            <TextInput
              value={form.label}
              onChange={(v) => setF("label", v)}
              placeholder={artistName || "Your label name"}
            />
          </Field>

          <Field label="Copyright Date of Release" required hint={`Format: YEAR Name — e.g. "${copyrightPlaceholder}"`}>
            <TextInput
              value={form.copyright}
              onChange={(v) => setF("copyright", v)}
              placeholder={copyrightPlaceholder}
            />
          </Field>

          <Field label="Copyright Date of Recording" required hint="Use the same format as above. Usually the same year as the release.">
            <TextInput
              value={form.copyrightRecordingYear}
              onChange={(v) => setF("copyrightRecordingYear", v)}
              placeholder={copyrightPlaceholder}
            />
          </Field>

          <div className="space-y-3">
            {lockedUpc ? (
              <Field label="Bar Code (UPC)" hint="Permanently assigned — cannot be changed.">
                <div className="flex items-center gap-2 bg-white/5 border border-border rounded-lg px-3 py-2">
                  <span className="text-white/80 text-sm font-mono flex-1">{lockedUpc}</span>
                  <span className="text-green-400/60 text-xs">Locked</span>
                </div>
              </Field>
            ) : (
              <>
                <Field label="Bar Code (UPC)" required hint="If you don't have a bar code (UPC) we will generate one for you.">
                  <Check
                    checked={form.hasOwnUpc}
                    onChange={(v) => setF("hasOwnUpc", v)}
                    label="I have my own UPC"
                  />
                </Field>
                {form.hasOwnUpc && (
                  <TextInput
                    value={form.upc}
                    onChange={(v) => setF("upc", v)}
                    placeholder="Enter your UPC / EAN barcode"
                  />
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Step 2: Track Upload ──────────────────────────────────────────────────────

function TrackForm({ track, index, total, form, onUpdate, onUpdateFields, onRemove, onMoveUp, onMoveDown, lockedIsrc }: {
  track: FormTrackInfo; index: number; total: number;
  form: typeof BLANK_FORM;
  onUpdate: (key: keyof FormTrackInfo, val: unknown) => void;
  onUpdateFields: (patch: Partial<FormTrackInfo>) => void;
  onRemove: () => void;
  onMoveUp: () => void; onMoveDown: () => void;
  lockedIsrc?: string;
}) {
  const [expanded, setExpanded] = useState(true);
  const audioRef = useRef<HTMLInputElement>(null);

  async function handleAudioChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    const validationError = validateAudioFile(file);
    if (validationError) {
      onUpdateFields({ audioFile: null, audioUrl: undefined, audioUploading: false, audioError: validationError });
      return;
    }

    onUpdateFields({ audioFile: file, audioUrl: undefined, audioUploading: true, audioError: "" });
    try {
      const r = await api.releases.uploadFile(file);
      onUpdateFields({ audioUrl: r.url, audioUploading: false, audioError: "" });
    } catch (err) {
      onUpdateFields({
        audioUploading: false,
        audioError: err instanceof Error ? err.message : "Upload failed. Please try again.",
      });
    }
  }

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div
        className="flex items-center gap-3 px-5 py-4 cursor-pointer hover:bg-white/3 transition-colors"
        onClick={() => setExpanded((v) => !v)}
      >
        <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary text-sm font-bold shrink-0">
          {index + 1}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-white font-medium truncate">{track.title || `Track ${index + 1}`}</div>
          {track.audioFile && <div className="text-white/30 text-xs truncate">{track.audioFile.name}</div>}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {total > 1 && (
            <>
              <button type="button" onClick={(e) => { e.stopPropagation(); onMoveUp(); }} disabled={index === 0} className="p-1 text-white/30 hover:text-white disabled:opacity-20">▲</button>
              <button type="button" onClick={(e) => { e.stopPropagation(); onMoveDown(); }} disabled={index === total - 1} className="p-1 text-white/30 hover:text-white disabled:opacity-20">▼</button>
            </>
          )}
          {total > 1 && (
            <button type="button" onClick={(e) => { e.stopPropagation(); onRemove(); }} className="p-1 text-white/30 hover:text-red-400 transition-colors">
              <XCircle className="w-4 h-4" />
            </button>
          )}
          <div className={`text-white/30 transition-transform ${expanded ? "rotate-90" : ""}`}>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="border-t border-white/8 p-5 space-y-5">
              {/* Track title & version */}
              <Field label="Title" required hint="200 characters max">
                <TextInput value={track.title} onChange={(v) => onUpdate("title", v)} placeholder="Official track title" />
              </Field>

              <Check
                checked={track.isAlternativeVersion}
                onChange={(v) => onUpdate("isAlternativeVersion", v)}
                label="Mark as alternative version of the original release"
              />

              {track.isAlternativeVersion && (
                <Field label="Version" hint="e.g. Remix, Acoustic, Live, Instrumental, Radio Edit">
                  <TextInput value={track.version ?? ""} onChange={(v) => onUpdate("version", v)} placeholder="e.g. Acoustic Version" />
                </Field>
              )}

              {/* Audio file */}
              <Field label="Audio File" hint="WAV, FLAC, or MP3. Max 200 MB. Uploads immediately so you can preview it here.">
                <div
                  onClick={() => !track.audioUploading && audioRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-4 flex items-center gap-4 transition-colors ${
                    track.audioUploading ? "border-white/10 cursor-wait" : "border-white/10 cursor-pointer hover:border-primary/30"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${track.audioFile || track.audioUrl ? "bg-primary/10" : "bg-white/5"}`}>
                    {track.audioUploading ? (
                      <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                    ) : (
                      <FileMusic className={`w-5 h-5 ${track.audioFile || track.audioUrl ? "text-primary" : "text-white/30"}`} />
                    )}
                  </div>
                  <div>
                    <div className="text-white/70 text-sm font-medium">
                      {track.audioUploading
                        ? "Uploading…"
                        : track.audioFile
                          ? track.audioFile.name
                          : "Click to upload audio"}
                    </div>
                    <div className="text-white/30 text-xs">.wav, .flac, .mp3 · max 200 MB</div>
                  </div>
                  <input ref={audioRef} type="file" accept=".wav,.flac,.mp3" className="hidden" onChange={handleAudioChange} />
                </div>
                {track.audioError && (
                  <div className="mt-2 text-red-400 text-xs flex items-start gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {track.audioError}
                  </div>
                )}
                {track.audioUrl && !track.audioUploading && !track.audioError && (
                  <audio controls src={track.audioUrl} className="w-full mt-2 h-9" />
                )}
              </Field>

              {/* Per-track Featured Artists */}
              <Field label="Featured Artists" hint="Optional — comma-separated names. These featured artists appear only on this track.">
                <TextInput
                  value={track.trackFeaturedArtists}
                  onChange={(v) => onUpdate("trackFeaturedArtists", v)}
                  placeholder="Artist Name, Another Artist"
                />
              </Field>

              {/* AI-Assisted Materials */}
              <Field
                label="AI-Assisted Materials"
                hint="Choose the option that most accurately reflects the creative process used to produce this track. Incorrect declarations may result in review delays or future restrictions depending on DSP policies."
              >
                <Select
                  value={track.aiMaterials}
                  onChange={(v) => onUpdate("aiMaterials", v)}
                  options={[{ value: "", label: "Select an Option" }, ...AI_MATERIALS_OPTIONS.map((o) => ({ value: o, label: o }))]}
                />
              </Field>

              {/* Lyric Info */}
              <div className="space-y-4 border-t border-white/8 pt-4">
                <h4 className="text-white/60 text-xs font-semibold uppercase tracking-wider">Lyric Info</h4>

                <Check
                  checked={track.explicitOption === "instrumental"}
                  onChange={(v) => {
                    if (v) {
                      onUpdateFields({ explicitOption: "instrumental", explicitContent: false, trackLanguage: "", trackLyrics: "" });
                    } else {
                      onUpdateFields({ explicitOption: "" });
                    }
                  }}
                  label="Instrumental track"
                />

                {track.explicitOption !== "instrumental" && (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <Field label="Track Language">
                        <Select
                          value={track.trackLanguage}
                          onChange={(v) => onUpdate("trackLanguage", v)}
                          options={LANGUAGES.map((l) => ({ value: l, label: l }))}
                        />
                      </Field>
                      <Field label="Explicit">
                        <Select
                          value={track.explicitOption}
                          onChange={(v) => { onUpdate("explicitOption", v); onUpdate("explicitContent", v === "explicit"); }}
                          options={[
                            { value: "", label: "Select an Option" },
                            { value: "clean", label: "Clean" },
                            { value: "explicit", label: "Explicit" },
                            { value: "not-applicable", label: "Not Applicable" },
                          ]}
                        />
                      </Field>
                    </div>

                    <Field label="Lyrics" hint="Optional — separate lines with return. Separate verses with a hard (double) break.">
                      <textarea
                        rows={4}
                        className={`${inputCls} resize-none`}
                        value={track.trackLyrics}
                        onChange={(e) => onUpdate("trackLyrics", e.target.value)}
                        placeholder="Paste lyrics here…"
                      />
                    </Field>
                  </>
                )}
              </div>

              {/* ISRC */}
              {lockedIsrc ? (
                <Field label="ISRC" hint="Permanently assigned — cannot be changed.">
                  <div className="flex items-center gap-2 bg-white/5 border border-border rounded-lg px-3 py-2">
                    <span className="text-white/80 text-sm font-mono flex-1">{lockedIsrc}</span>
                    <span className="text-green-400/60 text-xs">Locked</span>
                  </div>
                </Field>
              ) : (
                <Field label="ISRC" hint="Optional — leave blank and we will assign one for you.">
                  <TextInput value={track.isrc ?? ""} onChange={(v) => onUpdate("isrc", v)} placeholder="e.g. USRC17607839" />
                </Field>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Step2TrackUpload({ form, setF, setForm, editingRelease }: {
  form: typeof BLANK_FORM;
  setF: (k: string, v: unknown) => void;
  setForm: (updater: (f: typeof BLANK_FORM) => typeof BLANK_FORM) => void;
  editingRelease?: Release | null;
}) {
  const tracks = form.tracks as FormTrackInfo[];

  function updateTrack(i: number, key: keyof FormTrackInfo, val: unknown) {
    updateTrackFields(i, { [key]: val } as Partial<FormTrackInfo>);
  }

  function updateTrackFields(i: number, patch: Partial<FormTrackInfo>) {
    setForm((f) => {
      const nextTracks = [...(f.tracks as FormTrackInfo[])];
      nextTracks[i] = { ...nextTracks[i], ...patch };
      return { ...f, tracks: nextTracks };
    });
  }

  function addTrack() {
    setF("tracks", [...tracks, { ...BLANK_TRACK }]);
  }

  function removeTrack(i: number) {
    setF("tracks", tracks.filter((_, idx) => idx !== i));
  }

  function moveTrack(i: number, dir: -1 | 1) {
    const next = [...tracks];
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    setF("tracks", next);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-white font-semibold">
          {form.releaseType === "single" ? "Track" : `Tracks · ${tracks.length}`}
        </h3>
        {form.releaseType !== "single" && (
          <Button type="button" onClick={addTrack} size="sm" className="bg-primary text-black hover:bg-primary/90 font-bold">
            <Plus className="w-4 h-4 mr-1" /> Add Track
          </Button>
        )}
      </div>

      {tracks.map((track, i) => {
        const existingTrackIsrc =
          form.releaseType === "single"
            ? editingRelease?.isrc ?? undefined
            : editingRelease?.tracks?.[i]?.isrc ?? undefined;
        return (
          <TrackForm
            key={i}
            track={track}
            index={i}
            total={tracks.length}
            form={form}
            onUpdate={(k, v) => updateTrack(i, k, v)}
            onUpdateFields={(patch) => updateTrackFields(i, patch)}
            onRemove={() => removeTrack(i)}
            onMoveUp={() => moveTrack(i, -1)}
            onMoveDown={() => moveTrack(i, 1)}
            lockedIsrc={existingTrackIsrc || undefined}
          />
        );
      })}

      {form.releaseType !== "single" && tracks.length < 30 && (
        <button
          type="button"
          onClick={addTrack}
          className="w-full py-3 border-2 border-dashed border-white/10 rounded-xl text-white/30 hover:text-white hover:border-primary/30 text-sm font-medium transition-colors flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" /> Add Another Track
        </button>
      )}
    </div>
  );
}

// ── Step 3: Album Art ─────────────────────────────────────────────────────────

function Step3AlbumArt({ artworkFile, artworkPreview, onArtwork }: {
  artworkFile: File | null;
  artworkPreview: string | null;
  onArtwork: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  const ref = useRef<HTMLInputElement>(null);

  const requirements = [
    { ok: true,  text: "File format: JPG or PNG" },
    { ok: true,  text: "Size: at least 3000 × 3000 pixels" },
    { ok: true,  text: "File size: no greater than 35 MB" },
    { ok: true,  text: "Color mode: best quality RGB (including black and white images)" },
    { ok: true,  text: "Resolution: 72 dpi or higher" },
    { ok: false, text: "Must NOT contain logos, website addresses, release dates, or advertisements" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Album Assets" subtitle="Upload cover art for your release" />
        <div className="p-6">
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Preview */}
            <div className="shrink-0">
              <div
                onClick={() => ref.current?.click()}
                className="w-48 h-48 rounded-xl border-2 border-dashed border-white/15 overflow-hidden flex items-center justify-center bg-white/3 cursor-pointer hover:border-primary/40 transition-colors group"
              >
                {artworkPreview ? (
                  <img src={artworkPreview} alt="Cover art" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center p-4">
                    <ImageIcon className="w-10 h-10 text-white/20 mx-auto mb-2" />
                    <p className="text-white/30 text-xs">Click to upload</p>
                  </div>
                )}
              </div>
              <input ref={ref} type="file" accept="image/jpeg,image/png" className="hidden" onChange={onArtwork} />
              <Button
                type="button"
                onClick={() => ref.current?.click()}
                className="w-48 mt-3 bg-primary/10 border border-primary/30 text-primary hover:bg-primary/20 font-semibold"
              >
                {artworkPreview ? "Change Artwork" : "Browse"}
              </Button>
              {artworkFile && (
                <p className="text-white/30 text-xs mt-2 truncate w-48">{artworkFile.name}</p>
              )}
            </div>

            {/* Requirements */}
            <div className="flex-1">
              <h4 className="text-white/70 font-semibold text-sm mb-3">Artwork upload requirements</h4>
              <div className="space-y-2">
                {requirements.map((r, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-sm">
                    <span className={`mt-0.5 shrink-0 ${r.ok ? "text-white/30" : "text-red-400/60"}`}>
                      {r.ok ? "–" : "✕"}
                    </span>
                    <span className={r.ok ? "text-white/50" : "text-red-400/70"}>{r.text}</span>
                  </div>
                ))}
              </div>

              {!artworkPreview && (
                <div className="mt-4 p-3 bg-yellow-500/8 border border-yellow-500/20 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-400/70 shrink-0 mt-0.5" />
                  <p className="text-yellow-400/70 text-xs">Cover art is required before your release can be submitted for distribution.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Step 4: Distribution Preferences ─────────────────────────────────────────

function Step4Distribution({ form, setF }: { form: typeof BLANK_FORM; setF: (k: string, v: unknown) => void }) {
  const [allStores, setAllStores] = useState(form.stores.length === ALL_STORES.length);
  const [countrySearch, setCountrySearch] = useState("");
  const selectedCountries = form.selectedCountries as string[];
  const filteredCountries = countrySearch.trim()
    ? ALL_COUNTRIES.filter((c) => c.toLowerCase().includes(countrySearch.toLowerCase()))
    : ALL_COUNTRIES;

  function toggleStore(store: string) {
    const has = form.stores.includes(store);
    const next = has ? form.stores.filter((s) => s !== store) : [...form.stores, store];
    setF("stores", next);
    setAllStores(next.length === ALL_STORES.length);
  }

  function toggleAll() {
    const next = !allStores;
    setAllStores(next);
    setF("stores", next ? [...ALL_STORES] : []);
  }

  // Minimum release date is today + 3 days (we suggest 21 days to mirror industry standards)
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 3);
  const minDateStr = minDate.toISOString().split("T")[0];

  return (
    <div className="space-y-6">
      {/* Territory */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Territory" />
        <div className="p-6">
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: "worldwide", label: "🌍 World" },
              { value: "selected",  label: "🗺 Select Countries" },
            ].map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => {
                  setF("territory", t.value);
                  if (t.value === "worldwide") setF("selectedCountries", []);
                }}
                className={`py-3 rounded-xl text-sm font-semibold border-2 transition-all ${
                  form.territory === t.value
                    ? "bg-primary/10 border-primary text-primary"
                    : "border-white/10 text-white/40 hover:border-white/30 hover:text-white"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Country picker — shown when "Select Countries" is chosen */}
          {form.territory === "selected" && (
            <div className="mt-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-sm">
                  {selectedCountries.length > 0
                    ? `${selectedCountries.length} countr${selectedCountries.length === 1 ? "y" : "ies"} selected`
                    : "No countries selected"}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setF("selectedCountries", selectedCountries.length === ALL_COUNTRIES.length ? [] : [...ALL_COUNTRIES])
                  }
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                    selectedCountries.length === ALL_COUNTRIES.length
                      ? "border-primary text-primary bg-primary/10"
                      : "border-white/15 text-white/40 hover:text-white"
                  }`}
                >
                  {selectedCountries.length === ALL_COUNTRIES.length ? "Deselect All" : "Select All Countries"}
                </button>
              </div>

              <input
                type="text"
                className={inputCls}
                placeholder="Search countries…"
                value={countrySearch}
                onChange={(e) => setCountrySearch(e.target.value)}
              />

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
                {filteredCountries.map((country) => (
                  <label key={country} className="flex items-center gap-2 cursor-pointer group">
                    <div
                      onClick={() => {
                        const has = selectedCountries.includes(country);
                        setF(
                          "selectedCountries",
                          has ? selectedCountries.filter((c) => c !== country) : [...selectedCountries, country],
                        );
                      }}
                      className={`w-3.5 h-3.5 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                        selectedCountries.includes(country)
                          ? "bg-primary border-primary"
                          : "border-white/25 group-hover:border-white/50"
                      }`}
                    >
                      {selectedCountries.includes(country) && <div className="w-1.5 h-1.5 bg-black rounded-sm" />}
                    </div>
                    <span className="text-white/55 text-xs group-hover:text-white transition-colors truncate">{country}</span>
                  </label>
                ))}
              </div>

              {filteredCountries.length === 0 && (
                <p className="text-white/25 text-sm text-center py-4">No countries match "{countrySearch}"</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Release Date */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Release Date & Time" />
        <div className="p-6 space-y-5">
          <div className="p-4 bg-blue-500/6 border border-blue-500/15 rounded-xl space-y-2 text-xs text-white/50 leading-relaxed">
            <p><span className="text-blue-400/80 font-semibold">Release Date:</span> We recommend scheduling at least 21 days in the future. This gives you time to announce to fans, share pre-saves, and pitch to DSP editorial playlists.</p>
            <p><span className="text-blue-400/80 font-semibold">Release Time:</span> Your release will be available starting at 12am for each territory.</p>
            <p><span className="text-blue-400/80 font-semibold">Important:</span> As Apple does not allow timed releases, your album will be available at 12am for each country on Apple Music and iTunes.</p>
          </div>

          <Field label="Release Date" required>
            <TextInput type="date" value={form.releaseDate} onChange={(v) => setF("releaseDate", v)} />
          </Field>

          <Check
            checked={form.hasOriginalReleaseDate as boolean}
            onChange={(checked) => {
              setF("hasOriginalReleaseDate", checked);
              if (!checked) setF("originalReleaseDate", "");
            }}
            label="My release date is different than original release date"
          />
          {form.hasOriginalReleaseDate && (
            <Field label="Original Release Date">
              <TextInput type="date" value={form.originalReleaseDate} onChange={(v) => setF("originalReleaseDate", v)} />
            </Field>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Release Time (optional)">
              <TextInput type="time" value={form.releaseTime} onChange={(v) => setF("releaseTime", v)} />
            </Field>
            <Field label="Release Timezone (optional)">
              <Select
                value={form.releaseTimezone}
                onChange={(v) => setF("releaseTimezone", v)}
                options={TIMEZONES.map((t) => ({ value: t, label: t }))}
              />
            </Field>
          </div>
        </div>
      </div>

      {/* Pre-order & Pricing */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Pre-order & Pricing" />
        <div className="p-6 space-y-4">
          <Check
            checked={form.preOrder}
            onChange={(v) => setF("preOrder", v)}
            label="Pre-order — allow fans to pre-save / pre-order before release date"
          />
          {form.preOrder && (
            <Check
              checked={form.noPreviewsDuringPreOrder}
              onChange={(v) => setF("noPreviewsDuringPreOrder", v)}
              label="No previews during pre-order period"
            />
          )}

          <Field label="Select Pricing" hint="Determines the retail pricing tier across stores.">
            <Select
              value={form.pricing}
              onChange={(v) => setF("pricing", v)}
              options={PRICING_OPTIONS.map((p) => ({ value: p, label: p }))}
            />
          </Field>
        </div>
      </div>

      {/* Stores */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Streaming Platforms" subtitle="Choose which stores to distribute to" />
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-white/40 text-sm">{form.stores.length > 0 ? `${form.stores.length} platform${form.stores.length > 1 ? "s" : ""} selected` : "No platforms selected"}</span>
            <button
              type="button"
              onClick={toggleAll}
              className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                allStores ? "border-primary text-primary bg-primary/10" : "border-white/15 text-white/40 hover:text-white"
              }`}
            >
              {allStores ? "Deselect All" : "Select All"}
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto pr-1">
            {ALL_STORES.map((store) => (
              <label key={store} className="flex items-center gap-2 cursor-pointer group">
                <div
                  onClick={() => toggleStore(store)}
                  className={`w-3.5 h-3.5 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${
                    form.stores.includes(store) ? "bg-primary border-primary" : "border-white/25 group-hover:border-white/50"
                  }`}
                >
                  {form.stores.includes(store) && <div className="w-1.5 h-1.5 bg-black rounded-sm" />}
                </div>
                <span className="text-white/55 text-xs group-hover:text-white transition-colors truncate">{store}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Step 5: Preview / Distribute ──────────────────────────────────────────────

function Step5Preview({ form, artworkPreview, submitting, uploadError, onSubmit, editingRelease }: {
  form: typeof BLANK_FORM;
  artworkPreview: string | null;
  submitting: boolean;
  uploadError: string;
  onSubmit: (asDraft: boolean) => void;
  editingRelease: Release | null;
}) {
  const tracks = form.tracks as FormTrackInfo[];
  const releaseTitle = form.releaseType === "single" ? form.title : form.releaseTitle;

  const checks = [
    { label: "Release title",    ok: !!releaseTitle },
    { label: "Primary artist",   ok: form.isVariousArtists || !!form.mainArtists },
    { label: "Genre",            ok: !!form.genre },
    { label: "Language",         ok: !!form.language },
    { label: "Track(s) titled",  ok: tracks.every((t) => !!t.title) },
    { label: "Audio file(s)",    ok: tracks.some((t) => !!t.audioUrl) },
    { label: "Audio upload(s) finished", ok: tracks.every((t) => !t.audioUploading) },
    { label: "Cover artwork",    ok: !!artworkPreview },
    { label: "Release date",     ok: !!form.releaseDate },
  ];

  const allClear = checks.every((c) => c.ok);

  return (
    <div className="space-y-6">
      {/* Checklist */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Release Checklist" subtitle="All items should be complete before submitting" />
        <div className="p-6 space-y-3">
          {checks.map((c) => (
            <div key={c.label} className="flex items-center gap-3">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${c.ok ? "bg-green-500/20 text-green-400" : "bg-red-500/10 text-red-400/60"}`}>
                {c.ok ? <CheckCircle className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
              </div>
              <span className={`text-sm ${c.ok ? "text-white/70" : "text-red-400/70"}`}>{c.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Summary */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <SectionHeader title="Release Summary" />
        <div className="p-6 flex gap-5">
          {artworkPreview ? (
            <img src={artworkPreview} alt="Cover" className="w-24 h-24 rounded-xl object-cover shrink-0 border border-white/10" />
          ) : (
            <div className="w-24 h-24 rounded-xl bg-white/5 border border-dashed border-white/10 flex items-center justify-center shrink-0">
              <ImageIcon className="w-8 h-8 text-white/20" />
            </div>
          )}
          <div className="space-y-2 flex-1 min-w-0">
            <div>
              <div className="text-white font-semibold text-lg truncate">{releaseTitle || "Untitled"}</div>
              <div className="text-white/40 text-sm">{form.mainArtists || (form.isVariousArtists ? "Various Artists" : "—")}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs bg-white/8 text-white/50 px-2 py-0.5 rounded capitalize">{form.releaseType}</span>
              {form.genre && <span className="text-xs bg-white/8 text-white/50 px-2 py-0.5 rounded">{form.genre}</span>}
              {form.language && <span className="text-xs bg-white/8 text-white/50 px-2 py-0.5 rounded">{form.language}</span>}
            </div>
            {tracks.length > 0 && (
              <div className="text-white/30 text-xs">{tracks.length} track{tracks.length > 1 ? "s" : ""} · {form.stores.length > 0 ? `${form.stores.length} platforms` : "all platforms"}</div>
            )}
            {form.releaseDate && <div className="text-white/30 text-xs">Release date: {form.releaseDate}</div>}
          </div>
        </div>
        {tracks.length > 1 && (
          <div className="border-t border-white/8 px-6 pb-6">
            <div className="space-y-2 mt-4">
              {tracks.map((t, i) => (
                <div key={i} className="flex items-center gap-3 text-sm text-white/50">
                  <span className="w-5 h-5 rounded-full bg-white/5 flex items-center justify-center text-xs shrink-0">{i + 1}</span>
                  <span className="flex-1 truncate">{t.title || `Track ${i + 1}`}</span>
                  {t.audioFile && <span className="text-white/25 text-xs truncate max-w-32">{t.audioFile.name}</span>}
                  {t.audioUploading && <span className="text-primary/60 text-xs shrink-0">Uploading…</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {uploadError && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          {uploadError}
        </div>
      )}

      {!allClear && (
        <div className="p-4 bg-yellow-500/8 border border-yellow-500/20 rounded-xl text-yellow-400/80 text-sm flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          Some required items are incomplete. You can save as a draft and finish later, or go back to complete the missing details.
        </div>
      )}

      <div className="flex gap-3">
        <Button onClick={() => onSubmit(true)} disabled={submitting} variant="outline" className="border-white/15 text-white/70 hover:text-white flex-1">
          Save as Draft
        </Button>
        <Button
          onClick={() => onSubmit(false)}
          disabled={submitting || !allClear}
          className="bg-primary text-black hover:bg-primary/90 font-bold flex-1 disabled:opacity-40"
        >
          {submitting ? (
            <span className="flex items-center gap-2"><div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" /> Uploading…</span>
          ) : (
            <><Send className="w-4 h-4 mr-2" /> {editingRelease ? "Save Changes" : "Submit for Review"}</>
          )}
        </Button>
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function ArtistDashboard() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [authModal, setAuthModal] = useState<"login" | "register" | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [tab, setTab] = useState<ArtistTab>("releases");
  const [releases, setReleases] = useState<Release[]>([]);
  const [form, setForm] = useState({ ...BLANK_FORM });
  const [artworkFile, setArtworkFile] = useState<File | null>(null);
  const [artworkPreview, setArtworkPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [editingRelease, setEditingRelease] = useState<Release | null>(null);
  const [viewingRelease, setViewingRelease] = useState<Release | null>(null);
  const [uploadStep, setUploadStep] = useState<UploadStep>(1);
  const [autosaveState, setAutosaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const autosaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autosavingRef = useRef(false);
  const [earnings, setEarnings] = useState<ArtistEarnings | null>(null);
  const [earningsLoading, setEarningsLoading] = useState(false);
  const [payoutMethod, setPayoutMethod] = useState<PayoutMethod | null>(null);
  const [payoutMethodLoading, setPayoutMethodLoading] = useState(false);
  const [showPayoutForm, setShowPayoutForm] = useState(false);
  const [paymentRequests, setPaymentRequests] = useState<ArtistPaymentRequest[]>([]);
  const [paymentRequestsLoading, setPaymentRequestsLoading] = useState(false);
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [analytics, setAnalytics] = useState<ArtistAnalytics | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [ticketsLoading, setTicketsLoading] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketMessages, setTicketMessages] = useState<TicketMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [reply, setReply] = useState("");
  const [sendingReply, setSendingReply] = useState(false);
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [newTicket, setNewTicket] = useState({ subject: "", message: "", priority: "normal" });
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [ticketError, setTicketError] = useState("");

  useEffect(() => {
    if (!user) return;
    if (user.role !== "verified_artist" && user.role !== "admin") {
      setLocation("/apply-artist");
      return;
    }
    loadReleases();
  }, [user]);

  // Autosave the in-progress release as a draft a moment after the artist
  // stops typing/uploading, so refreshing the page or leaving mid-flow never
  // means starting the whole release over — "My Releases" will already show
  // it as a draft with everything filled in exactly as they left it.
  useEffect(() => {
    if (tab !== "upload" || submitting || !user) return;
    if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
    autosaveTimerRef.current = setTimeout(() => { autosaveProgress(); }, 1500);
    return () => { if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form, artworkFile, artworkPreview, tab]);

  // Remember the furthest step reached on the current draft so re-opening it
  // later (via "My Releases") resumes at the same spot instead of step 1.
  useEffect(() => {
    if (user && editingRelease) setStepForRelease(user.id, editingRelease.id, uploadStep);
  }, [uploadStep, editingRelease?.id, user]);

  async function loadReleases() {
    try { setReleases(await api.releases.my()); } catch {}
  }

  async function loadAnalytics() {
    setAnalyticsLoading(true);
    try { setAnalytics(await api.analytics.me()); } catch {}
    setAnalyticsLoading(false);
  }

  useEffect(() => {
    if (tab === "earnings" && user) {
      setEarningsLoading(true);
      api.earnings.me().then(setEarnings).catch(() => {}).finally(() => setEarningsLoading(false));
      setPayoutMethodLoading(true);
      api.payoutMethod.me().then(setPayoutMethod).catch(() => {}).finally(() => setPayoutMethodLoading(false));
      setPaymentRequestsLoading(true);
      api.paymentRequests.my().then(setPaymentRequests).catch(() => {}).finally(() => setPaymentRequestsLoading(false));
    }
  }, [tab, user]);

  useEffect(() => {
    if (tab === "analytics" && user) loadAnalytics();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, user]);

  useEffect(() => {
    if (tab === "support" && user) {
      setTicketsLoading(true);
      api.support.myTickets().then(setTickets).catch(() => {}).finally(() => setTicketsLoading(false));
    }
  }, [tab, user]);

  async function openTicket(ticket: SupportTicket) {
    setSelectedTicket(ticket);
    setMessagesLoading(true);
    try {
      const msgs = await api.support.messages(ticket.id);
      setTicketMessages(msgs);
    } catch {}
    setMessagesLoading(false);
  }

  async function sendReply() {
    if (!selectedTicket || !reply.trim() || sendingReply) return;
    setSendingReply(true);
    try {
      const msg = await api.support.sendMessage(selectedTicket.id, reply.trim());
      setTicketMessages((m) => [...m, msg]);
      setReply("");
    } catch {}
    setSendingReply(false);
  }

  async function submitNewTicket(e: React.FormEvent) {
    e.preventDefault();
    if (!newTicket.subject.trim() || !newTicket.message.trim()) {
      setTicketError("Subject and message are required.");
      return;
    }
    setSubmittingTicket(true);
    setTicketError("");
    try {
      const ticket = await api.support.create(newTicket.subject.trim(), newTicket.message.trim(), newTicket.priority);
      setTickets((ts) => [ticket, ...ts]);
      setNewTicket({ subject: "", message: "", priority: "normal" });
      setShowNewTicket(false);
    } catch (err) {
      setTicketError(err instanceof Error ? err.message : "Failed to submit ticket.");
    }
    setSubmittingTicket(false);
  }

  async function autosaveProgress() {
    if (!user || autosavingRef.current) return;
    // Never autosave over a release that's already been submitted — only
    // drafts and releases the artist is still allowed to edit.
    if (editingRelease && !["draft", "changes_requested", "rejected"].includes(editingRelease.status)) return;

    const tracks = form.tracks as FormTrackInfo[];
    const hasContent = !!(
      form.title || form.releaseTitle || form.mainArtists || form.genre ||
      artworkFile || artworkPreview ||
      tracks.some((t) => t.title || t.audioUrl)
    );
    if (!hasContent) return;

    autosavingRef.current = true;
    setAutosaveState("saving");
    try {
      let artworkUrl: string | undefined;
      if (artworkFile) {
        const r = await api.releases.uploadFile(artworkFile);
        artworkUrl = r.url;
        setArtworkFile(null); // already uploaded — don't re-upload on the next tick
      }

      const trackPayload = buildTrackPayload(tracks);
      const singleAudioUrl = form.releaseType === "single"
        ? trackPayload[0]?.audioUrl ?? editingRelease?.audioUrl ?? undefined
        : undefined;

      const effectiveTitle =
        form.releaseType !== "single" && !form.title
          ? (form.tracks[0]?.title || form.releaseTitle || "Untitled draft")
          : (form.title || "Untitled draft");

      const payload: Partial<Release> = {
        releaseType: form.releaseType,
        releaseTitle: form.releaseType !== "single" ? form.releaseTitle || undefined : undefined,
        title: effectiveTitle,
        audioUrl: singleAudioUrl,
        version: form.version || undefined,
        genre: form.genre || undefined,
        language: form.language,
        explicitContent: form.explicitContent,
        isrc: form.isrc || undefined,
        upc: form.hasOwnUpc ? form.upc || undefined : undefined,
        releaseDate: form.releaseDate || undefined,
        originalReleaseDate: form.originalReleaseDate || undefined,
        copyright: form.copyright || undefined,
        copyrightRecordingYear: form.copyrightRecordingYear || undefined,
        publisher: form.label || form.publisher || undefined,
        composer: form.composer || undefined,
        songwriter: form.songwriter || undefined,
        producer: form.producer || undefined,
        lyrics: form.lyrics || undefined,
        mainArtists: form.mainArtists || undefined,
        featuredArtists: form.featuredArtists || undefined,
        stores: form.stores.length > 0 ? form.stores : undefined,
        territory: form.territory,
        selectedCountries: form.territory === "selected" && (form.selectedCountries as string[]).length > 0
          ? (form.selectedCountries as string[])
          : undefined,
        tracks: form.releaseType !== "single" ? trackPayload : undefined,
        artworkUrl: artworkUrl ?? editingRelease?.artworkUrl ?? undefined,
      };

      if (editingRelease) {
        const updated = await api.releases.update(editingRelease.id, payload);
        setEditingRelease(updated);
      } else {
        const created = await api.releases.create({ ...payload, status: "draft" });
        setEditingRelease(created);
        setStepForRelease(user.id, created.id, uploadStep);
        loadReleases(); // surface the new draft in "My Releases" right away
      }
      setAutosaveState("saved");
    } catch {
      // Autosave failures should never interrupt the artist's flow — they can
      // still finish and hit Submit, which will surface any real error.
      setAutosaveState("error");
    } finally {
      autosavingRef.current = false;
    }
  }

  function handleArtwork(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setArtworkFile(f);
    setArtworkPreview(URL.createObjectURL(f));
  }

  function setF(key: string, val: unknown) {
    setForm((f) => ({ ...f, [key]: val }));
  }

  function resetUpload() {
    setForm({ ...BLANK_FORM });
    setArtworkFile(null);
    setArtworkPreview(null);
    setEditingRelease(null);
    setUploadStep(1);
    setUploadError("");
    setAutosaveState("idle");
  }

  function loadForEdit(r: Release) {
    setEditingRelease(r);
    const tracks: FormTrackInfo[] = (r.tracks ?? [{ ...BLANK_TRACK }]).map((t, i) => ({
      ...BLANK_TRACK, ...t,
      // Singles store their audio at the release level, not per-track — seed
      // it here so the audio step correctly shows it as already uploaded.
      audioUrl: t.audioUrl ?? (i === 0 && r.releaseType === "single" ? r.audioUrl : undefined),
    }));
    setForm({
      releaseType: (r.releaseType as "single" | "ep" | "album") ?? "single",
      releaseTitle: r.releaseTitle ?? "",
      title: r.title ?? "",
      version: r.version ?? "",
      isVariousArtists: false,
      mainArtists: r.mainArtists ?? "",
      featuredArtists: r.featuredArtists ?? "",
      genre: r.genre ?? "",
      secondaryGenre: "",
      language: r.language ?? "English",
      label: r.publisher ?? "",
      copyright: r.copyright ?? "",
      copyrightRecordingYear: r.copyrightRecordingYear ?? "",
      hasOwnUpc: !!(r.upc),
      upc: r.upc ?? "",
      isrc: r.isrc ?? "",
      explicitContent: r.explicitContent ?? false,
      releaseDate: r.releaseDate ?? "",
      originalReleaseDate: r.originalReleaseDate ?? "",
      hasOriginalReleaseDate: !!(r.originalReleaseDate),
      releaseTime: "00:00",
      releaseTimezone: "(GMT+1) West Africa Time",
      preOrder: false,
      noPreviewsDuringPreOrder: false,
      pricing: "HIGH",
      territory: r.territory ?? "worldwide",
      stores: r.stores ?? [],
      selectedCountries: (r.selectedCountries ?? []) as string[],
      lyrics: r.lyrics ?? "",
      publisher: r.publisher ?? "",
      composer: r.composer ?? "",
      songwriter: r.songwriter ?? "",
      producer: r.producer ?? "",
      tracks,
    });
    setArtworkPreview(r.artworkUrl ?? null);
    setUploadStep(user ? getStepForRelease(user.id, r.id) ?? 1 : 1);
    setAutosaveState("idle");
    setTab("upload");
  }

  async function deleteRelease(id: number) {
    if (!confirm("Delete this release? This cannot be undone.")) return;
    try {
      await api.releases.delete(id);
      setReleases((rs) => rs.filter((r) => r.id !== id));
      if (user) clearStepForRelease(user.id, id);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Delete failed");
    }
  }

  async function submitRelease(asDraft: boolean) {
    const effectiveTitle =
      form.releaseType !== "single" && !form.title
        ? (form.tracks[0]?.title || form.releaseTitle || "Untitled")
        : form.title;

    if (!asDraft && (!effectiveTitle || !form.genre || !form.language)) {
      setUploadError("Title, Genre and Language are required.");
      return;
    }
    if (!asDraft && (!form.copyright || !form.copyrightRecordingYear)) {
      setUploadError("Copyright Date of Release and Copyright Date of Recording are required.");
      return;
    }
    const tracksSnapshot = form.tracks as FormTrackInfo[];
    if (tracksSnapshot.some((t) => t.audioUploading)) {
      setUploadError("Please wait for the audio upload to finish before submitting.");
      return;
    }
    setSubmitting(true);
    setUploadError("");
    try {
      let artworkUrl: string | undefined;
      if (artworkFile) { const r = await api.releases.uploadFile(artworkFile); artworkUrl = r.url; }

      // Audio for each track is already uploaded immediately on selection
      // (see handleAudioChange in TrackForm), so just forward the resulting URL.
      const tracks = tracksSnapshot;
      const trackPayload = buildTrackPayload(tracks);

      // Singles carry their single track's audio at the release level (no
      // per-track "tracks" array is sent for them), so surface it explicitly
      // here — otherwise the uploaded audio file is silently dropped.
      const singleAudioUrl =
        form.releaseType === "single"
          ? trackPayload[0]?.audioUrl ?? editingRelease?.audioUrl ?? undefined
          : undefined;

      const payload: Partial<Release> = {
        releaseType: form.releaseType,
        releaseTitle: form.releaseType !== "single" ? form.releaseTitle || undefined : undefined,
        title: effectiveTitle,
        audioUrl: singleAudioUrl,
        version: form.version || undefined,
        genre: form.genre,
        language: form.language,
        explicitContent: form.explicitContent,
        isrc: form.isrc || undefined,
        upc: form.hasOwnUpc ? form.upc || undefined : undefined,
        releaseDate: form.releaseDate || undefined,
        originalReleaseDate: form.originalReleaseDate || undefined,
        copyright: form.copyright || undefined,
        copyrightRecordingYear: form.copyrightRecordingYear || undefined,
        publisher: form.label || form.publisher || undefined,
        composer: form.composer || undefined,
        songwriter: form.songwriter || undefined,
        producer: form.producer || undefined,
        lyrics: form.lyrics || undefined,
        mainArtists: form.mainArtists || undefined,
        featuredArtists: form.featuredArtists || undefined,
        stores: form.stores.length > 0 ? form.stores : undefined,
        territory: form.territory,
        selectedCountries: form.territory === "selected" && (form.selectedCountries as string[]).length > 0
          ? (form.selectedCountries as string[])
          : undefined,
        tracks: form.releaseType !== "single" ? trackPayload : undefined,
        artworkUrl: artworkUrl ?? editingRelease?.artworkUrl ?? undefined,
        status: asDraft ? "draft" : "pending_review",
      };

      let savedId = editingRelease?.id;
      if (editingRelease) {
        await api.releases.update(editingRelease.id, payload);
      } else {
        const created = await api.releases.create(payload);
        savedId = created.id;
      }
      if (user && savedId) clearStepForRelease(user.id, savedId);

      setUploadSuccess(true);
      resetUpload();
      await loadReleases();
      setTimeout(() => { setUploadSuccess(false); setTab("releases"); }, 2500);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Upload failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  // ── Loading / Guest states ──────────────────────────────────────────────────

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-sm w-full text-center">
            <Music className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="font-display text-4xl text-white mb-2">ARTIST DASHBOARD</h1>
            <p className="text-white/50 mb-6">Login to access your artist studio.</p>
            <Button onClick={() => setAuthModal("login")} className="bg-primary text-black hover:bg-primary/90 font-bold w-full">Login</Button>
          </div>
        </div>
        {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSwitch={(m) => setAuthModal(m)} />}
      </>
    );
  }

  const tabs: { id: ArtistTab; label: string; icon: React.ElementType }[] = [
    { id: "releases", label: "My Releases", icon: List },
    { id: "upload",   label: editingRelease ? "Edit Release" : "Upload Music", icon: Upload },
    { id: "services", label: "Artist Services", icon: Mic2 },
    { id: "earnings", label: "Earnings", icon: DollarSign },
    { id: "analytics",label: "Analytics", icon: BarChart2 },
    { id: "support",  label: "Support", icon: LifeBuoy },
  ];

  const isBlocked = user.isBlocked;
  const releaseName = form.releaseType === "single" ? form.title : form.releaseTitle;

  return (
    <div className="min-h-screen bg-black">
      {/* Nav */}
      <div className="bg-black/90 backdrop-blur-md border-b border-white/10 px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <BrandLockup iconSize="w-6 h-7" textSize="text-xl" />
        </Link>
        <div className="flex items-center gap-4">
          <NotificationBell />
          <ProfileDropdown open={profileOpen} onClose={() => setProfileOpen(false)} onToggle={() => setProfileOpen((v) => !v)} />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl text-white mb-1">ARTIST STUDIO</h1>
          <p className="text-white/40 text-sm">Verified Artist · 85% Royalties · Free Distribution</p>
        </div>

        {/* Blocked warning */}
        {isBlocked && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-red-400 font-semibold">Your account is suspended</div>
              {user.blockedReason && <div className="text-red-400/70 text-sm mt-0.5">{user.blockedReason}</div>}
              <div className="text-white/40 text-sm mt-1">Contact support to resolve this. You can still view your releases and withdraw earnings.</div>
            </div>
          </div>
        )}

        {/* Main tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => {
                if (id === "upload" && isBlocked) return;
                if (id !== "upload") setEditingRelease(null);
                setTab(id);
              }}
              disabled={id === "upload" && isBlocked}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab === id ? "bg-primary text-black" : "text-white/50 hover:text-white hover:bg-white/5"
              } disabled:opacity-30 disabled:cursor-not-allowed`}
            >
              <Icon className="w-4 h-4" /> {label}
            </button>
          ))}
        </div>

        {/* ── Releases ── */}
        {tab === "releases" && (
          <div>
            {uploadSuccess && (
              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-5 p-4 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm flex items-center gap-2">
                <CheckCircle className="w-4 h-4" /> Release submitted for review! We'll be in touch.
              </motion.div>
            )}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-white font-semibold text-lg">All Releases ({releases.length})</h2>
              {!isBlocked && (
                <Button onClick={() => { resetUpload(); setTab("upload"); }} size="sm" className="bg-primary text-black hover:bg-primary/90 font-bold">
                  <Plus className="w-4 h-4 mr-1" /> New Release
                </Button>
              )}
            </div>
            {releases.length === 0 ? (
              <div className="text-center py-20 text-white/30">
                <Music className="w-12 h-12 mx-auto mb-4" />
                <p className="text-lg">No releases yet</p>
                <p className="text-sm mt-1 mb-6">Upload your first track to get started</p>
                {!isBlocked && (
                  <Button onClick={() => setTab("upload")} className="bg-primary text-black hover:bg-primary/90 font-bold">
                    Upload Music <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {releases.map((r) => {
                  const s = STATUS_MAP[r.status] ?? STATUS_MAP.draft;
                  const Icon = s.icon;
                  const canEdit = (r.status === "draft" || r.status === "changes_requested" || r.status === "rejected") && !isBlocked;
                  const canDelete = r.status === "draft" || r.status === "rejected";
                  return (
                    <motion.div
                      key={r.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => setViewingRelease(r)}
                      className="bg-card border border-border rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:border-white/20 transition-colors"
                    >
                      {r.artworkUrl ? (
                        <img src={r.artworkUrl} alt={r.title} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                      ) : (
                        <div className="w-14 h-14 rounded-lg bg-white/5 border border-border flex items-center justify-center shrink-0">
                          <Music className="w-6 h-6 text-white/30" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="text-white font-semibold truncate">
                          {r.releaseType !== "single" && r.releaseTitle ? r.releaseTitle : r.title}
                          {r.releaseType !== "single" && <span className="ml-2 text-xs bg-white/10 text-white/50 px-1.5 py-0.5 rounded capitalize">{r.releaseType}</span>}
                        </div>
                        <div className="text-white/40 text-sm">{r.genre}{r.genre && r.language ? " · " : ""}{r.language}</div>
                        {r.releaseDate && <div className="text-white/30 text-xs">{r.releaseDate}</div>}
                        {r.adminNotes && (r.status === "changes_requested" || r.status === "rejected") && (
                          <div className="mt-1 text-orange-400 text-xs flex items-start gap-1">
                            <AlertCircle className="w-3 h-3 mt-0.5 shrink-0" />
                            <span>{r.adminNotes}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`flex items-center gap-1.5 text-xs px-3 py-1 rounded-full border ${s.color}`}>
                          <Icon className="w-3 h-3" /> {s.label}
                        </span>
                        {canEdit && (
                          <button onClick={(e) => { e.stopPropagation(); loadForEdit(r); }} className="p-1.5 rounded-lg text-white/40 hover:text-primary hover:bg-primary/10 transition-colors" title="Edit">
                            <Pencil className="w-4 h-4" />
                          </button>
                        )}
                        {canDelete && (
                          <button onClick={(e) => { e.stopPropagation(); deleteRelease(r.id); }} className="p-1.5 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-colors" title="Delete">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── Upload Wizard ── */}
        {tab === "upload" && (
          <div>
            {/* Wizard header */}
            <div className="mb-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-white font-bold text-xl">
                    {editingRelease ? `Manage Release: ${releaseName || "Draft"}` : "New Release"}
                  </h2>
                  <p className="text-white/30 text-sm mt-0.5">Complete all steps to submit for distribution</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  {editingRelease && (
                    <span className="text-xs flex items-center gap-1.5">
                      {autosaveState === "saving" && (
                        <span className="text-white/30 flex items-center gap-1.5">
                          <div className="w-3 h-3 border-2 border-white/20 border-t-white/50 rounded-full animate-spin" /> Saving…
                        </span>
                      )}
                      {autosaveState === "saved" && (
                        <span className="text-green-400/70 flex items-center gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5" /> Saved
                        </span>
                      )}
                      {autosaveState === "error" && (
                        <span className="text-yellow-400/70 flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" /> Couldn't save changes
                        </span>
                      )}
                    </span>
                  )}
                  {editingRelease && (
                    <button onClick={resetUpload} className="text-white/30 hover:text-white text-sm">Cancel Edit</button>
                  )}
                </div>
              </div>
              {editingRelease?.status === "changes_requested" && editingRelease.adminNotes && (
                <div className="mb-4 flex items-start gap-2 rounded-lg border border-orange-500/20 bg-orange-500/10 px-3 py-2.5 text-sm text-orange-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-orange-400">Changes requested by review team</div>
                    <div className="text-orange-300/90 mt-0.5">{editingRelease.adminNotes}</div>
                    <div className="text-orange-300/60 text-xs mt-1">Make the requested changes below, then resubmit for review.</div>
                  </div>
                </div>
              )}
              <div className="overflow-x-auto">
                <StepWizard currentStep={uploadStep} onStep={setUploadStep} />
              </div>
            </div>

            {/* Step content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={uploadStep}
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.18 }}
              >
                {uploadStep === 1 && <Step1AlbumInfo form={form} setF={setF} lockedUpc={editingRelease?.upc ?? undefined} />}
                {uploadStep === 2 && <Step2TrackUpload form={form} setF={setF} setForm={setForm} editingRelease={editingRelease} />}
                {uploadStep === 3 && <Step3AlbumArt artworkFile={artworkFile} artworkPreview={artworkPreview} onArtwork={handleArtwork} />}
                {uploadStep === 4 && <Step4Distribution form={form} setF={setF} />}
                {uploadStep === 5 && (
                  <Step5Preview
                    form={form}
                    artworkPreview={artworkPreview}
                    submitting={submitting}
                    uploadError={uploadError}
                    onSubmit={submitRelease}
                    editingRelease={editingRelease}
                  />
                )}
              </motion.div>
            </AnimatePresence>

            {/* Step navigation */}
            {uploadStep < 5 && (
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-white/8">
                {uploadStep > 1 ? (
                  <Button onClick={() => setUploadStep((s) => Math.max(1, s - 1) as UploadStep)} variant="outline" className="border-white/15 text-white/60 hover:text-white">
                    ← {STEPS[uploadStep - 2].label}
                  </Button>
                ) : (
                  <div />
                )}
                <Button onClick={() => setUploadStep((s) => Math.min(5, s + 1) as UploadStep)} className="bg-primary text-black hover:bg-primary/90 font-bold">
                  {STEPS[uploadStep].label} →
                </Button>
              </div>
            )}
          </div>
        )}

        {/* ── Earnings ── */}
        {tab === "earnings" && (
          <div className="max-w-2xl space-y-6">
            {earningsLoading ? (
              <div className="flex justify-center py-16">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : !earnings || earnings.totalEarningsNgn === 0 ? (
              <div className="space-y-6">
                {!payoutMethodLoading && (
                  <PayoutMethodSummary method={payoutMethod} onEdit={() => setShowPayoutForm(true)} />
                )}
                <div className="bg-card border border-border rounded-2xl p-8 text-center">
                  <DollarSign className="w-14 h-14 text-primary mx-auto mb-4" />
                  <h2 className="text-white font-bold text-xl mb-2">Earnings Dashboard</h2>
                  <p className="text-white/50 mb-6">No earnings have been reported for your releases yet. Your royalties will appear here once your first earnings report is available.</p>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    {[{ label: "Your Share", value: "85%" }, { label: "Platform Fee", value: "15%" }, { label: "Payouts", value: "Monthly" }].map(({ label, value }) => (
                      <div key={label} className="bg-black/40 rounded-xl p-4">
                        <div className="font-display text-2xl text-primary">{value}</div>
                        <div className="text-white/40 text-xs mt-1">{label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <>
                {!payoutMethodLoading && (
                  <PayoutMethodSummary method={payoutMethod} onEdit={() => setShowPayoutForm(true)} />
                )}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Total Gross</p>
                    <p className="text-white font-display text-3xl">₦{earnings.totalEarningsNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Your Share (85%)</p>
                    <p className="text-primary font-display text-3xl">₦{earnings.artistShareNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Platform Fee (15%)</p>
                    <p className="text-white/40 font-display text-3xl">₦{earnings.platformFeeNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-2xl p-6 flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Available Balance</p>
                    <p className="text-white font-display text-3xl">₦{earnings.availableBalanceNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    {earnings.totalRequestedNgn > 0 && (
                      <p className="text-white/30 text-xs mt-1">₦{earnings.totalRequestedNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} already requested</p>
                    )}
                    {earnings.availableBalanceNgn < 10000 && (
                      <p className="text-white/40 text-xs mt-1">
                        ₦{(10000 - earnings.availableBalanceNgn).toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} more needed to request payment (min. ₦10,000.00)
                      </p>
                    )}
                  </div>
                  <Button
                    onClick={() => setShowRequestForm(true)}
                    disabled={earnings.availableBalanceNgn < 10000}
                    title={earnings.availableBalanceNgn < 10000 ? "Minimum withdrawal is ₦10,000" : undefined}
                    className="bg-primary text-black hover:bg-primary/90 font-bold disabled:opacity-40"
                  >
                    <Send className="w-4 h-4 mr-2" /> Request Payment
                  </Button>
                </div>

                {earnings.byRelease.length > 0 && (
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h3 className="text-white font-bold mb-4">Earnings by Release</h3>
                    <div className="space-y-3">
                      {earnings.byRelease.map((r) => {
                        const pct = earnings.totalEarningsNgn > 0 ? (r.earningsNgn / earnings.totalEarningsNgn) * 100 : 0;
                        return (
                          <div key={r.releaseId} className="space-y-1">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-white truncate max-w-[60%]">{r.title}</span>
                              <span className="text-primary font-bold">₦{r.earningsNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                            <div className="w-full bg-white/5 rounded-full h-1.5">
                              <div className="bg-primary h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {!paymentRequestsLoading && paymentRequests.length > 0 && (
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h3 className="text-white font-bold mb-4">Payment Requests</h3>
                    <div className="space-y-3">
                      {paymentRequests.map((r) => (
                        <div key={r.id} className="flex items-center justify-between gap-3 bg-black/20 border border-white/5 rounded-xl px-4 py-3">
                          <div>
                            <p className="text-white text-sm font-bold">₦{r.amountNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            <p className="text-white/30 text-xs mt-0.5">
                              Requested {new Date(r.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                              {r.paidAt && ` · Paid ${new Date(r.paidAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}`}
                            </p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <PaymentRequestStatusBadge status={r.status} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* ── Analytics ── */}
        {tab === "analytics" && (
          <div className="max-w-3xl space-y-6">
            {analyticsLoading ? (
              <div className="flex justify-center py-16">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : !analytics || analytics.totalStreams === 0 ? (
              <div className="bg-card border border-border rounded-2xl p-8 text-center">
                <BarChart2 className="w-14 h-14 text-primary mx-auto mb-4" />
                <h2 className="text-white font-bold text-xl mb-2">Streaming Analytics</h2>
                <p className="text-white/50">Real-time streaming stats, platform breakdowns, and audience insights will be available here once your releases go live and we've imported your first report.</p>
              </div>
            ) : (
              <>
                <div className="bg-card border border-border rounded-2xl p-6">
                  <p className="text-white/50 text-sm mb-1">Total Streams</p>
                  <p className="text-white font-display text-4xl">{analytics.totalStreams.toLocaleString()}</p>
                </div>

                <div className="bg-card border border-border rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-4">Streams by Platform</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics.byOutlet.slice().sort((a, b) => b.streams - a.streams)}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                        <XAxis dataKey="outlet" stroke="rgba(255,255,255,0.4)" fontSize={12} tickLine={false} />
                        <YAxis stroke="rgba(255,255,255,0.4)" fontSize={12} tickLine={false} />
                        <Tooltip
                          contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }}
                          cursor={{ fill: "rgba(255,255,255,0.05)" }}
                        />
                        <Bar dataKey="streams" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-4">Streams by Release</h3>
                  <div className="space-y-2">
                    {analytics.byRelease.map((r) => (
                      <div key={r.releaseId} className="flex items-center justify-between bg-black/20 border border-border rounded-lg px-4 py-3">
                        <span className="text-white text-sm">{r.title}</span>
                        <span className="text-primary font-bold text-sm">{r.streams.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── Artist Services ── */}
        {tab === "services" && (
          <ArtistServices
            user={{ id: user.id, email: user.email, name: user.name }}
            releases={releases}
          />
        )}

        {/* ── Support ── */}
        {tab === "support" && (
          <div className="max-w-3xl space-y-4">
            {selectedTicket ? (
              /* ─ Ticket thread ─ */
              <div className="space-y-4">
                <button
                  onClick={() => { setSelectedTicket(null); setTicketMessages([]); setReply(""); }}
                  className="flex items-center gap-1.5 text-white/40 hover:text-white/70 text-sm transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" /> All Tickets
                </button>

                <div className="bg-card border border-border rounded-2xl p-5">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <h2 className="text-white font-bold text-lg leading-tight">{selectedTicket.subject}</h2>
                      <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                        <TicketStatusBadge status={selectedTicket.status} />
                        <PriorityBadge priority={selectedTicket.priority} />
                        <span className="text-white/30 text-xs">
                          {new Date(selectedTicket.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                        </span>
                      </div>
                    </div>
                    <span className="text-white/25 text-xs font-mono">#{selectedTicket.id}</span>
                  </div>
                </div>

                {messagesLoading ? (
                  <div className="flex justify-center py-10">
                    <div className="w-7 h-7 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-3">
                    {ticketMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-3 ${msg.isStaff ? "flex-row" : "flex-row-reverse"}`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${msg.isStaff ? "bg-primary/20 text-primary" : "bg-white/10 text-white/60"}`}>
                          {msg.isStaff ? "NE" : "ME"}
                        </div>
                        <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${msg.isStaff ? "bg-primary/10 border border-primary/20 text-white/85" : "bg-white/8 border border-white/10 text-white/80"}`}>
                          <p className="leading-relaxed">{msg.message}</p>
                          <p className={`text-xs mt-1.5 ${msg.isStaff ? "text-primary/50" : "text-white/25"}`}>
                            {new Date(msg.createdAt).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {selectedTicket.status !== "resolved" && selectedTicket.status !== "closed" && (
                  <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
                    <textarea
                      rows={3}
                      value={reply}
                      onChange={(e) => setReply(e.target.value)}
                      placeholder="Write your reply…"
                      className="w-full bg-input border border-border rounded-xl px-4 py-3 text-white text-sm placeholder:text-white/20 resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <div className="flex justify-end">
                      <Button
                        onClick={sendReply}
                        disabled={!reply.trim() || sendingReply}
                        size="sm"
                        className="bg-primary text-black hover:bg-primary/90 font-bold"
                      >
                        {sendingReply
                          ? <><div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin mr-1.5" />Sending…</>
                          : <><Send className="w-3.5 h-3.5 mr-1.5" />Send Reply</>}
                      </Button>
                    </div>
                  </div>
                )}

                {(selectedTicket.status === "resolved" || selectedTicket.status === "closed") && (
                  <div className="text-center text-white/30 text-sm py-4 border border-white/8 rounded-xl">
                    This ticket is {selectedTicket.status}. Open a new ticket if you need further help.
                  </div>
                )}
              </div>
            ) : (
              /* ─ Ticket list ─ */
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-white font-bold text-xl">Support</h2>
                    <p className="text-white/40 text-sm mt-0.5">Get help with your releases, payments, or account.</p>
                  </div>
                  <Button
                    onClick={() => { setShowNewTicket((v) => !v); setTicketError(""); }}
                    size="sm"
                    className="bg-primary text-black hover:bg-primary/90 font-bold"
                  >
                    <Plus className="w-4 h-4 mr-1.5" /> New Ticket
                  </Button>
                </div>

                {showNewTicket && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-card border border-border rounded-2xl p-5"
                  >
                    <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                      <MessageCircle className="w-4 h-4 text-primary" /> New Support Ticket
                    </h3>
                    <form onSubmit={submitNewTicket} className="space-y-4">
                      <div>
                        <label className="text-white/50 text-xs uppercase tracking-wider block mb-1.5">Subject <span className="text-primary">*</span></label>
                        <input
                          value={newTicket.subject}
                          onChange={(e) => setNewTicket((t) => ({ ...t, subject: e.target.value }))}
                          placeholder="e.g. Issue with my release submission"
                          className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-white text-sm placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-white/50 text-xs uppercase tracking-wider block mb-1.5">Priority</label>
                        <div className="flex gap-2 flex-wrap">
                          {(["low", "normal", "high", "urgent"] as const).map((p) => (
                            <button
                              key={p}
                              type="button"
                              onClick={() => setNewTicket((t) => ({ ...t, priority: p }))}
                              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize border transition-colors ${
                                newTicket.priority === p
                                  ? p === "urgent" ? "bg-red-500/20 border-red-500/50 text-red-400"
                                    : p === "high" ? "bg-orange-500/20 border-orange-500/50 text-orange-400"
                                    : p === "normal" ? "bg-primary/20 border-primary/50 text-primary"
                                    : "bg-white/10 border-white/20 text-white/70"
                                  : "border-white/10 text-white/30 hover:border-white/25 hover:text-white/50"
                              }`}
                            >
                              {p}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="text-white/50 text-xs uppercase tracking-wider block mb-1.5">Message <span className="text-primary">*</span></label>
                        <textarea
                          rows={4}
                          value={newTicket.message}
                          onChange={(e) => setNewTicket((t) => ({ ...t, message: e.target.value }))}
                          placeholder="Describe your issue in detail…"
                          className="w-full bg-input border border-border rounded-xl px-4 py-3 text-white text-sm placeholder:text-white/20 resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      {ticketError && <p className="text-red-400 text-sm">{ticketError}</p>}
                      <div className="flex gap-3">
                        <Button type="submit" disabled={submittingTicket} className="bg-primary text-black hover:bg-primary/90 font-bold">
                          {submittingTicket
                            ? <><div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin mr-1.5" />Submitting…</>
                            : <><Send className="w-3.5 h-3.5 mr-1.5" />Submit Ticket</>}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => { setShowNewTicket(false); setNewTicket({ subject: "", message: "", priority: "normal" }); setTicketError(""); }} className="border-white/15 text-white/50">
                          Cancel
                        </Button>
                      </div>
                    </form>
                  </motion.div>
                )}

                {ticketsLoading ? (
                  <div className="flex justify-center py-16">
                    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : tickets.length === 0 ? (
                  <div className="bg-card border border-border rounded-2xl p-10 text-center">
                    <LifeBuoy className="w-12 h-12 text-primary mx-auto mb-4 opacity-60" />
                    <p className="text-white/50 text-sm">No support tickets yet. If you need help, open a ticket and our team will get back to you.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {tickets.map((ticket) => (
                      <button
                        key={ticket.id}
                        onClick={() => openTicket(ticket)}
                        className="w-full text-left bg-card border border-border hover:border-white/20 rounded-2xl p-4 transition-colors group"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1.5">
                              <TicketStatusBadge status={ticket.status} />
                              <PriorityBadge priority={ticket.priority} />
                            </div>
                            <p className="text-white font-medium text-sm group-hover:text-primary transition-colors truncate">{ticket.subject}</p>
                            <p className="text-white/30 text-xs mt-0.5">
                              {new Date(ticket.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                            </p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-white/25 group-hover:text-primary shrink-0 mt-1 transition-colors" />
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
      {viewingRelease && (
        <ArtistReleaseDetail release={viewingRelease} onClose={() => setViewingRelease(null)} />
      )}
      {showPayoutForm && (
        <PayoutMethodForm
          existing={payoutMethod}
          onClose={() => setShowPayoutForm(false)}
          onSaved={(m) => { setPayoutMethod(m); setShowPayoutForm(false); }}
        />
      )}
      {showRequestForm && earnings && (
        <PaymentRequestForm
          availableBalanceNgn={earnings.availableBalanceNgn}
          onClose={() => setShowRequestForm(false)}
          onCreated={(r) => {
            setPaymentRequests((prev) => [r, ...prev]);
            setEarnings((e) => e ? { ...e, availableBalanceNgn: e.availableBalanceNgn - r.amountNgn, totalRequestedNgn: e.totalRequestedNgn + r.amountNgn } : e);
            setShowRequestForm(false);
          }}
        />
      )}
    </div>
  );
}

function PaymentRequestStatusBadge({ status }: { status: ArtistPaymentRequest["status"] }) {
  const map: Record<string, { label: string; color: string }> = {
    pending: { label: "Pending", color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
    paid:    { label: "Paid",    color: "bg-green-500/10 text-green-400 border-green-500/20" },
  };
  const s = map[status] ?? map.pending;
  return (
    <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${s.color}`}>{s.label}</span>
  );
}

function PayoutMethodSummary({ method, onEdit }: { method: PayoutMethod | null; onEdit: () => void }) {
  if (!method) {
    return (
      <div className="bg-card border border-dashed border-white/15 rounded-2xl p-5 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <Wallet className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-white font-medium text-sm">No payment method on file</p>
            <p className="text-white/40 text-xs mt-0.5">Add one so we know where to send your earnings.</p>
          </div>
        </div>
        <Button onClick={onEdit} size="sm" className="bg-primary text-black hover:bg-primary/90 font-bold shrink-0">
          <Plus className="w-3.5 h-3.5 mr-1" /> Add Payment Method
        </Button>
      </div>
    );
  }

  const Icon = method.method === "paypal" ? Wallet : Building2;
  let title: string;
  let subtitle: string;
  if (method.method === "paypal") {
    title = "PayPal";
    subtitle = method.details.email ?? "";
  } else if (method.bankDetailType === "naira") {
    title = `${method.details.bankName ?? ""} (Naira)`;
    subtitle = `•••• ${(method.details.accountNumber ?? "").slice(-4)} — ${method.details.accountName ?? ""}`;
  } else {
    const typeLabel = method.bankDetailType === "ach" ? "ACH" : method.bankDetailType === "wire" ? "Wire" : "SWIFT";
    title = `Bank Transfer — ${typeLabel} (USD)`;
    subtitle = `•••• ${(method.details.accountNumber ?? "").slice(-4)} — ${method.details.accountName ?? ""}`;
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 flex items-center justify-between gap-4 flex-wrap">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div className="min-w-0">
          <p className="text-white font-medium text-sm truncate">{title}</p>
          <p className="text-white/40 text-xs mt-0.5 truncate">{subtitle}</p>
        </div>
      </div>
      <Button onClick={onEdit} size="sm" variant="outline" className="border-border text-white/60 hover:text-white hover:border-white/30 shrink-0">
        <Pencil className="w-3.5 h-3.5 mr-1" /> Change Payment Method
      </Button>
    </div>
  );
}

function TicketStatusBadge({ status }: { status: SupportTicket["status"] }) {
  const map: Record<string, { label: string; color: string; icon: React.ElementType }> = {
    open:        { label: "Open",        color: "bg-green-500/10 text-green-400 border-green-500/20",   icon: MessageCircle },
    in_progress: { label: "In Progress", color: "bg-blue-500/10 text-blue-400 border-blue-500/20",     icon: Clock },
    resolved:    { label: "Resolved",    color: "bg-white/8 text-white/50 border-white/10",            icon: CheckCircle },
    closed:      { label: "Closed",      color: "bg-white/5 text-white/30 border-white/8",             icon: XCircle },
  };
  const s = map[status] ?? map.open;
  const Icon = s.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium ${s.color}`}>
      <Icon className="w-3 h-3" />{s.label}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: SupportTicket["priority"] }) {
  const map: Record<string, { label: string; color: string }> = {
    low:    { label: "Low",    color: "bg-white/5 text-white/30 border-white/8" },
    normal: { label: "Normal", color: "bg-white/8 text-white/50 border-white/10" },
    high:   { label: "High",   color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
    urgent: { label: "Urgent", color: "bg-red-500/10 text-red-400 border-red-500/20" },
  };
  const p = map[priority] ?? map.normal;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium ${p.color}`}>
      <Tag className="w-2.5 h-2.5" />{p.label}
    </span>
  );
}
