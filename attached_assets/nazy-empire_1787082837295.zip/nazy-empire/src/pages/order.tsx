import { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  ArrowLeft, ArrowRight, CheckCircle, Loader2,
  CheckCircle2, XCircle, AlertCircle, Server, Cpu, Globe,
} from "lucide-react";
import { BrandLockup } from "@/components/mic-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/lib/auth";
import { AuthModal } from "@/components/auth-modal";
import { api, type PublicSettings, type HostingPlan } from "@/lib/api";

declare global {
  interface Window {
    PaystackPop: {
      setup(opts: {
        key: string; email: string; amount: number; ref: string;
        onClose: () => void; callback: (response: { reference: string }) => void;
      }): { openIframe(): void };
    };
  }
}

const fmt = (n: number) =>
  "₦" + n.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const SUPPORTED_TLDS = [".com", ".ng", ".net", ".com.ng", ".edu.ng", ".org", ".biz", ".xyz"];

// These TLDs cannot be checked via the API — a specialist will confirm availability
const SPECIALIST_TLDS = new Set([".com.ng", ".edu.ng"]);

// Website types that require VPS hosting (no shared hosting available)
const VPS_ONLY_TYPES = new Set([
  "Business Website & App",
  "E-learning Website & App",
  "E-commerce Store & App",
  "Custom Web Application",
]);

const DEFAULT_WEBSITE_PRICES: Record<string, number> = {
  "Landing Page": 32000, "Personal Portfolio": 40000, "Blog Website & App": 48000,
  "School Website & App": 64000, "Church Website & App": 64000, "NGO Website & App": 72000,
  "Business Website & App": 80000, "Company Website & App": 96000, "Real Estate Website & App": 112000,
  "Hotel Website & App": 120000, "Restaurant Website & App": 120000, "News Website & App": 128000,
  "Directory Website & App": 144000, "E-learning Website & App": 160000, "Membership Website & App": 176000,
  "Booking Website & App": 192000, "Job Portal": 208000, "Marketplace Website & App": 240000,
  "E-commerce Store & App": 256000, "Custom Web Application": 400000,
};

const DEFAULT_TLD_PRICES: Record<string, number> = {
  ".com": 16067.31, ".ng": 9855.27, ".net": 31065.53, ".com.ng": 3213.68,
  ".edu.ng": 16711.11, ".org": 18103.70, ".biz": 51472.36, ".xyz": 36957.26,
};

const DEFAULT_HOSTING_PLANS: Record<string, HostingPlan> = {
  Starter:                { monthly: 1391.25,  annual: 16695,    features: ["8GB Webspace","30GB Bandwidth","10 Subdomains","2 Addon Domains","Free SSL","Unlimited Emails","Unlimited DB"] },
  Business:               { monthly: 1947.75,  annual: 23373,    features: ["15GB Webspace","45GB Bandwidth","15 Subdomains","3 Addon Domains","Free SSL","Unlimited Emails","Unlimited DB"] },
  Professional:           { monthly: 2504.25,  annual: 30051,    features: ["30GB Webspace","60GB Bandwidth","20 Subdomains","5 Addon Domains","Free SSL","Unlimited Emails","Unlimited DB"] },
  Enterprise:             { monthly: 3060.75,  annual: 36729,    features: ["120GB Webspace","150GB Bandwidth","40 Subdomains","10 Addon Domains","Free SSL","Unlimited Emails","Unlimited DB"] },
  "Starter VPS":          { monthly: 20833,    annual: 250000,   features: ["2 vCPU Cores","4 GB RAM","80 GB SSD/NVMe","2 TB Monthly Transfer","1 Dedicated IPv4"] },
  "Pro Business VPS":     { monthly: 58333,    annual: 700000,   features: ["4 vCPU Cores","12 GB RAM","250 GB NVMe","5 TB Monthly Transfer","2 Dedicated IPv4"] },
  "Elite VPS":            { monthly: 166666,   annual: 2000000,  features: ["12 vCPU Cores","32 GB RAM","600 GB Enterprise NVMe","Unmetered / 15 TB Transfer","3 Dedicated IPv4"] },
};

const VPS_PLAN_NAMES = new Set(["Starter VPS", "Pro Business VPS", "Elite VPS"]);
const RECOMMENDED_PLANS = new Set(["Business", "Pro Business VPS"]);
const HOSTING_DISCOUNT: Record<number, number> = { 1: 0, 2: 0.10, 3: 0.20 };
const PERIOD_OPTIONS: { y: number; discount: string | null }[] = [
  { y: 1, discount: null },
  { y: 2, discount: "Save 10%" },
  { y: 3, discount: "Save 20%" },
];

function parseDomainParts(input: string): { sld: string; tld: string | null } {
  const cleaned = input
    .toLowerCase()
    .trim()
    .replace(/^https?:\/\//, "")  // strip protocol
    .split("/")[0]                 // strip path
    .replace(/^www\./, "");       // strip leading www.
  const matchedTld = SUPPORTED_TLDS.slice()
    .sort((a, b) => b.length - a.length)
    .find((tld) => cleaned.endsWith(tld));
  if (!matchedTld) return { sld: cleaned, tld: null };
  const sld = cleaned.slice(0, cleaned.length - matchedTld.length);
  // Validate SLD: ≥2 chars, alphanumeric + hyphens, no leading/trailing hyphen
  if (sld.length < 2 || !/^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/.test(sld)) {
    return { sld: cleaned, tld: null };
  }
  return { sld, tld: matchedTld };
}

type DomainStatus = "idle" | "checking" | "available" | "unavailable" | "error" | "unsupported" | "specialist";

export default function Order() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [authModal, setAuthModal] = useState<"login" | "register" | null>(null);
  const [settings, setSettings] = useState<PublicSettings | null>(null);
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Domain availability
  const [domainStatus, setDomainStatus] = useState<DomainStatus>("idle");
  const [domainTld, setDomainTld] = useState<string | null>(null);
  const domainCheckTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [form, setForm] = useState({
    websiteType: "",
    includesDomainHosting: false,
    domainName: "",
    domainPeriod: 1,
    hostingPlan: "Starter",
    hostingPeriod: 1,
    projectTitle: "",
    description: "",
    preferredCompletionDate: "",
    clientName: user?.name ?? "",
    clientEmail: user?.email ?? "",
    clientPhone: user?.phone ?? "",
    clientCompany: user?.company ?? "",
    clientCountry: user?.country ?? "",
  });

  useEffect(() => {
    api.settings.getPublic().then(setSettings).catch(() => {});
  }, []);

  useEffect(() => {
    if (user) {
      setForm((f) => ({
        ...f,
        clientName: f.clientName || user.name,
        clientEmail: f.clientEmail || user.email,
        clientPhone: f.clientPhone || user.phone || "",
        clientCompany: f.clientCompany || user.company || "",
        clientCountry: f.clientCountry || user.country || "",
      }));
    }
  }, [user]);

  const websitePrices = (settings?.websitePrices && Object.keys(settings.websitePrices).length > 0) ? settings.websitePrices : DEFAULT_WEBSITE_PRICES;
  const tldPrices = (settings?.tldPrices && Object.keys(settings.tldPrices).length > 0) ? settings.tldPrices : DEFAULT_TLD_PRICES;
  const hostingPlans = (settings?.hostingPlans && Object.keys(settings.hostingPlans).length > 0) ? settings.hostingPlans : DEFAULT_HOSTING_PLANS;

  const developmentFee = websitePrices[form.websiteType] ?? 0;

  const selectedTldPrice = domainTld ? (tldPrices[domainTld] ?? 0) : 0;
  const domainPrice = form.includesDomainHosting ? selectedTldPrice * form.domainPeriod : 0;

  const selectedPlan = hostingPlans[form.hostingPlan];
  const hostingAnnual = selectedPlan?.annual ?? 0;
  const hostingDiscount = HOSTING_DISCOUNT[form.hostingPeriod] ?? 0;
  const hostingFullPrice = hostingAnnual * form.hostingPeriod;
  const hostingPrice = form.includesDomainHosting
    ? Math.round(hostingFullPrice * (1 - hostingDiscount))
    : 0;
  const hostingSavings = form.includesDomainHosting ? Math.round(hostingFullPrice * hostingDiscount) : 0;

  const totalAmount = developmentFee + domainPrice + hostingPrice;

  function setField(key: string, val: unknown) {
    setForm((f) => ({ ...f, [key]: val }));
    setError("");
  }

  // Domain availability check (debounced).
  // Local parse gives instant UX feedback (unsupported TLD); then passes the full
  // raw string to the backend which re-parses and calls the API.
  const checkDomain = useCallback(async (domain: string) => {
    const { sld, tld } = parseDomainParts(domain);

    // Immediate local feedback — no network call needed
    if (!sld || sld.length < 2) { setDomainStatus("idle"); return; }
    if (!tld) { setDomainTld(null); setDomainStatus("unsupported"); return; }

    setDomainTld(tld);

    // .com.ng and .edu.ng require specialist confirmation — skip API check
    if (SPECIALIST_TLDS.has(tld)) { setDomainStatus("specialist"); return; }

    setDomainStatus("checking");
    try {
      // Pass full domain string; backend handles parsing + API call
      const result = await api.domains.check(domain);
      // Backend returns isAvailable; fall back to available for compat
      const ok = result.isAvailable ?? result.available;
      // Prefer server-returned tld/price (handles edge cases)
      if (result.tld) setDomainTld(result.tld);
      if (ok === true) setDomainStatus("available");
      else if (ok === false) setDomainStatus("unavailable");
      else setDomainStatus("error");
    } catch {
      setDomainStatus("error");
    }
  }, []);

  function handleDomainChange(value: string) {
    setField("domainName", value);
    if (domainCheckTimer.current) clearTimeout(domainCheckTimer.current);
    setDomainStatus("idle");
    if (value.length > 3) {
      domainCheckTimer.current = setTimeout(() => checkDomain(value), 600);
    }
  }

  // Derived: which hosting plans to show based on website type
  const isVpsOnly = VPS_ONLY_TYPES.has(form.websiteType);
  const visiblePlans = Object.entries(hostingPlans).filter(([name]) =>
    isVpsOnly ? VPS_PLAN_NAMES.has(name) : true
  );

  // Auto-switch hosting plan when website type changes
  useEffect(() => {
    if (isVpsOnly && !VPS_PLAN_NAMES.has(form.hostingPlan)) {
      setField("hostingPlan", "Starter VPS");
    } else if (!isVpsOnly && VPS_PLAN_NAMES.has(form.hostingPlan)) {
      setField("hostingPlan", "Starter");
    }
  }, [isVpsOnly]);

  function canProceedStep1() {
    if (!form.websiteType || !developmentFee) return false;
    if (form.includesDomainHosting) {
      if (!form.domainName) return false;
      if (domainStatus === "unavailable" || domainStatus === "unsupported") return false;
    }
    return true;
  }

  function canProceedStep2() {
    return !!(form.clientName && form.clientEmail);
  }

  async function handleSubmitOrder() {
    if (!user) { setAuthModal("login"); return; }
    setLoading(true);
    setError("");
    try {
      const { sld, tld } = parseDomainParts(form.domainName);
      const project = await api.projects.create({
        websiteType: form.websiteType,
        developmentFee,
        includesDomainHosting: form.includesDomainHosting,
        domainName: form.includesDomainHosting && form.domainName ? `${sld}${tld}` : undefined,
        domainTld: tld ?? undefined,
        domainPeriod: form.includesDomainHosting ? form.domainPeriod : undefined,
        domainPrice,
        hostingPlan: form.includesDomainHosting ? form.hostingPlan : undefined,
        hostingPrice: form.includesDomainHosting ? hostingAnnual : 0,
        hostingPeriod: form.includesDomainHosting ? form.hostingPeriod : undefined,
        servicePeriod: form.hostingPeriod,
        totalAmount,
        projectTitle: form.projectTitle || undefined,
        description: form.description || undefined,
        preferredCompletionDate: form.preferredCompletionDate || undefined,
        clientName: form.clientName,
        clientEmail: form.clientEmail,
        clientPhone: form.clientPhone || undefined,
        clientCompany: form.clientCompany || undefined,
        clientCountry: form.clientCountry || undefined,
        affiliateRef: localStorage.getItem("affiliateRef") ?? undefined,
      });
      await initiatePayment(project.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Order failed");
      setLoading(false);
    }
  }

  async function initiatePayment(projectId: number) {
    try {
      const payData = await api.payments.initialize(projectId);
      const scriptId = "paystack-js";
      if (!document.getElementById(scriptId)) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement("script");
          script.id = scriptId;
          script.src = "https://js.paystack.co/v1/inline.js";
          script.onload = () => resolve();
          script.onerror = () => reject(new Error("Failed to load Paystack"));
          document.head.appendChild(script);
        });
      }
      const handler = window.PaystackPop.setup({
        key: payData.publicKey,
        email: payData.email,
        amount: payData.amountKobo,
        ref: payData.reference,
        onClose() { setLoading(false); setError("Payment was cancelled. You can pay from your dashboard."); },
        callback(response) { setLocation(`/thank-you?reference=${response.reference}`); },
      });
      handler.openIframe();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Payment initialization failed");
      setLoading(false);
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const DomainBadge = () => {
    if (domainStatus === "idle") return null;
    if (domainStatus === "checking") return (
      <span className="flex items-center gap-1 text-xs text-white/50">
        <Loader2 className="w-3 h-3 animate-spin" /> Checking…
      </span>
    );
    if (domainStatus === "available") return (
      <span className="flex items-center gap-1 text-xs text-green-400">
        <CheckCircle2 className="w-3.5 h-3.5" /> Available
        {domainTld && selectedTldPrice > 0 && <span className="text-white/40">· {fmt(selectedTldPrice)}/yr</span>}
      </span>
    );
    if (domainStatus === "unavailable") return (
      <span className="flex items-center gap-1 text-xs text-red-400">
        <XCircle className="w-3.5 h-3.5" /> Not available — try a different name
      </span>
    );
    if (domainStatus === "unsupported") return (
      <span className="flex items-center gap-1 text-xs text-orange-400">
        <AlertCircle className="w-3.5 h-3.5" /> Unsupported TLD. Use: {SUPPORTED_TLDS.join(", ")}
      </span>
    );
    if (domainStatus === "specialist") return (
      <span className="flex items-center gap-1 text-xs text-blue-400">
        <AlertCircle className="w-3.5 h-3.5" /> Availability will be confirmed by a specialist — you may proceed
      </span>
    );
    return (
      <span className="flex items-center gap-1 text-xs text-white/30">
        <AlertCircle className="w-3.5 h-3.5" /> Could not verify — you may still proceed
      </span>
    );
  };

  return (
    <>
      <div className="min-h-screen bg-black">
        <div className="bg-black/90 backdrop-blur-md border-b border-white/10 px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <BrandLockup iconSize="w-6 h-7" textSize="text-xl" />
          </Link>
          <Link href="/" className="text-white/50 hover:text-white text-sm flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" /> Back to Site
          </Link>
        </div>

        <div className="max-w-2xl mx-auto px-4 py-12">
          {/* Progress steps */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-2">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                    step > s ? "bg-primary text-black" : step === s ? "bg-primary/20 border-2 border-primary text-primary" : "bg-white/5 text-white/30"
                  }`}>
                    {step > s ? <CheckCircle className="w-4 h-4" /> : s}
                  </div>
                  {s < 3 && <div className={`h-0.5 w-12 ${step > s ? "bg-primary" : "bg-white/10"}`} />}
                </div>
              ))}
            </div>
            <div className="flex gap-12 text-xs text-white/40">
              <span className={step >= 1 ? "text-primary" : ""}>Service</span>
              <span className={step >= 2 ? "text-primary" : ""}>Details</span>
              <span className={step >= 3 ? "text-primary" : ""}>Review</span>
            </div>
          </div>

          {/* Step 1: Service Selection */}
          {step === 1 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="font-display text-4xl text-white mb-2">CHOOSE SERVICE</h1>
              <p className="text-white/50 mb-8">Select the type of website & app you want built.</p>
              <div className="space-y-6">
                {/* Website & App type */}
                <div className="space-y-2">
                  <Label>Website & App Type *</Label>
                  <select
                    value={form.websiteType}
                    onChange={(e) => setField("websiteType", e.target.value)}
                    className="w-full bg-card border border-input rounded-md px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-ring appearance-none cursor-pointer"
                    style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 12px center" }}
                  >
                    <option value="" disabled>Select website & app type…</option>
                    {Object.entries(websitePrices).map(([type, price]) => (
                      <option key={type} value={type}>{type} — {fmt(price)}</option>
                    ))}
                  </select>
                </div>

                {developmentFee > 0 && (
                  <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                    <div className="text-primary font-bold text-2xl">{fmt(developmentFee)}</div>
                    <div className="text-white/50 text-sm">Development fee for {form.websiteType}</div>
                  </div>
                )}

                {/* Domain + Hosting toggle */}
                <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
                  <div>
                    <div className="text-white font-medium">Include Domain & Hosting</div>
                    <div className="text-white/40 text-sm">Add domain registration and web hosting</div>
                  </div>
                  <Switch
                    checked={form.includesDomainHosting}
                    onCheckedChange={(v) => { setField("includesDomainHosting", v); setDomainStatus("idle"); }}
                  />
                </div>

                {form.includesDomainHosting && (
                  <div className="space-y-6">
                    {/* Domain section */}
                    <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                      <h3 className="text-white font-semibold flex items-center gap-2">
                        <Globe className="w-4 h-4 text-primary" /> Domain Registration
                      </h3>
                      <div className="space-y-2">
                        <Label>Domain Name</Label>
                        <Input
                          placeholder="e.g. mybusiness.com or mybusiness.com.ng"
                          value={form.domainName}
                          onChange={(e) => handleDomainChange(e.target.value)}
                        />
                        <div className="h-4 flex items-center">
                          <DomainBadge />
                        </div>
                        <p className="text-white/30 text-xs">
                          Supported: {SUPPORTED_TLDS.join(" · ")}
                        </p>
                        <p className="text-blue-400/70 text-xs mt-1">
                          ℹ️ <strong>.com.ng</strong> and <strong>.edu.ng</strong> extensions require specialist approval — domain availability will be confirmed by our team before registration.
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label>Domain Period</Label>
                        <div className="flex gap-2">
                          {[1, 2, 3].map((y) => (
                            <button
                              key={y}
                              type="button"
                              onClick={() => setField("domainPeriod", y)}
                              className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-all ${
                                form.domainPeriod === y
                                  ? "bg-primary/10 border-primary text-primary"
                                  : "border-border text-white/50 hover:text-white hover:border-white/30"
                              }`}
                            >
                              {y} yr{y > 1 ? "s" : ""}
                              {domainTld && selectedTldPrice > 0 && (
                                <div className="text-xs font-normal opacity-70">{fmt(selectedTldPrice * y)}</div>
                              )}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Hosting plan section */}
                    <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                      <h3 className="text-white font-semibold flex items-center gap-2">
                        {isVpsOnly ? <Cpu className="w-4 h-4 text-primary" /> : <Server className="w-4 h-4 text-primary" />}
                        Hosting Plan
                      </h3>
                      {isVpsOnly && (
                        <p className="text-xs text-blue-400/80 bg-blue-400/10 border border-blue-400/20 rounded-lg px-3 py-2">
                          ⚡ <strong>{form.websiteType}</strong> requires a VPS plan for the resources and performance it demands.
                        </p>
                      )}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {visiblePlans.map(([name, plan]) => {
                          const isRecommended = RECOMMENDED_PLANS.has(name);
                          const isSelected = form.hostingPlan === name;
                          return (
                            <button
                              key={name}
                              type="button"
                              onClick={() => setField("hostingPlan", name)}
                              className={`relative p-4 rounded-lg border text-left transition-all ${
                                isSelected
                                  ? "border-primary bg-primary/10"
                                  : isRecommended
                                  ? "border-primary/40 hover:border-primary/70"
                                  : "border-border hover:border-white/30"
                              }`}
                            >
                              {isRecommended && (
                                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                                  <span className="bg-primary text-black text-[10px] font-bold px-2.5 py-0.5 rounded-full whitespace-nowrap tracking-wide uppercase">
                                    Most Popular
                                  </span>
                                </div>
                              )}
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-white font-semibold text-sm">{name}</span>
                                {isSelected && <CheckCircle2 className="w-4 h-4 text-primary" />}
                              </div>
                              <div className="text-primary font-bold">{fmt(plan.monthly)}<span className="text-white/30 text-xs font-normal">/mo</span></div>
                              <div className="text-white/30 text-xs mt-1">{fmt(plan.annual)}/year</div>
                              <ul className="mt-2 space-y-0.5">
                                {plan.features.map((f) => (
                                  <li key={f} className="text-white/40 text-xs flex items-center gap-1">
                                    <span className="text-primary/60">·</span> {f}
                                  </li>
                                ))}
                              </ul>
                            </button>
                          );
                        })}
                      </div>
                      <div className="space-y-2">
                        <Label>Hosting Period <span className="text-white/30 text-xs">(billed yearly)</span></Label>
                        <div className="flex gap-2">
                          {PERIOD_OPTIONS.map(({ y, discount }) => (
                            <button
                              key={y}
                              type="button"
                              onClick={() => setField("hostingPeriod", y)}
                              className={`relative flex-1 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                                form.hostingPeriod === y
                                  ? "bg-primary/10 border-primary text-primary"
                                  : discount
                                  ? "border-green-500/30 text-white/60 hover:text-white hover:border-green-500/60"
                                  : "border-border text-white/50 hover:text-white hover:border-white/30"
                              }`}
                            >
                              {discount && (
                                <span className={`absolute -top-2.5 left-1/2 -translate-x-1/2 text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap tracking-wide uppercase ${
                                  form.hostingPeriod === y
                                    ? "bg-green-500 text-black"
                                    : "bg-green-500/20 text-green-400 border border-green-500/30"
                                }`}>
                                  {discount}
                                </span>
                              )}
                              {y} yr{y > 1 ? "s" : ""}
                              <div className="text-xs font-normal opacity-60 mt-0.5">
                                {fmt(Math.round(hostingAnnual * y * (1 - (HOSTING_DISCOUNT[y] ?? 0))))}
                              </div>
                            </button>
                          ))}
                        </div>
                        {hostingSavings > 0 && (
                          <div className="flex items-center gap-2 mt-1 px-1">
                            <span className="text-green-400 text-sm font-semibold">
                              🎉 You save {fmt(hostingSavings)}
                            </span>
                            <span className="text-white/30 text-xs">
                              vs paying year-by-year
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Price summary */}
                {totalAmount > 0 && (
                  <div className="p-4 bg-card border border-border rounded-lg">
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between text-white/50">
                        <span>Development Fee</span><span>{fmt(developmentFee)}</span>
                      </div>
                      {form.includesDomainHosting && domainPrice > 0 && (
                        <div className="flex justify-between text-white/50">
                          <span>Domain ({form.domainPeriod} yr{form.domainPeriod > 1 ? "s" : ""})</span>
                          <span>{fmt(domainPrice)}</span>
                        </div>
                      )}
                      {form.includesDomainHosting && hostingPrice > 0 && (
                        <div className="flex justify-between text-white/50">
                          <span>{form.hostingPlan} Hosting ({form.hostingPeriod} yr{form.hostingPeriod > 1 ? "s" : ""})</span>
                          <span>{fmt(hostingPrice)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-white font-bold text-lg border-t border-border pt-2 mt-2">
                        <span>Total</span><span className="text-primary">{fmt(totalAmount)}</span>
                      </div>
                    </div>
                  </div>
                )}

                <Button
                  onClick={() => setStep(2)}
                  disabled={!canProceedStep1()}
                  className="w-full bg-primary text-black hover:bg-primary/90 font-bold"
                >
                  Continue <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Client Details */}
          {step === 2 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="font-display text-4xl text-white mb-2">YOUR DETAILS</h1>
              <p className="text-white/50 mb-8">Tell us about yourself and your project.</p>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label>Full Name *</Label>
                    <Input value={form.clientName} onChange={(e) => setField("clientName", e.target.value)} required />
                  </div>
                  <div className="space-y-1">
                    <Label>Email *</Label>
                    <Input type="email" value={form.clientEmail} onChange={(e) => setField("clientEmail", e.target.value)} required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label>Phone</Label>
                    <Input value={form.clientPhone} onChange={(e) => setField("clientPhone", e.target.value)} />
                  </div>
                  <div className="space-y-1">
                    <Label>Country</Label>
                    <Input value={form.clientCountry} onChange={(e) => setField("clientCountry", e.target.value)} />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label>Company / Organization</Label>
                  <Input value={form.clientCompany} onChange={(e) => setField("clientCompany", e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Project Title</Label>
                  <Input placeholder="e.g. ABC Company Website" value={form.projectTitle} onChange={(e) => setField("projectTitle", e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Project Description</Label>
                  <Textarea
                    placeholder="Tell us about your business, your goals, any specific features you need…"
                    rows={4}
                    value={form.description}
                    onChange={(e) => setField("description", e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Preferred Completion Date</Label>
                  <Input
                    type="date"
                    value={form.preferredCompletionDate}
                    onChange={(e) => setField("preferredCompletionDate", e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1 border-white/20">
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <Button
                    onClick={() => setStep(3)}
                    disabled={!canProceedStep2()}
                    className="flex-1 bg-primary text-black hover:bg-primary/90 font-bold"
                  >
                    Review Order <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Review & Pay */}
          {step === 3 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="font-display text-4xl text-white mb-2">REVIEW ORDER</h1>
              <p className="text-white/50 mb-8">Review your order before payment.</p>
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-xl p-6 space-y-3">
                  <h3 className="text-white font-semibold mb-4">Service Summary</h3>
                  {[
                    ["Website & App Type", form.websiteType],
                    ["Development Fee", fmt(developmentFee)],
                    ...(form.includesDomainHosting ? [
                      ["Domain", form.domainName || "TBD"],
                      ["Domain Period", `${form.domainPeriod} year${form.domainPeriod > 1 ? "s" : ""}`],
                      ["Domain Price", fmt(domainPrice)],
                      ["Hosting Plan", form.hostingPlan],
                      ["Hosting Period", `${form.hostingPeriod} year${form.hostingPeriod > 1 ? "s" : ""}`],
                      ["Hosting Price", fmt(hostingPrice)],
                    ] : []),
                  ].map(([label, value]) => (
                    <div key={label} className="flex justify-between text-sm">
                      <span className="text-white/50">{label}</span>
                      <span className="text-white">{value}</span>
                    </div>
                  ))}
                  <div className="flex justify-between font-bold text-lg border-t border-border pt-3">
                    <span className="text-white">Total</span>
                    <span className="text-primary">{fmt(totalAmount)}</span>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-xl p-6 space-y-3">
                  <h3 className="text-white font-semibold mb-4">Client Details</h3>
                  {[
                    ["Name", form.clientName],
                    ["Email", form.clientEmail],
                    form.clientPhone ? ["Phone", form.clientPhone] : null,
                    form.clientCountry ? ["Country", form.clientCountry] : null,
                    form.clientCompany ? ["Company", form.clientCompany] : null,
                    form.projectTitle ? ["Project Title", form.projectTitle] : null,
                    form.preferredCompletionDate ? ["Completion Date", form.preferredCompletionDate] : null,
                  ].filter(Boolean).map((row) => {
                    const [label, value] = row as [string, string];
                    return (
                      <div key={label} className="flex justify-between text-sm">
                        <span className="text-white/50">{label}</span>
                        <span className="text-white">{value}</span>
                      </div>
                    );
                  })}
                </div>

                {form.description && (
                  <div className="bg-card border border-border rounded-xl p-6">
                    <h3 className="text-white font-semibold mb-2">Project Description</h3>
                    <p className="text-white/60 text-sm">{form.description}</p>
                  </div>
                )}

                {!user && (
                  <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                    <p className="text-white/70 text-sm">
                      You need to be logged in to place an order.{" "}
                      <button onClick={() => setAuthModal("login")} className="text-primary hover:underline font-medium">
                        Login or register
                      </button>
                    </p>
                  </div>
                )}

                {error && <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">{error}</div>}

                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setStep(2)} className="flex-1 border-white/20" disabled={loading}>
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <Button
                    onClick={handleSubmitOrder}
                    disabled={loading}
                    className="flex-1 bg-primary text-black hover:bg-primary/90 font-bold"
                  >
                    {loading ? "Processing…" : `Pay ${fmt(totalAmount)} Now`}
                  </Button>
                </div>
                <p className="text-white/30 text-xs text-center">Secure payment powered by Paystack</p>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {authModal && (
        <AuthModal
          mode={authModal}
          onClose={() => setAuthModal(null)}
          onSwitch={(m) => setAuthModal(m)}
        />
      )}
    </>
  );
}
