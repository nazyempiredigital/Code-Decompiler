import { useEffect, useState, useRef } from "react";
import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import { Calendar, Tag, User, ArrowLeft, Share2, BookOpen, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api, type BlogPost } from "@/lib/api";

function formatDate(d: string | null | undefined) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-NG", { year: "numeric", month: "long", day: "numeric" });
}

/** Inject or update a <meta> tag */
function setMeta(name: string, content: string, property = false) {
  const attr = property ? "property" : "name";
  let el = document.querySelector(`meta[${attr}="${name}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

/** Inject JSON-LD structured data for Article */
function injectStructuredData(post: BlogPost) {
  const existing = document.getElementById("blog-json-ld");
  if (existing) existing.remove();
  const script = document.createElement("script");
  script.id = "blog-json-ld";
  script.type = "application/ld+json";
  script.textContent = JSON.stringify({
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.metaTitle || post.title,
    description: post.metaDescription || post.excerpt || "",
    image: post.ogImage || post.featuredImage || "",
    author: { "@type": "Person", name: post.author || "Nazy Empire" },
    publisher: {
      "@type": "Organization",
      name: "Nazy Empire",
      url: "https://nazyempire.com",
    },
    datePublished: post.publishedAt || post.createdAt,
    dateModified: post.updatedAt,
    url: post.canonicalUrl || window.location.href,
    keywords: post.metaKeywords || post.tags || "",
    articleSection: post.category || "General",
  });
  document.head.appendChild(script);
}

/** Clean up injected tags on unmount */
function cleanupSEO(originalTitle: string) {
  document.title = originalTitle;
  document.getElementById("blog-json-ld")?.remove();
  document.querySelector('link[rel="canonical"]')?.remove();
}

/** Render post content — supports simple markdown-like headings, bold, lists */
function PostContent({ content }: { content: string }) {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];
  let listKey = 0;

  function flushList() {
    if (listItems.length > 0) {
      elements.push(
        <ul key={`ul-${listKey++}`} className="list-disc list-inside space-y-2 text-white/70 leading-relaxed my-4 pl-2">
          {listItems.map((li, i) => <li key={i}>{renderInline(li)}</li>)}
        </ul>
      );
      listItems = [];
    }
  }

  function renderInline(text: string): React.ReactNode {
    // Bold: **text**
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return <strong key={i} className="text-white font-semibold">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  }

  lines.forEach((line, i) => {
    const trimmed = line.trim();
    if (!trimmed) { flushList(); elements.push(<div key={`br-${i}`} className="h-4" />); return; }
    if (trimmed.startsWith("## ")) { flushList(); elements.push(<h2 key={i} className="font-display text-2xl md:text-3xl text-white mt-10 mb-4">{trimmed.slice(3)}</h2>); return; }
    if (trimmed.startsWith("### ")) { flushList(); elements.push(<h3 key={i} className="font-semibold text-lg text-white mt-6 mb-3">{trimmed.slice(4)}</h3>); return; }
    if (trimmed.startsWith("#### ")) { flushList(); elements.push(<h4 key={i} className="font-semibold text-white mt-4 mb-2">{trimmed.slice(5)}</h4>); return; }
    if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) { listItems.push(trimmed.slice(2)); return; }
    if (trimmed.startsWith("> ")) {
      flushList();
      elements.push(
        <blockquote key={i} className="border-l-4 border-primary pl-4 py-1 my-4 text-white/60 italic">
          {renderInline(trimmed.slice(2))}
        </blockquote>
      );
      return;
    }
    flushList();
    elements.push(<p key={i} className="text-white/70 leading-relaxed my-3">{renderInline(trimmed)}</p>);
  });

  flushList();
  return <div className="prose-custom">{elements}</div>;
}

export default function BlogPostPage() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [copied, setCopied] = useState(false);
  const originalTitle = useRef(document.title);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    api.blog.bySlug(slug)
      .then((p) => {
        setPost(p);

        // SEO: title
        const pageTitle = p.metaTitle || p.title;
        document.title = `${pageTitle} | Nazy Empire`;

        // SEO: standard meta
        setMeta("description", p.metaDescription || p.excerpt || "");
        if (p.metaKeywords) setMeta("keywords", p.metaKeywords);
        setMeta("author", p.author || "Nazy Empire");
        setMeta("robots", "index, follow");

        // Open Graph
        setMeta("og:type", "article", true);
        setMeta("og:title", p.ogTitle || pageTitle, true);
        setMeta("og:description", p.ogDescription || p.metaDescription || p.excerpt || "", true);
        setMeta("og:image", p.ogImage || p.featuredImage || "", true);
        setMeta("og:url", p.canonicalUrl || window.location.href, true);
        setMeta("og:site_name", "Nazy Empire", true);

        // Twitter Card
        setMeta("twitter:card", "summary_large_image");
        setMeta("twitter:title", p.ogTitle || pageTitle);
        setMeta("twitter:description", p.ogDescription || p.metaDescription || p.excerpt || "");
        setMeta("twitter:image", p.ogImage || p.featuredImage || "");

        // Canonical
        if (p.canonicalUrl) {
          let link = document.querySelector('link[rel="canonical"]');
          if (!link) { link = document.createElement("link"); link.setAttribute("rel", "canonical"); document.head.appendChild(link); }
          link.setAttribute("href", p.canonicalUrl);
        }

        // JSON-LD
        injectStructuredData(p);
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));

    return () => cleanupSEO(originalTitle.current);
  }, [slug]);

  async function share() {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      if (navigator.share) navigator.share({ title: post?.title, url });
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (notFound || !post) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="text-center">
          <BookOpen className="w-12 h-12 text-white/20 mx-auto mb-4" />
          <h1 className="font-display text-4xl text-white mb-3">POST NOT FOUND</h1>
          <p className="text-white/40 mb-8">This article doesn't exist or has been removed.</p>
          <Link href="/blog"><Button className="bg-primary text-black hover:bg-primary/90 font-bold">Back to Blog</Button></Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero */}
      <section className="relative pt-28 pb-0 bg-gradient-to-b from-zinc-950 to-black">
        {post.featuredImage && (
          <div className="absolute inset-0 overflow-hidden opacity-10">
            <img src={post.featuredImage} alt="" className="w-full h-full object-cover blur-2xl" />
          </div>
        )}
        <div className="container mx-auto px-4 relative">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto">
            <Link href="/blog">
              <button className="flex items-center gap-2 text-white/40 hover:text-primary text-sm mb-8 transition-colors">
                <ArrowLeft className="w-4 h-4" /> Back to Blog
              </button>
            </Link>
            {post.category && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium mb-4">
                <Tag className="w-3 h-3" /> {post.category}
              </span>
            )}
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-white mb-6 leading-tight">{post.title}</h1>
            {post.excerpt && (
              <p className="text-white/60 text-lg leading-relaxed mb-8">{post.excerpt}</p>
            )}
            <div className="flex items-center justify-between flex-wrap gap-4 pb-8 border-b border-white/10">
              <div className="flex items-center gap-4 text-white/40 text-sm">
                <span className="flex items-center gap-1.5"><User className="w-4 h-4" />{post.author || "Nazy Empire"}</span>
                {post.publishedAt && <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" />{formatDate(post.publishedAt)}</span>}
              </div>
              <button
                onClick={share}
                className="flex items-center gap-2 text-white/40 hover:text-primary text-sm transition-colors"
              >
                <Share2 className="w-4 h-4" />
                {copied ? "Link copied!" : "Share article"}
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured image */}
      {post.featuredImage && (
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto">
            <div className="rounded-2xl overflow-hidden border border-white/10 bg-zinc-900 max-h-[480px]">
              <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <article className="container mx-auto px-4 py-8 pb-20">
        <div className="max-w-3xl mx-auto">
          <PostContent content={post.content} />

          {/* Tags */}
          {post.tags && (
            <div className="mt-12 pt-8 border-t border-white/10">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-3">Tags</p>
              <div className="flex flex-wrap gap-2">
                {post.tags.split(",").map((tag) => tag.trim()).filter(Boolean).map((tag) => (
                  <span key={tag} className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-white/50 text-xs">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </article>

      {/* CTA */}
      <section className="py-20 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 text-center max-w-2xl">
          <h2 className="font-display text-4xl text-white mb-4">READY TO GET STARTED?</h2>
          <p className="text-white/50 mb-8">
            From web development and domain registration to music distribution — your digital empire starts here.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/order">
              <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold px-8">
                Start Your Project <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/blog">
              <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8">
                More Articles
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
