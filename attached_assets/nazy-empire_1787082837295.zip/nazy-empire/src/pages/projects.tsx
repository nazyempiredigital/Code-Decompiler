import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { ExternalLink, ArrowLeft, Layers } from "lucide-react";
import { api, type PortfolioProject } from "@/lib/api";

export default function Projects() {
  const [projects, setProjects] = useState<PortfolioProject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");

  useEffect(() => {
    api.portfolio
      .list()
      .then((data) =>
        // Newest first: higher id = more recently added
        setProjects([...data].sort((a, b) => b.id - a.id))
      )
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  const categories = ["All", ...Array.from(new Set(projects.map((p) => p.category).filter(Boolean)))];
  const filtered =
    activeCategory === "All" ? projects : projects.filter((p) => p.category === activeCategory);

  return (
    <div className="pt-16 min-h-screen bg-black">
      {/* Hero */}
      <section className="bg-gradient-to-b from-zinc-950 to-black py-20 border-b border-white/10">
        <div className="container mx-auto px-4">
          <Link href="/" className="inline-flex items-center gap-2 text-white/40 hover:text-primary text-sm mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Home
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="font-display text-6xl md:text-7xl text-white mb-4">OUR WORK</h1>
            <p className="text-white/50 text-lg max-w-2xl">
              Every project we deliver — websites, apps, and digital experiences built for clients across Africa and beyond.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter tabs */}
      {categories.length > 1 && (
        <div className="sticky top-16 z-30 bg-black/90 backdrop-blur-md border-b border-white/10">
          <div className="container mx-auto px-4">
            <div className="flex gap-1 overflow-x-auto py-3 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                    activeCategory === cat
                      ? "bg-primary text-black"
                      : "text-white/50 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Projects grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-72 bg-zinc-900 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-24">
              <Layers className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <p className="text-white/30">No projects found.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((project, i) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: (i % 6) * 0.07 }}
                  className="group relative overflow-hidden rounded-2xl bg-zinc-950 border border-white/10 hover:border-primary/40 transition-all duration-300"
                >
                  {/* Image */}
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={project.imageUrl}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    {project.category && (
                      <span className="inline-block px-2.5 py-0.5 rounded-full bg-primary/15 border border-primary/25 text-primary text-xs font-medium mb-3">
                        {project.category}
                      </span>
                    )}
                    <h3 className="text-white font-semibold text-lg mb-2 leading-snug">{project.title}</h3>
                    {project.description && (
                      <p className="text-white/50 text-sm leading-relaxed mb-4">{project.description}</p>
                    )}
                    {project.link && (
                      <a
                        href={project.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-4 py-2 bg-primary text-black text-xs font-bold rounded-lg hover:bg-primary/90 transition-colors"
                      >
                        Learn More <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-zinc-950 border-t border-white/10 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl md:text-5xl text-white mb-4">
            READY TO BUILD YOURS?
          </h2>
          <p className="text-white/50 mb-8 max-w-xl mx-auto">
            Join the growing list of clients who trust Nazy Empire to bring their vision to life.
          </p>
          <Link href="/order">
            <span className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-black font-bold rounded-lg hover:bg-primary/90 transition-colors">
              Start Your Project
            </span>
          </Link>
        </div>
      </section>
    </div>
  );
}
