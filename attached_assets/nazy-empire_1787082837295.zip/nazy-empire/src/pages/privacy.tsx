import { LegalPage } from "@/components/legal-page";
import { Link } from "wouter";

export default function Privacy() {
  return (
    <LegalPage
      title="PRIVACY POLICY"
      subtitle="NAZY EMPIRE DIGITAL is committed to protecting your personal data and respecting your privacy rights. This Policy explains what data we collect, why we collect it, how we use and protect it, and your rights under applicable law."
      effectiveDate="10 July 2026"
      lastReviewed="10 July 2026"
      sections={[
        {
          heading: "1. Identity of the Data Controller",
          content: (
            <>
              <p><strong>NAZY EMPIRE DIGITAL</strong> (CAC Business Name Registration No. BN 9657494, Enugu, Nigeria) is the data controller responsible for the personal data you provide through this website.</p>
              <p>Contact for privacy matters: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
            </>
          ),
        },
        {
          heading: "2. Legal Framework",
          content: (
            <>
              <p>This Policy is issued in compliance with the <strong>Nigeria Data Protection Act 2023 (NDPA)</strong> and the Nigeria Data Protection Regulation 2019 (NDPR). We also apply appropriate safeguards aligned with international data protection principles, including those of the <strong>EU General Data Protection Regulation (GDPR)</strong>, to the extent that they are more protective of your rights than Nigerian law.</p>
              <p>This website is operated from Nigeria. If you access it from outside Nigeria, your information may be transferred to and processed in Nigeria, a jurisdiction that may not provide the same level of data protection as your home country. By using this website, you consent to such transfer.</p>
            </>
          ),
        },
        {
          heading: "3. Data We Collect",
          content: (
            <>
              <p>We collect and process the following categories of personal data:</p>
              <h3>3.1 Data You Provide Directly</h3>
              <ul>
                <li><strong>Account registration:</strong> Full name, email address, phone number, and password (hashed; we cannot read it).</li>
                <li><strong>Order placement:</strong> Name, email, phone number, business name, project details, and billing address.</li>
                <li><strong>Contact enquiries:</strong> Name, email address, and the content of your message.</li>
                <li><strong>Artist applications:</strong> Name, stage name, biography, social media handles, and audio samples.</li>
              </ul>
              <h3>3.2 Payment Data</h3>
              <p>We do not store, process, or see your full payment card details. All payment transactions are processed by <strong>Paystack</strong> directly. We receive only a transaction reference, amount, and status from Paystack. Paystack is a PCI-DSS Level 1 certified processor and governs its own data under its <a href="https://paystack.com/terms" target="_blank" rel="noopener noreferrer">Privacy Policy</a>.</p>
              <h3>3.3 Automatically Collected Data</h3>
              <ul>
                <li>IP address and approximate geolocation (country/city level).</li>
                <li>Browser type, version, and operating system.</li>
                <li>Pages visited, time spent, referring URL.</li>
                <li>Device identifiers (where applicable).</li>
                <li>Cookie and tracking data (see our <Link href="/cookie-policy">Cookie Policy</Link>).</li>
              </ul>
              <h3>3.4 Data from Third Parties</h3>
              <p>We may receive limited information about you from payment processors, fraud-prevention services, or publicly available sources where relevant to verifying the legitimacy of a transaction or complying with legal obligations.</p>
            </>
          ),
        },
        {
          heading: "4. How We Use Your Data",
          content: (
            <>
              <p>We process your personal data for the following purposes and on the following legal bases:</p>
              <ul>
                <li><strong>Service delivery</strong> — Processing your orders, communicating project updates, provisioning hosting and domains, and distributing music. <em>Legal basis: Contract performance.</em></li>
                <li><strong>Account management</strong> — Creating and maintaining your user account, authenticating your identity, and enabling access to your dashboard. <em>Legal basis: Contract performance.</em></li>
                <li><strong>Payment processing</strong> — Passing transaction data to Paystack and recording payment status. <em>Legal basis: Contract performance.</em></li>
                <li><strong>Customer support</strong> — Responding to your enquiries, complaints, and support tickets. <em>Legal basis: Legitimate interest / contract performance.</em></li>
                <li><strong>Legal compliance</strong> — Retaining records as required by Nigerian tax, company, and financial regulations; responding to lawful requests from authorities. <em>Legal basis: Legal obligation.</em></li>
                <li><strong>Security and fraud prevention</strong> — Monitoring for suspicious activity, protecting the integrity of our systems. <em>Legal basis: Legitimate interest.</em></li>
                <li><strong>Service improvement</strong> — Analysing aggregate usage patterns to improve our website and services. We use anonymised or aggregated data for this purpose. <em>Legal basis: Legitimate interest.</em></li>
                <li><strong>Marketing communications</strong> — Sending you information about our services, promotions, or updates. <em>Legal basis: Consent (you may withdraw at any time). We will only send marketing emails if you have opted in or are an existing customer and the communication relates to similar services (soft opt-in).</em></li>
              </ul>
            </>
          ),
        },
        {
          heading: "5. Data Sharing and Disclosure",
          content: (
            <>
              <p>We do not sell, rent, or trade your personal data. We share data only in the following circumstances:</p>
              <ul>
                <li><strong>Service providers:</strong> We share data with carefully vetted third-party processors who provide services on our behalf (e.g., Paystack for payments, our hosting infrastructure provider, email delivery services). These processors are contractually bound to process data only on our instructions and to maintain appropriate security.</li>
                <li><strong>Legal obligations:</strong> We may disclose your data to law enforcement, regulatory bodies, or courts where required to do so by applicable Nigerian law or a valid legal order.</li>
                <li><strong>Business transfers:</strong> If we undergo a merger, acquisition, or sale of assets, your data may be transferred as part of that transaction. We will notify you by email and/or prominent website notice before your data is transferred and becomes subject to a different privacy policy.</li>
                <li><strong>With your consent:</strong> In any other circumstances, we will ask for your explicit consent before sharing your data.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "6. International Data Transfers",
          content: (
            <p>Some of our service providers (e.g., cloud infrastructure) may be located outside Nigeria. Where we transfer personal data internationally, we take steps to ensure that appropriate safeguards are in place, such as data processing agreements incorporating standard contractual clauses or equivalent mechanisms, to ensure your data receives an adequate level of protection.</p>
          ),
        },
        {
          heading: "7. Data Retention",
          content: (
            <>
              <p>We retain your personal data for no longer than is necessary for the purposes for which it was collected:</p>
              <ul>
                <li><strong>Account data:</strong> For the duration of your account and for 2 years after account closure, unless a longer period is required by law.</li>
                <li><strong>Order and transaction records:</strong> 7 years from the date of the transaction (in compliance with Nigerian tax and financial record-keeping obligations).</li>
                <li><strong>Support communications:</strong> 3 years from the date of the last communication in the thread.</li>
                <li><strong>Marketing consents:</strong> Until you withdraw your consent or for 3 years from last interaction, whichever is earlier.</li>
                <li><strong>Website analytics data:</strong> 26 months in aggregated form.</li>
              </ul>
              <p>When retention periods expire, we securely delete or anonymise the data.</p>
            </>
          ),
        },
        {
          heading: "8. Your Rights",
          content: (
            <>
              <p>Under the NDPA 2023 and applicable international standards, you have the following rights:</p>
              <ul>
                <li><strong>Right of access:</strong> Request a copy of the personal data we hold about you.</li>
                <li><strong>Right of rectification:</strong> Ask us to correct inaccurate or incomplete data.</li>
                <li><strong>Right of erasure:</strong> Request deletion of your personal data where it is no longer necessary for the purposes for which it was collected, subject to our legal obligations to retain certain records.</li>
                <li><strong>Right to restrict processing:</strong> Ask us to suspend processing of your data in certain circumstances (e.g., while accuracy is contested).</li>
                <li><strong>Right to data portability:</strong> Receive your data in a structured, machine-readable format and transmit it to another controller.</li>
                <li><strong>Right to object:</strong> Object to processing based on our legitimate interests, including direct marketing.</li>
                <li><strong>Right to withdraw consent:</strong> Withdraw any consent you have given at any time, without affecting the lawfulness of processing before withdrawal.</li>
              </ul>
              <p>To exercise any of these rights, send a written request to <a href="mailto:info@nazyempire.com">info@nazyempire.com</a>. We will respond within <strong>30 days</strong>. We may require you to verify your identity before processing your request. There is no charge for reasonable requests.</p>
              <p>If you are dissatisfied with our response, you have the right to lodge a complaint with the <strong>Nigeria Data Protection Commission (NDPC)</strong> at <a href="https://ndpc.gov.ng" target="_blank" rel="noopener noreferrer">ndpc.gov.ng</a>. EU/EEA residents may also contact their local supervisory authority.</p>
            </>
          ),
        },
        {
          heading: "9. Security",
          content: (
            <>
              <p>We implement appropriate technical and organisational measures to protect your personal data against unauthorised access, alteration, disclosure, or destruction. These measures include:</p>
              <ul>
                <li>TLS/HTTPS encryption for all data in transit.</li>
                <li>Bcrypt hashing of passwords; we cannot recover your plain-text password.</li>
                <li>Access controls limiting staff access to personal data on a need-to-know basis.</li>
                <li>Regular security reviews and updates.</li>
              </ul>
              <p>No method of transmission over the internet or electronic storage is 100% secure. While we strive to protect your personal data, we cannot guarantee absolute security. In the event of a data breach that is likely to result in a risk to your rights and freedoms, we will notify you and the NDPC as required by applicable law.</p>
            </>
          ),
        },
        {
          heading: "10. Cookies",
          content: (
            <p>We use cookies and similar tracking technologies on our website. For detailed information about the cookies we use, why we use them, and how to control them, please read our <Link href="/cookie-policy">Cookie Policy</Link>.</p>
          ),
        },
        {
          heading: "11. Children's Privacy",
          content: (
            <p>Our services are not directed to persons under the age of 18. We do not knowingly collect personal data from children. If we become aware that we have inadvertently collected personal data from a child, we will delete it promptly. If you believe we hold data about a child, please contact us immediately at <a href="mailto:info@nazyempire.com">info@nazyempire.com</a>.</p>
          ),
        },
        {
          heading: "12. Third-Party Links",
          content: (
            <p>Our website may contain links to third-party websites or services. This Privacy Policy does not apply to those external sites. We are not responsible for the privacy practices of third parties and encourage you to review their privacy policies before providing any personal data.</p>
          ),
        },
        {
          heading: "13. Changes to this Policy",
          content: (
            <p>We may update this Privacy Policy from time to time. Material changes will be communicated by email (to registered users) and/or by a notice on the website. We will update the "Last reviewed" date at the top of this page. Your continued use of the website after the effective date of any changes constitutes acceptance of the revised Policy.</p>
          ),
        },
        {
          heading: "14. Contact",
          content: (
            <>
              <p>For any questions, concerns, or requests relating to this Privacy Policy or our data practices:</p>
              <p><strong>NAZY EMPIRE DIGITAL</strong><br />
              CAC BN 9657494<br />
              Enugu, Nigeria<br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
            </>
          ),
        },
      ]}
    />
  );
}
