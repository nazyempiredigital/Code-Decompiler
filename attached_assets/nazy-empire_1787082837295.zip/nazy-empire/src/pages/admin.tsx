import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import {
  Globe, LogOut, BarChart2, FolderOpen, Users, DollarSign,
  Settings, Search, Upload, MessageSquare, Send, Music,
  LifeBuoy, CheckCircle, XCircle, Clock, AlertCircle, ChevronDown,
  ShieldOff, Shield, Trash2, UserX, UserCheck, Image, Plus, Pencil, Eye, EyeOff,
  ChevronRight, BookOpen, Tag, Calendar, ShoppingBag, Share2,
} from "lucide-react";
import { AdminReleaseDetail } from "@/components/admin-release-detail";
import { AdminArtistOrders } from "@/components/admin-artist-orders";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/auth";
import { AuthModal } from "@/components/auth-modal";
import { NotificationBell } from "@/components/notification-bell";
import { BrandLockup } from "@/components/mic-logo";
import {
  api, type Project, type AdminStats, type User, type Message,
  type RawSetting, type ArtistApplication, type Release,
  type SupportTicket, type TicketMessage, type PortfolioProject,
  type AnalyticsUpload, type AnalyticsUploadResult,
  type EarningsUpload, type EarningsUploadResult, type ArtistPaymentRequest,
  type BlogPost, type AffiliateApplication, type AffiliateWithdrawal, type AffiliateCommission,
} from "@/lib/api";

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending_review:             { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  awaiting_payment:           { label: "Awaiting Payment",  color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  in_progress:                { label: "In Progress",       color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  waiting_for_client_feedback:{ label: "Awaiting Feedback", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  completed:                  { label: "Completed",         color: "bg-green-500/10 text-green-400 border-green-500/20" },
  delivered:                  { label: "Delivered",         color: "bg-primary/10 text-primary border-primary/20" },
};

const RELEASE_STATUS: Record<string, { label: string; color: string }> = {
  draft:             { label: "Draft",             color: "bg-white/10 text-white/50 border-white/10" },
  pending_review:    { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  changes_requested: { label: "Changes Requested", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  approved:          { label: "Approved",          color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  rejected:          { label: "Rejected",          color: "bg-red-500/10 text-red-400 border-red-500/20" },
  live:              { label: "Live",              color: "bg-green-500/10 text-green-400 border-green-500/20" },
};

const TICKET_STATUS: Record<string, { label: string; color: string }> = {
  open:        { label: "Open",        color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  in_progress: { label: "In Progress", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  resolved:    { label: "Resolved",    color: "bg-green-500/10 text-green-400 border-green-500/20" },
  closed:      { label: "Closed",      color: "bg-white/10 text-white/40 border-white/10" },
};

type AdminTab = "dashboard" | "projects" | "portfolio" | "artist_apps" | "releases" | "artist_orders" | "artists" | "analytics" | "earnings" | "payment_requests" | "support" | "users" | "blog" | "settings" | "affiliates";

const PAYMENT_REQUEST_STATUS: Record<string, { label: string; color: string }> = {
  pending: { label: "Pending", color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  paid:    { label: "Paid",    color: "bg-green-500/10 text-green-400 border-green-500/20" },
};

const ARTIST_APP_STATUS: Record<string, { label: string; color: string }> = {
  pending:  { label: "Pending",  color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  approved: { label: "Approved", color: "bg-green-500/10 text-green-400 border-green-500/20" },
  rejected: { label: "Rejected", color: "bg-red-500/10 text-red-400 border-red-500/20" },
};

export default function Admin() {
  const { user, logout, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [authModal, setAuthModal] = useState<"login" | "register" | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [stats, setStats] = useState<AdminStats | null>(null);

  const [projects, setProjects] = useState<Project[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [adminMessage, setAdminMessage] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [artistApps, setArtistApps] = useState<ArtistApplication[]>([]);
  const [reviewNotes, setReviewNotes] = useState<Record<number, string>>({});

  const [releases, setReleases] = useState<Release[]>([]);
  const [releaseNotes, setReleaseNotes] = useState<Record<number, string>>({});
  const [selectedRelease, setSelectedRelease] = useState<Release | null>(null);
  const [releaseFilter, setReleaseFilter] = useState("all");
  const [appFilter, setAppFilter] = useState("all");
  const [artistFilter, setArtistFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [releaseDetailLoading, setReleaseDetailLoading] = useState(false);

  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketMessages, setTicketMessages] = useState<TicketMessage[]>([]);
  const [ticketReply, setTicketReply] = useState("");

  const [users, setUsers] = useState<User[]>([]);
  const [artists, setArtists] = useState<User[]>([]);
  const [blockReason, setBlockReason] = useState<Record<number, string>>({});
  const [settings, setSettings] = useState<RawSetting[]>([]);
  const [settingsEdits, setSettingsEdits] = useState<Record<string, string>>({});

  const [portfolioProjects, setPortfolioProjects] = useState<PortfolioProject[]>([]);
  const [portfolioForm, setPortfolioForm] = useState<Partial<PortfolioProject> | null>(null);
  const [portfolioSaving, setPortfolioSaving] = useState(false);
  const [portfolioImageUploading, setPortfolioImageUploading] = useState(false);
  const [portfolioError, setPortfolioError] = useState<string | null>(null);
  const portfolioImageRef = useRef<HTMLInputElement>(null);

  const [analyticsUploads, setAnalyticsUploads] = useState<AnalyticsUpload[]>([]);
  const [analyticsUploading, setAnalyticsUploading] = useState(false);
  const [analyticsResult, setAnalyticsResult] = useState<AnalyticsUploadResult | null>(null);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);
  const analyticsFileRef = useRef<HTMLInputElement>(null);

  const [earningsUploads, setEarningsUploads] = useState<EarningsUpload[]>([]);
  const [earningsUploading, setEarningsUploading] = useState(false);
  const [earningsResult, setEarningsResult] = useState<EarningsUploadResult | null>(null);
  const [earningsError, setEarningsError] = useState<string | null>(null);
  const earningsFileRef = useRef<HTMLInputElement>(null);

  const [paymentRequests, setPaymentRequests] = useState<ArtistPaymentRequest[]>([]);
  const [paymentRequestsLoading, setPaymentRequestsLoading] = useState(false);
  const [processingRequest, setProcessingRequest] = useState<ArtistPaymentRequest | null>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  // Affiliate state
  const [affApps, setAffApps] = useState<AffiliateApplication[]>([]);
  const [affWithdrawals, setAffWithdrawals] = useState<AffiliateWithdrawal[]>([]);
  const [affCommissions, setAffCommissions] = useState<AffiliateCommission[]>([]);
  const [affSubTab, setAffSubTab] = useState<"applications" | "withdrawals" | "commissions">("applications");
  const [affAppNotes, setAffAppNotes] = useState<Record<number, string>>({});
  const [affWdNotes, setAffWdNotes] = useState<Record<number, string>>({});
  const [affLoading, setAffLoading] = useState(false);

  // Blog state
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [blogForm, setBlogForm] = useState<Partial<BlogPost> | null>(null);
  const [blogEditingId, setBlogEditingId] = useState<number | null>(null);
  const [blogSaving, setBlogSaving] = useState(false);
  const [blogError, setBlogError] = useState<string | null>(null);
  const [blogPreviewMode, setBlogPreviewMode] = useState(false);

  useEffect(() => {
    if (user?.role === "admin" || user?.role === "moderator") {
      loadStats();
      loadProjects();
    }
  }, [user]);

  async function loadStats() { try { setStats(await api.admin.stats()); } catch {} }
  async function loadProjects() { try { setProjects(await api.admin.projects()); } catch {} }
  async function loadArtistApps() { try { setArtistApps(await api.artistApplications.list()); } catch {} }
  async function loadReleases() { try { setReleases(await api.releases.list()); } catch {} }

  async function openRelease(r: Release) {
    setReleaseDetailLoading(true);
    try {
      const full = await api.releases.get(r.id);
      setSelectedRelease(full);
    } catch {
      setSelectedRelease(r);
    }
    setReleaseDetailLoading(false);
  }
  async function loadTickets() { try { setTickets(await api.support.allTickets()); } catch {} }
  async function loadUsers() {
    try {
      const all = await api.admin.users();
      setUsers(all);
      setArtists(all.filter((u) => u.role === "verified_artist"));
    } catch {}
  }
  async function loadSettings() { try { setSettings(await api.settings.getAll()); } catch {} }
  async function loadPortfolio() { try { setPortfolioProjects(await api.portfolio.listAll()); } catch {} }
  async function loadAnalyticsUploads() { try { setAnalyticsUploads(await api.analytics.uploads()); } catch {} }
  async function loadEarningsUploads() { try { setEarningsUploads(await api.earnings.uploads()); } catch {} }

  async function uploadAnalyticsCsv(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAnalyticsUploading(true);
    setAnalyticsError(null);
    setAnalyticsResult(null);
    try {
      const result = await api.analytics.upload(file);
      setAnalyticsResult(result);
      await loadAnalyticsUploads();
    } catch {
      setAnalyticsError("Failed to process this CSV. Check that it has isrc, outlet and streams columns.");
    }
    setAnalyticsUploading(false);
    if (analyticsFileRef.current) analyticsFileRef.current.value = "";
  }

  async function uploadEarningsCsv(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setEarningsUploading(true);
    setEarningsError(null);
    setEarningsResult(null);
    try {
      const result = await api.earnings.upload(file);
      setEarningsResult(result);
      await loadEarningsUploads();
    } catch {
      setEarningsError("Failed to process this CSV. Check that it has ISRC and Earnings columns.");
    }
    setEarningsUploading(false);
    if (earningsFileRef.current) earningsFileRef.current.value = "";
  }

  async function selectProject(p: Project) {
    setSelectedProject(p);
    const msgs = await api.projects.messages(p.id).catch(() => []);
    setMessages(msgs);
  }

  async function sendAdminMessage() {
    if (!selectedProject || !adminMessage.trim()) return;
    try {
      const msg = await api.projects.sendMessage(selectedProject.id, adminMessage.trim());
      setMessages((m) => [...m, msg]);
      setAdminMessage("");
    } catch {}
  }

  async function updateProjectStatus(id: number, status: string) {
    await api.admin.updateProject(id, { status });
    setProjects((ps) => ps.map((p) => p.id === id ? { ...p, status } : p));
    if (selectedProject?.id === id) setSelectedProject((p) => p ? { ...p, status } : p);
  }

  async function uploadCompletedFile(e: React.ChangeEvent<HTMLInputElement>) {
    if (!selectedProject || !e.target.files?.[0]) return;
    setUploadingFile(true);
    try {
      const result = await api.admin.uploadCompletedFile(selectedProject.id, e.target.files[0]);
      setSelectedProject((p) => p ? { ...p, completedFiles: [...(p.completedFiles ?? []), result.url] } : p);
    } catch {}
    setUploadingFile(false);
  }

  async function reviewArtistApp(id: number, status: "approved" | "rejected") {
    try {
      await api.artistApplications.review(id, status, reviewNotes[id]);
      setArtistApps((apps) => apps.map((a) => a.id === id ? { ...a, status } : a));
    } catch {}
  }

  async function reviewRelease(id: number, status: string) {
    try {
      await api.releases.update(id, { status: status as Release["status"], adminNotes: releaseNotes[id] });
      setReleases((rs) => rs.map((r) => r.id === id ? { ...r, status: status as Release["status"], adminNotes: releaseNotes[id] } : r));
    } catch {}
  }

  async function selectTicket(t: SupportTicket) {
    setSelectedTicket(t);
    const msgs = await api.support.messages(t.id).catch(() => []);
    setTicketMessages(msgs);
  }

  async function sendTicketReply() {
    if (!selectedTicket || !ticketReply.trim()) return;
    try {
      const msg = await api.support.sendMessage(selectedTicket.id, ticketReply.trim());
      setTicketMessages((m) => [...m, msg]);
      setTicketReply("");
    } catch {}
  }

  async function updateUserRole(id: number, role: string) {
    try {
      const updated = await api.admin.updateUserRole(id, role);
      setUsers((us) => us.map((u) => u.id === id ? { ...u, role: updated.role } : u));
    } catch {}
  }

  async function blockArtist(id: number) {
    try {
      const updated = await api.admin.blockUser(id, blockReason[id]);
      setArtists((as) => as.map((a) => a.id === id ? { ...a, ...updated } : a));
      setBlockReason((b) => { const n = { ...b }; delete n[id]; return n; });
    } catch {}
  }

  async function unblockArtist(id: number) {
    try {
      const updated = await api.admin.unblockUser(id);
      setArtists((as) => as.map((a) => a.id === id ? { ...a, ...updated } : a));
    } catch {}
  }

  async function deleteArtist(id: number) {
    if (!confirm("Permanently delete this artist account? All their data will be lost.")) return;
    try {
      await api.admin.deleteUser(id);
      setArtists((as) => as.filter((a) => a.id !== id));
    } catch {}
  }

  async function saveSettings() {
    try {
      await api.settings.bulk(settingsEdits);
      setSettingsEdits({});
      await loadSettings();
    } catch {}
  }

  useEffect(() => {
    setSelectedRelease(null);
    setReleaseFilter("all");
    setAppFilter("all");
    setArtistFilter("all");
    setPaymentFilter("all");
    if (tab === "artist_apps") loadArtistApps();
    if (tab === "releases") loadReleases();
    if (tab === "artists") loadUsers();
    if (tab === "support") loadTickets();
    if (tab === "users") loadUsers();
    if (tab === "settings") loadSettings();
    if (tab === "portfolio") loadPortfolio();
    if (tab === "analytics") loadAnalyticsUploads();
    if (tab === "earnings") loadEarningsUploads();
    if (tab === "payment_requests") loadPaymentRequests();
    if (tab === "blog") loadBlogPosts();
    if (tab === "affiliates") loadAffiliates();
  }, [tab]);

  async function loadBlogPosts() {
    try { setBlogPosts(await api.blog.adminAll()); } catch {}
  }

  async function loadAffiliates() {
    setAffLoading(true);
    try {
      const [apps, wds, comms] = await Promise.all([
        api.affiliates.adminApplications(),
        api.affiliates.adminWithdrawals(),
        api.affiliates.adminCommissions(),
      ]);
      setAffApps(apps);
      setAffWithdrawals(wds);
      setAffCommissions(comms);
    } catch {}
    setAffLoading(false);
  }

  async function reviewAffApp(id: number, status: "approved" | "rejected") {
    try {
      const updated = await api.affiliates.adminReviewApplication(id, status, affAppNotes[id]);
      setAffApps((prev) => prev.map((a) => a.id === id ? { ...a, ...updated } : a));
    } catch {}
  }

  async function updateAffWithdrawal(id: number, status: "approved" | "paid" | "rejected") {
    try {
      const updated = await api.affiliates.adminUpdateWithdrawal(id, status, affWdNotes[id]);
      setAffWithdrawals((prev) => prev.map((w) => w.id === id ? { ...w, ...updated } : w));
    } catch {}
  }

  function blogSlugify(title: string) {
    return title.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").trim();
  }

  async function saveBlogPost() {
    if (!blogForm?.title?.trim() || !blogForm?.slug?.trim() || !blogForm?.content?.trim()) {
      setBlogError("Title, slug, and content are required.");
      return;
    }
    setBlogSaving(true);
    setBlogError(null);
    try {
      if (blogEditingId) {
        const updated = await api.blog.update(blogEditingId, blogForm);
        setBlogPosts((ps) => ps.map((p) => p.id === blogEditingId ? updated : p));
      } else {
        const created = await api.blog.create(blogForm);
        setBlogPosts((ps) => [created, ...ps]);
      }
      setBlogForm(null);
      setBlogEditingId(null);
      setBlogPreviewMode(false);
    } catch (err) {
      setBlogError(err instanceof Error ? err.message : "Failed to save post");
    }
    setBlogSaving(false);
  }

  async function deleteBlogPost(id: number) {
    if (!confirm("Permanently delete this blog post?")) return;
    try {
      await api.blog.delete(id);
      setBlogPosts((ps) => ps.filter((p) => p.id !== id));
    } catch {}
  }

  async function loadPaymentRequests() {
    setPaymentRequestsLoading(true);
    try { setPaymentRequests(await api.paymentRequests.adminList()); } catch {}
    setPaymentRequestsLoading(false);
  }

  async function submitMarkPaid() {
    if (!processingRequest) return;
    setPaymentError(null);
    try {
      const updated = await api.paymentRequests.markPaid(processingRequest.id);
      setPaymentRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
      setProcessingRequest(null);
    } catch (err) {
      setPaymentError(err instanceof Error ? err.message : "Failed to mark as paid");
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-sm w-full text-center">
            <Globe className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="font-display text-4xl text-white mb-2">ADMIN</h1>
            <p className="text-white/50 mb-6">Admin access required.</p>
            <Button onClick={() => setAuthModal("login")} className="bg-primary text-black hover:bg-primary/90 font-bold w-full">Login</Button>
          </div>
        </div>
        {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSwitch={(m) => setAuthModal(m)} />}
      </>
    );
  }

  if (user.role !== "admin" && user.role !== "moderator") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="text-center">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h1 className="font-display text-4xl text-white mb-2">ACCESS DENIED</h1>
          <p className="text-white/50 mb-6">You don't have permission to access this area.</p>
          <Link href="/dashboard"><Button className="bg-primary text-black hover:bg-primary/90 font-bold">Go to Dashboard</Button></Link>
        </div>
      </div>
    );
  }

  const navTabs: { id: AdminTab; label: string; icon: React.ElementType; adminOnly?: boolean }[] = [
    { id: "dashboard",   label: "Dashboard",          icon: BarChart2 },
    { id: "projects",    label: "Projects",            icon: FolderOpen },
    { id: "portfolio",   label: "Portfolio",           icon: Image, adminOnly: true },
    { id: "artist_apps", label: "Artist Applications", icon: Music },
    { id: "releases",      label: "Releases",            icon: Music },
    { id: "artist_orders", label: "Artist Orders",       icon: ShoppingBag },
    { id: "artists",       label: "Artists",             icon: UserCheck },
    { id: "analytics",   label: "Analytics",           icon: BarChart2, adminOnly: true },
    { id: "earnings",    label: "Earnings Upload",     icon: DollarSign, adminOnly: true },
    { id: "payment_requests", label: "Payment Requests", icon: Send, adminOnly: true },
    { id: "support",     label: "Support Tickets",     icon: LifeBuoy },
    { id: "users",       label: "All Users",           icon: Users, adminOnly: true },
    { id: "blog",        label: "Blog",                icon: BookOpen, adminOnly: true },
    { id: "affiliates",  label: "Affiliates",          icon: Share2, adminOnly: true },
    { id: "settings",    label: "Settings",            icon: Settings, adminOnly: true },
  ];

  const fmt = (n: string | number) =>
    "₦" + parseFloat(String(n)).toLocaleString("en-NG", { minimumFractionDigits: 2 });

  return (
    <div className="min-h-screen bg-black flex">
      <aside className="hidden lg:flex flex-col w-56 bg-zinc-950 border-r border-white/10 py-6 shrink-0">
        <Link href="/" className="flex items-center gap-2 px-5 mb-8">
          <BrandLockup iconSize="w-5 h-6" textSize="text-lg" />
        </Link>
        <nav className="flex-1 space-y-1 px-3">
          {navTabs.filter((t) => !t.adminOnly || user.role === "admin").map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                tab === id ? "bg-primary text-black font-semibold" : "text-white/50 hover:text-white hover:bg-white/5"
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" /> {label}
            </button>
          ))}
        </nav>
        <div className="px-3 mt-4 space-y-1">
          <Link href="/dashboard">
            <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/50 hover:text-white hover:bg-white/5 transition-colors">
              <Users className="w-4 h-4" /> Client View
            </button>
          </Link>
          <div className="px-3 py-2">
            <ProfileDropdown
              open={profileOpen}
              onClose={() => setProfileOpen(false)}
              onToggle={() => setProfileOpen((v) => !v)}
            />
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <div className="bg-black/90 backdrop-blur-md border-b border-white/10 px-4 py-4 flex items-center justify-between lg:hidden">
          <Link href="/" className="flex items-center gap-2">
            <BrandLockup iconSize="w-6 h-7" textSize="text-xl" />
          </Link>
          <div className="flex items-center gap-3">
            <NotificationBell />
            <ProfileDropdown
              open={profileOpen}
              onClose={() => setProfileOpen(false)}
              onToggle={() => setProfileOpen((v) => !v)}
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-1 px-4 py-3 border-b border-white/10 lg:hidden">
          {navTabs.filter((t) => !t.adminOnly || user.role === "admin").map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-colors ${tab === id ? "bg-primary text-black font-semibold" : "text-white/50 hover:text-white"}`}
            >
              <Icon className="w-3 h-3" /> {label}
            </button>
          ))}
        </div>

        <main className="flex-1 overflow-auto p-4 lg:p-8">

          {/* Dashboard */}
          {tab === "dashboard" && stats && (
            <div>
              <h1 className="font-display text-4xl text-white mb-8">DASHBOARD</h1>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
                {[
                  { label: "Total Projects", value: stats.totalProjects, icon: FolderOpen },
                  { label: "Active Projects", value: stats.activeProjects, icon: BarChart2 },
                  { label: "Revenue (NGN)", value: stats.totalRevenue ? fmt(stats.totalRevenue) : "₦0", icon: DollarSign },
                  { label: "Clients", value: stats.totalClients, icon: Users },
                  { label: "Artists", value: stats.totalArtists, icon: Music },
                ].map(({ label, value, icon: Icon }) => (
                  <div key={label} className="bg-card border border-border rounded-xl p-4">
                    <Icon className="w-5 h-5 text-primary mb-2" />
                    <div className="font-display text-3xl text-white">{value}</div>
                    <div className="text-white/40 text-xs mt-1">{label}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                {[
                  { label: "Pending Artist Applications", value: stats.pendingArtistApplications, color: "text-yellow-400", tab: "artist_apps" as AdminTab },
                  { label: "Pending Music Releases",      value: stats.pendingReleases,            color: "text-blue-400",   tab: "releases" as AdminTab },
                  { label: "Open Support Tickets",        value: stats.openSupportTickets,         color: "text-orange-400", tab: "support" as AdminTab },
                ].map(({ label, value, color, tab: t }) => (
                  <button key={label} onClick={() => setTab(t)} className="bg-card border border-border rounded-xl p-4 text-left hover:border-primary/30 transition-colors">
                    <div className={`font-display text-4xl ${color}`}>{value}</div>
                    <div className="text-white/50 text-sm mt-1">{label}</div>
                  </button>
                ))}
              </div>
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-5 py-4 border-b border-border">
                  <h2 className="text-white font-semibold">Recent Orders</h2>
                </div>
                <div className="divide-y divide-border">
                  {stats.recentOrders.map((p) => {
                    const s = STATUS_LABELS[p.status] ?? { label: p.status, color: "bg-white/10 text-white/50 border-white/10" };
                    return (
                      <div key={p.id} className="flex items-center justify-between px-5 py-3">
                        <div>
                          <div className="text-white text-sm font-medium">{p.websiteType}</div>
                          <div className="text-white/40 text-xs">{p.projectId} · {p.clientName}</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-primary font-bold text-sm">{fmt(p.totalAmount)}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full border ${s.color}`}>{s.label}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Projects */}
          {tab === "projects" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">PROJECTS</h1>
              <div className="flex gap-3 mb-6 flex-wrap">
                <div className="relative flex-1 min-w-48">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search..." className="pl-9" />
                </div>
                <select
                  className="bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">All Status</option>
                  {Object.entries(STATUS_LABELS).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-2 space-y-3 max-h-[70vh] overflow-y-auto pr-1">
                  {projects
                    .filter((p) => {
                      if (statusFilter !== "all" && p.status !== statusFilter) return false;
                      if (search) {
                        const s = search.toLowerCase();
                        return p.projectId.toLowerCase().includes(s) || p.clientName.toLowerCase().includes(s) || p.websiteType.toLowerCase().includes(s);
                      }
                      return true;
                    })
                    .map((p) => {
                      const s = STATUS_LABELS[p.status] ?? { label: p.status, color: "bg-white/10 text-white/50 border-white/10" };
                      return (
                        <div
                          key={p.id}
                          onClick={() => selectProject(p)}
                          className={`p-4 rounded-xl border cursor-pointer transition-all ${selectedProject?.id === p.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-white/20"}`}
                        >
                          <div className="flex items-start justify-between mb-1">
                            <div>
                              <div className="text-white font-medium text-sm">{p.websiteType}</div>
                              <div className="text-white/40 text-xs">{p.projectId} · {p.clientName}</div>
                            </div>
                            <span className={`text-xs px-2 py-0.5 rounded-full border ${s.color}`}>{s.label}</span>
                          </div>
                          <div className="text-primary font-bold text-sm">{fmt(p.totalAmount)}</div>
                        </div>
                      );
                    })}
                </div>
                <div className="lg:col-span-3">
                  {!selectedProject ? (
                    <div className="flex items-center justify-center h-64 text-white/20 text-center">
                      <div><FolderOpen className="w-12 h-12 mx-auto mb-3" /><p>Select a project</p></div>
                    </div>
                  ) : (
                    <div className="bg-card border border-border rounded-xl overflow-hidden">
                      <div className="p-5 border-b border-border">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-white font-bold text-lg">{selectedProject.websiteType}</h3>
                            <div className="text-white/40 text-sm">{selectedProject.projectId} · {selectedProject.clientEmail}</div>
                          </div>
                          <div className="text-primary font-bold text-xl">{fmt(selectedProject.totalAmount)}</div>
                        </div>
                        <div className="flex flex-wrap gap-2 items-center">
                          <select
                            className="bg-input border border-border rounded-lg px-3 py-1.5 text-white text-sm focus:outline-none"
                            value={selectedProject.status}
                            onChange={(e) => updateProjectStatus(selectedProject.id, e.target.value)}
                          >
                            {Object.entries(STATUS_LABELS).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
                          </select>
                          <Button
                            size="sm" variant="outline" className="border-white/20 text-white/70 text-xs"
                            disabled={uploadingFile}
                            onClick={() => fileInputRef.current?.click()}
                          >
                            <Upload className="w-3 h-3 mr-1" /> {uploadingFile ? "Uploading..." : "Upload File"}
                          </Button>
                          <input ref={fileInputRef} type="file" className="hidden" onChange={uploadCompletedFile} />
                        </div>
                      </div>
                      <div className="p-4 max-h-48 overflow-y-auto flex flex-col gap-3">
                        {messages.length === 0 && <p className="text-white/30 text-sm text-center py-4">No messages</p>}
                        {messages.map((msg) => (
                          <div key={msg.id} className={`flex ${msg.isAdmin ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${msg.isAdmin ? "bg-primary text-black font-medium" : "bg-card border border-border text-white/80"}`}>
                              {!msg.isAdmin && <div className="text-xs text-white/40 mb-1">Client</div>}
                              {msg.content}
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="p-4 flex gap-3 border-t border-border">
                        <Textarea placeholder="Reply to client..." rows={2} value={adminMessage} onChange={(e) => setAdminMessage(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendAdminMessage(); } }} className="resize-none" />
                        <Button onClick={sendAdminMessage} className="bg-primary text-black hover:bg-primary/90 shrink-0"><Send className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Portfolio Projects */}
          {tab === "portfolio" && user.role === "admin" && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h1 className="font-display text-4xl text-white">PORTFOLIO</h1>
                <button
                  onClick={() => setPortfolioForm(portfolioForm ? null : {
                    title: "", description: "", imageUrl: "", category: "Web Development",
                    link: "", sortOrder: portfolioProjects.length + 1, isVisible: true,
                  })}
                  className="flex items-center gap-2 px-4 py-2 bg-primary text-black rounded-lg font-semibold text-sm hover:bg-primary/90 transition-colors"
                >
                  <Plus className="w-4 h-4" /> {portfolioForm && !portfolioForm.id ? "Cancel" : "Add Project"}
                </button>
              </div>

              {/* Error banner */}
              {portfolioError && (
                <div className="mb-4 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm flex items-center justify-between">
                  <span>{portfolioError}</span>
                  <button onClick={() => setPortfolioError(null)} className="text-red-400/60 hover:text-red-400 ml-4 text-lg leading-none">×</button>
                </div>
              )}

              {/* Create / Edit Form */}
              {portfolioForm !== null && (
                <div className="bg-card border border-border rounded-xl p-6 mb-6">
                  <h2 className="text-white font-bold text-lg mb-4">
                    {portfolioForm.id ? "Edit Project" : "New Portfolio Project"}
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Title *</label>
                      <input
                        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Project title"
                        value={portfolioForm.title ?? ""}
                        onChange={(e) => setPortfolioForm((f) => ({ ...f!, title: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Category</label>
                      <select
                        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                        value={portfolioForm.category ?? "Web Development"}
                        onChange={(e) => setPortfolioForm((f) => ({ ...f!, category: e.target.value }))}
                      >
                        {["Web Development","Business Website & App","E-commerce Store & App","Restaurant Website & App","E-learning Website & App","Music Distribution","Domain Registration","Web Hosting","Custom Web Application"].map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                    <div className="md:col-span-2 space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Description *</label>
                      <textarea
                        rows={3}
                        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Short description of the project..."
                        value={portfolioForm.description ?? ""}
                        onChange={(e) => setPortfolioForm((f) => ({ ...f!, description: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Image URL *</label>
                      <div className="flex gap-2">
                        <input
                          className="flex-1 bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="https://..."
                          value={portfolioForm.imageUrl ?? ""}
                          onChange={(e) => setPortfolioForm((f) => ({ ...f!, imageUrl: e.target.value }))}
                        />
                        <button
                          disabled={portfolioImageUploading}
                          onClick={() => portfolioImageRef.current?.click()}
                          className="px-3 py-2 bg-white/5 border border-border rounded-lg text-white/60 text-xs hover:bg-white/10 transition-colors disabled:opacity-50 whitespace-nowrap"
                        >
                          {portfolioImageUploading ? "Uploading…" : "Upload"}
                        </button>
                        <input
                          ref={portfolioImageRef}
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setPortfolioImageUploading(true);
                            try {
                              const result = await api.portfolio.uploadImage(file);
                              setPortfolioForm((f) => ({ ...f!, imageUrl: result.url }));
                            } catch {}
                            setPortfolioImageUploading(false);
                            e.target.value = "";
                          }}
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Project Link (optional)</label>
                      <input
                        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="https://..."
                        value={portfolioForm.link ?? ""}
                        onChange={(e) => setPortfolioForm((f) => ({ ...f!, link: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Sort Order</label>
                      <input
                        type="number"
                        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                        value={portfolioForm.sortOrder ?? 0}
                        onChange={(e) => setPortfolioForm((f) => ({ ...f!, sortOrder: parseInt(e.target.value) || 0 }))}
                      />
                    </div>
                    <div className="flex items-center gap-3">
                      <label className="text-white/50 text-xs uppercase tracking-wider">Visible on Homepage</label>
                      <button
                        onClick={() => setPortfolioForm((f) => ({ ...f!, isVisible: !f!.isVisible }))}
                        className={`relative w-10 h-6 rounded-full transition-colors ${portfolioForm.isVisible ? "bg-primary" : "bg-white/10"}`}
                      >
                        <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${portfolioForm.isVisible ? "left-5" : "left-1"}`} />
                      </button>
                    </div>
                  </div>

                  {/* Preview image */}
                  {portfolioForm.imageUrl && (
                    <div className="mt-4">
                      <img
                        src={portfolioForm.imageUrl}
                        alt="Preview"
                        className="h-32 w-full object-cover rounded-lg border border-border"
                        onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                      />
                    </div>
                  )}

                  <div className="flex gap-3 mt-5">
                    <button
                      disabled={portfolioSaving}
                      onClick={async () => {
                        if (!portfolioForm.title?.trim() || !portfolioForm.description?.trim() || !portfolioForm.imageUrl?.trim()) {
                          setPortfolioError("Title, description, and image URL are required.");
                          return;
                        }
                        setPortfolioSaving(true);
                        setPortfolioError(null);
                        try {
                          if (portfolioForm.id) {
                            const updated = await api.portfolio.update(portfolioForm.id, {
                              title: portfolioForm.title,
                              description: portfolioForm.description,
                              imageUrl: portfolioForm.imageUrl,
                              category: portfolioForm.category,
                              link: portfolioForm.link || undefined,
                              sortOrder: portfolioForm.sortOrder,
                              isVisible: portfolioForm.isVisible,
                            });
                            setPortfolioProjects((ps) => ps.map((p) => p.id === updated.id ? updated : p));
                          } else {
                            const created = await api.portfolio.create({
                              title: portfolioForm.title!,
                              description: portfolioForm.description!,
                              imageUrl: portfolioForm.imageUrl!,
                              category: portfolioForm.category ?? "Web Development",
                              link: portfolioForm.link || undefined,
                              sortOrder: portfolioForm.sortOrder ?? 0,
                              isVisible: portfolioForm.isVisible ?? true,
                            });
                            setPortfolioProjects((ps) => [...ps, created]);
                          }
                          setPortfolioForm(null);
                        } catch (err) {
                          setPortfolioError(err instanceof Error ? err.message : "Failed to save. Please try again.");
                        }
                        setPortfolioSaving(false);
                      }}
                      className="px-5 py-2 bg-primary text-black rounded-lg font-semibold text-sm hover:bg-primary/90 transition-colors disabled:opacity-50"
                    >
                      {portfolioSaving ? "Saving…" : portfolioForm.id ? "Save Changes" : "Create Project"}
                    </button>
                    <button
                      onClick={() => setPortfolioForm(null)}
                      className="px-5 py-2 bg-white/5 border border-border text-white/60 rounded-lg text-sm hover:bg-white/10 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* Project list */}
              {portfolioProjects.length === 0 ? (
                <div className="text-center py-16 text-white/30">
                  <Image className="w-10 h-10 mx-auto mb-3" />
                  <p>No portfolio projects yet. Add your first one!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {portfolioProjects.map((p) => (
                    <div key={p.id} className="bg-card border border-border rounded-xl p-4 flex gap-4 items-center">
                      <img
                        src={p.imageUrl}
                        alt={p.title}
                        className="w-20 h-14 object-cover rounded-lg border border-border shrink-0"
                        onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-white font-semibold text-sm">{p.title}</span>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">{p.category}</span>
                          {!p.isVisible && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-white/30 border border-white/10 flex items-center gap-1">
                              <EyeOff className="w-3 h-3" /> Hidden
                            </span>
                          )}
                        </div>
                        <p className="text-white/40 text-xs mt-0.5 line-clamp-1">{p.description}</p>
                        <p className="text-white/25 text-xs mt-0.5">Sort order: {p.sortOrder}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => setPortfolioForm({ ...p })}
                          className="p-2 rounded-lg bg-white/5 border border-border text-white/50 hover:text-white hover:bg-white/10 transition-colors"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={async () => {
                            try {
                              await api.portfolio.update(p.id, { isVisible: !p.isVisible });
                              setPortfolioProjects((ps) => ps.map((x) => x.id === p.id ? { ...x, isVisible: !x.isVisible } : x));
                            } catch { setPortfolioError("Failed to update visibility."); }
                          }}
                          className="p-2 rounded-lg bg-white/5 border border-border text-white/50 hover:text-white hover:bg-white/10 transition-colors"
                          title={p.isVisible ? "Hide from homepage" : "Show on homepage"}
                        >
                          {p.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={async () => {
                            if (!confirm("Delete this portfolio project?")) return;
                            try {
                              await api.portfolio.delete(p.id);
                              setPortfolioProjects((ps) => ps.filter((x) => x.id !== p.id));
                            } catch { setPortfolioError("Failed to delete project."); }
                          }}
                          className="p-2 rounded-lg bg-red-500/5 border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Artist Applications */}
          {tab === "artist_apps" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">ARTIST APPLICATIONS</h1>
              {/* Filter bar */}
              <div className="flex gap-2 mb-5 flex-wrap">
                {(["all", "pending", "approved", "rejected"] as const).map((v) => {
                  const label = v === "all" ? "All" : (ARTIST_APP_STATUS[v]?.label ?? v);
                  const count = v === "all" ? artistApps.length : artistApps.filter((a) => a.status === v).length;
                  const active = appFilter === v;
                  return (
                    <button
                      key={v}
                      onClick={() => setAppFilter(v)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                        active
                          ? "border-primary/40 bg-primary/10 text-primary"
                          : "border-white/10 text-white/40 hover:text-white/70 hover:border-white/20"
                      }`}
                    >
                      {label}{count > 0 && <span className="ml-1.5 opacity-60">{count}</span>}
                    </button>
                  );
                })}
              </div>
              <div className="space-y-4">
                {artistApps.filter((a) => appFilter === "all" || a.status === appFilter).length === 0 && (
                  <div className="text-center py-16 text-white/30"><Music className="w-10 h-10 mx-auto mb-3" /><p>{artistApps.length === 0 ? "No applications yet" : "No applications match this filter"}</p></div>
                )}
                {artistApps.filter((a) => appFilter === "all" || a.status === appFilter).map((app) => (
                  <div key={app.id} className="bg-card border border-border rounded-xl p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="text-white font-bold text-lg">{app.stageName}</div>
                        <div className="text-white/40 text-sm">{app.userName} · {app.userEmail}</div>
                        <div className="text-white/50 text-sm mt-1">Genre: {app.genre}</div>
                      </div>
                      <span className={`text-xs px-3 py-1 rounded-full border ${
                        app.status === "pending" ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" :
                        app.status === "approved" ? "bg-green-500/10 text-green-400 border-green-500/20" :
                        "bg-red-500/10 text-red-400 border-red-500/20"
                      }`}>
                        {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm mb-4 leading-relaxed">{app.bio}</p>
                    {app.socialLinks && <p className="text-white/40 text-xs mb-4">Links: {app.socialLinks}</p>}
                    {app.status === "pending" && (
                      <div className="space-y-3">
                        <textarea
                          rows={2}
                          className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="Admin notes (optional feedback)..."
                          value={reviewNotes[app.id] ?? ""}
                          onChange={(e) => setReviewNotes((n) => ({ ...n, [app.id]: e.target.value }))}
                        />
                        <div className="flex gap-3">
                          <Button onClick={() => reviewArtistApp(app.id, "approved")} className="bg-green-600 hover:bg-green-700 text-white font-bold flex-1">
                            <CheckCircle className="w-4 h-4 mr-2" /> Approve
                          </Button>
                          <Button onClick={() => reviewArtistApp(app.id, "rejected")} variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10 flex-1">
                            <XCircle className="w-4 h-4 mr-2" /> Reject
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Releases */}
          {tab === "releases" && (
            <div>
              {selectedRelease ? (
                <AdminReleaseDetail
                  release={selectedRelease}
                  onBack={() => setSelectedRelease(null)}
                  onUpdated={(updated) => {
                    setSelectedRelease(updated);
                    setReleases((rs) => rs.map((r) => r.id === updated.id ? { ...r, ...updated } : r));
                  }}
                  onDeleted={(id) => {
                    setReleases((rs) => rs.filter((r) => r.id !== id));
                    setSelectedRelease(null);
                  }}
                />
              ) : (
                <>
                  <h1 className="font-display text-4xl text-white mb-6">MUSIC RELEASES</h1>
                  {/* Filter bar */}
                  <div className="flex gap-2 mb-5 flex-wrap">
                    {["all", "pending_review", "changes_requested", "approved", "live", "rejected"].map((v) => {
                      const label = v === "all" ? "All" : (RELEASE_STATUS[v]?.label ?? v);
                      const count = v === "all" ? releases.length : releases.filter((r) => r.status === v).length;
                      const active = releaseFilter === v;
                      return (
                        <button
                          key={v}
                          onClick={() => setReleaseFilter(v)}
                          className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                            active
                              ? "border-primary/40 bg-primary/10 text-primary"
                              : "border-white/10 text-white/40 hover:text-white/70 hover:border-white/20"
                          }`}
                        >
                          {label}{count > 0 && <span className="ml-1.5 opacity-60">{count}</span>}
                        </button>
                      );
                    })}
                  </div>
                  {releaseDetailLoading && (
                    <div className="flex items-center justify-center py-8">
                      <div className="w-7 h-7 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                  <div className="space-y-2">
                    {releases.length === 0 && (
                      <div className="text-center py-16 text-white/30">
                        <Music className="w-10 h-10 mx-auto mb-3" />
                        <p>No releases submitted yet</p>
                      </div>
                    )}
                    {releases
                      .filter((r) => releaseFilter === "all" || r.status === releaseFilter)
                      .map((r) => {
                      const s = RELEASE_STATUS[r.status] ?? RELEASE_STATUS.draft;
                      const displayTitle = r.releaseType !== "single" && r.releaseTitle ? r.releaseTitle : r.title;
                      return (
                        <button
                          key={r.id}
                          onClick={() => openRelease(r)}
                          disabled={releaseDetailLoading}
                          className="w-full bg-card border border-border rounded-xl p-4 flex items-center gap-4 hover:border-white/20 hover:bg-white/[0.04] transition-all text-left group disabled:opacity-60"
                        >
                          {r.artworkUrl ? (
                            <img src={r.artworkUrl} alt={displayTitle} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                          ) : (
                            <div className="w-14 h-14 rounded-lg bg-white/5 border border-border flex items-center justify-center shrink-0">
                              <Music className="w-6 h-6 text-white/20" />
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="text-white font-semibold truncate">
                              {displayTitle}
                              {r.releaseType !== "single" && (
                                <span className="ml-2 text-xs bg-white/10 text-white/40 px-1.5 py-0.5 rounded capitalize">{r.releaseType}</span>
                              )}
                            </div>
                            <div className="text-white/40 text-sm truncate">
                              {r.userName} · {r.genre} · {r.language}
                            </div>
                            <div className="text-white/25 text-xs mt-0.5 flex items-center gap-3">
                              {r.releaseDate && <span>Release: {r.releaseDate}</span>}
                              {r.stores && r.stores.length > 0 && <span>{r.stores.length} platforms</span>}
                              {(!r.isrc) && <span className="text-orange-400/60">No ISRC</span>}
                            </div>
                          </div>
                          <div className="flex items-center gap-3 shrink-0">
                            <span className={`text-xs px-2.5 py-1 rounded-full border whitespace-nowrap ${s.color}`}>{s.label}</span>
                            <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-colors" />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Artists management */}
          {tab === "artists" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">ARTISTS</h1>
              {/* Filter bar */}
              <div className="flex gap-2 mb-5 flex-wrap">
                {([
                  { v: "all",       label: "All",       count: artists.length },
                  { v: "active",    label: "Active",    count: artists.filter((a) => !a.isBlocked).length },
                  { v: "suspended", label: "Suspended", count: artists.filter((a) => a.isBlocked).length },
                ]).map(({ v, label, count }) => {
                  const active = artistFilter === v;
                  return (
                    <button
                      key={v}
                      onClick={() => setArtistFilter(v)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                        active
                          ? "border-primary/40 bg-primary/10 text-primary"
                          : "border-white/10 text-white/40 hover:text-white/70 hover:border-white/20"
                      }`}
                    >
                      {label}{count > 0 && <span className="ml-1.5 opacity-60">{count}</span>}
                    </button>
                  );
                })}
              </div>
              <div className="space-y-4">
                {artists.filter((a) =>
                  artistFilter === "all" ||
                  (artistFilter === "active" && !a.isBlocked) ||
                  (artistFilter === "suspended" && a.isBlocked)
                ).length === 0 && (
                  <div className="text-center py-16 text-white/30"><Music className="w-10 h-10 mx-auto mb-3" /><p>{artists.length === 0 ? "No verified artists yet" : "No artists match this filter"}</p></div>
                )}
                {artists.filter((a) =>
                  artistFilter === "all" ||
                  (artistFilter === "active" && !a.isBlocked) ||
                  (artistFilter === "suspended" && a.isBlocked)
                ).map((a) => (
                  <div key={a.id} className={`bg-card border rounded-xl p-5 ${a.isBlocked ? "border-red-500/30" : "border-border"}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="text-white font-bold">{a.name}</div>
                          {a.isBlocked && (
                            <span className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <ShieldOff className="w-3 h-3" /> Suspended
                            </span>
                          )}
                        </div>
                        <div className="text-white/40 text-sm">{a.email}</div>
                        {a.isBlocked && a.blockedReason && (
                          <div className="text-red-400/70 text-xs mt-1">Reason: {a.blockedReason}</div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {a.isBlocked ? (
                          <Button
                            size="sm"
                            onClick={() => unblockArtist(a.id)}
                            className="bg-green-600 hover:bg-green-700 text-white text-xs"
                          >
                            <UserCheck className="w-3.5 h-3.5 mr-1" /> Unblock
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => blockArtist(a.id)}
                            className="bg-orange-600 hover:bg-orange-700 text-white text-xs"
                          >
                            <UserX className="w-3.5 h-3.5 mr-1" /> Block
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteArtist(a.id)}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 text-xs"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                    {!a.isBlocked && (
                      <div className="mt-3 flex gap-2">
                        <input
                          className="flex-1 bg-input border border-border rounded-lg px-3 py-1.5 text-white text-xs focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="Block reason (optional)..."
                          value={blockReason[a.id] ?? ""}
                          onChange={(e) => setBlockReason((b) => ({ ...b, [a.id]: e.target.value }))}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Analytics */}
          {tab === "analytics" && (
            <div className="max-w-3xl space-y-6">
              <div className="bg-card border border-border rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-1">Upload Streaming Analytics</h2>
                <p className="text-white/50 text-sm mb-4">
                  Upload a CSV export from your distributor. Rows are matched to artists automatically by ISRC and routed to that artist's Analytics tab.
                </p>
                <input
                  ref={analyticsFileRef}
                  type="file"
                  accept=".csv,text/csv"
                  onChange={uploadAnalyticsCsv}
                  disabled={analyticsUploading}
                  className="hidden"
                  id="analytics-csv-input"
                />
                <label
                  htmlFor="analytics-csv-input"
                  className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg font-bold text-sm cursor-pointer ${analyticsUploading ? "bg-white/10 text-white/40 cursor-not-allowed" : "bg-primary text-black hover:bg-primary/90"}`}
                >
                  <Upload className="w-4 h-4" />
                  {analyticsUploading ? "Processing..." : "Upload CSV"}
                </label>

                {analyticsError && (
                  <p className="text-red-400 text-sm mt-3">{analyticsError}</p>
                )}

                {analyticsResult && (
                  <div className="mt-4 bg-black/30 border border-border rounded-xl p-4 text-sm">
                    <p className="text-white">
                      Processed <span className="font-bold">{analyticsResult.totalRows}</span> rows —{" "}
                      <span className="text-green-400 font-bold">{analyticsResult.matchedRows} matched</span>
                      {analyticsResult.unmatchedRows > 0 && (
                        <> · <span className="text-orange-400 font-bold">{analyticsResult.unmatchedRows} unmatched</span></>
                      )}
                    </p>
                    {analyticsResult.unmatched.length > 0 && (
                      <div className="mt-3">
                        <p className="text-white/50 text-xs mb-2">Unmatched rows (no release found with this ISRC):</p>
                        <div className="space-y-1 max-h-40 overflow-y-auto">
                          {analyticsResult.unmatched.map((u, i) => (
                            <div key={i} className="text-white/60 text-xs font-mono">
                              {u.isrc} — {u.title || "untitled"} ({u.outlet}: {u.streams})
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-card border border-border rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-4">Upload History</h2>
                {analyticsUploads.length === 0 ? (
                  <p className="text-white/40 text-sm">No CSV uploads yet.</p>
                ) : (
                  <div className="space-y-2">
                    {analyticsUploads.map((u) => (
                      <div key={u.id} className="flex items-center justify-between bg-black/20 border border-border rounded-lg px-4 py-3">
                        <div>
                          <p className="text-white text-sm font-medium">{u.filename}</p>
                          <p className="text-white/40 text-xs">{new Date(u.createdAt).toLocaleString()}</p>
                        </div>
                        <div className="text-right text-xs">
                          <p className="text-green-400">{u.matchedRows} matched</p>
                          {u.unmatchedRows > 0 && <p className="text-orange-400">{u.unmatchedRows} unmatched</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Earnings Upload */}
          {tab === "earnings" && (
            <div className="max-w-3xl space-y-6">
              <div className="bg-card border border-border rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-1">Upload Earnings CSV</h2>
                <p className="text-white/50 text-sm mb-4">
                  Upload a CSV with <span className="font-mono text-white/70">ISRC</span> and <span className="font-mono text-white/70">Earnings</span> columns (amounts in NGN). Rows are matched to artists automatically by ISRC and routed to that artist's Earnings tab.
                </p>
                <input
                  ref={earningsFileRef}
                  type="file"
                  accept=".csv,text/csv"
                  onChange={uploadEarningsCsv}
                  disabled={earningsUploading}
                  className="hidden"
                  id="earnings-csv-input"
                />
                <label
                  htmlFor="earnings-csv-input"
                  className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-lg font-bold text-sm cursor-pointer ${earningsUploading ? "bg-white/10 text-white/40 cursor-not-allowed" : "bg-primary text-black hover:bg-primary/90"}`}
                >
                  <Upload className="w-4 h-4" />
                  {earningsUploading ? "Processing..." : "Upload CSV"}
                </label>

                {earningsError && (
                  <p className="text-red-400 text-sm mt-3">{earningsError}</p>
                )}

                {earningsResult && (
                  <div className="mt-4 bg-black/30 border border-border rounded-xl p-4 text-sm">
                    <p className="text-white">
                      Processed <span className="font-bold">{earningsResult.totalRows}</span> rows —{" "}
                      <span className="text-green-400 font-bold">{earningsResult.matchedRows} matched</span>
                      {earningsResult.unmatchedRows > 0 && (
                        <> · <span className="text-orange-400 font-bold">{earningsResult.unmatchedRows} unmatched</span></>
                      )}
                    </p>
                    {earningsResult.unmatched.length > 0 && (
                      <div className="mt-3">
                        <p className="text-white/50 text-xs mb-2">Unmatched rows (no release found with this ISRC):</p>
                        <div className="space-y-1 max-h-40 overflow-y-auto">
                          {earningsResult.unmatched.map((u, i) => (
                            <div key={i} className="text-white/60 text-xs font-mono">
                              {u.isrc} — ₦{u.earnings.toLocaleString()}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="bg-card border border-border rounded-2xl p-6">
                <h2 className="text-white font-bold text-lg mb-4">Upload History</h2>
                {earningsUploads.length === 0 ? (
                  <p className="text-white/40 text-sm">No earnings CSV uploads yet.</p>
                ) : (
                  <div className="space-y-2">
                    {earningsUploads.map((u) => (
                      <div key={u.id} className="flex items-center justify-between bg-black/20 border border-border rounded-lg px-4 py-3">
                        <div>
                          <p className="text-white text-sm font-medium">{u.filename}</p>
                          <p className="text-white/40 text-xs">{new Date(u.createdAt).toLocaleString()}</p>
                        </div>
                        <div className="text-right text-xs">
                          <p className="text-green-400">{u.matchedRows} matched</p>
                          {u.unmatchedRows > 0 && <p className="text-orange-400">{u.unmatchedRows} unmatched</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Payment Requests */}
          {tab === "payment_requests" && (
            <div className="max-w-4xl">
              <h1 className="font-display text-4xl text-white mb-6">PAYMENT REQUESTS</h1>
              {/* Filter bar */}
              <div className="flex gap-2 mb-5 flex-wrap">
                {(["all", "pending", "paid"] as const).map((v) => {
                  const label = v === "all" ? "All" : (PAYMENT_REQUEST_STATUS[v]?.label ?? v);
                  const count = v === "all" ? paymentRequests.length : paymentRequests.filter((r) => r.status === v).length;
                  const active = paymentFilter === v;
                  return (
                    <button
                      key={v}
                      onClick={() => setPaymentFilter(v)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                        active
                          ? "border-primary/40 bg-primary/10 text-primary"
                          : "border-white/10 text-white/40 hover:text-white/70 hover:border-white/20"
                      }`}
                    >
                      {label}{count > 0 && <span className="ml-1.5 opacity-60">{count}</span>}
                    </button>
                  );
                })}
              </div>
              {paymentRequestsLoading ? (
                <div className="flex justify-center py-16">
                  <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : paymentRequests.filter((r) => paymentFilter === "all" || r.status === paymentFilter).length === 0 ? (
                <div className="text-center py-16 text-white/30"><Send className="w-10 h-10 mx-auto mb-3" /><p>{paymentRequests.length === 0 ? "No payment requests yet" : "No requests match this filter"}</p></div>
              ) : (
                <div className="space-y-4">
                  {paymentRequests.filter((r) => paymentFilter === "all" || r.status === paymentFilter).map((r) => {
                    const s = PAYMENT_REQUEST_STATUS[r.status] ?? PAYMENT_REQUEST_STATUS.pending;
                    let snapshot: Record<string, string> | null = null;
                    let snapshotMethod = "", snapshotCurrency = "", snapshotBankType = "";
                    try {
                      const parsed = JSON.parse(r.payoutMethodSnapshot ?? "null");
                      if (parsed) {
                        snapshot = parsed.details;
                        snapshotMethod = parsed.method;
                        snapshotCurrency = parsed.currency ?? "";
                        snapshotBankType = parsed.bankDetailType ?? "";
                      }
                    } catch {}
                    return (
                      <div key={r.id} className="bg-card border border-border rounded-xl p-5">
                        <div className="flex items-start justify-between gap-4 flex-wrap">
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="text-white font-bold text-lg">₦{r.amountNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                              <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${s.color}`}>{s.label}</span>
                            </div>
                            <p className="text-white/50 text-sm mt-0.5">{r.userName} · {r.userEmail}</p>
                            <p className="text-white/30 text-xs mt-1">
                              Requested {new Date(r.createdAt).toLocaleString()}
                              {r.paidAt && ` · Paid ${new Date(r.paidAt).toLocaleString()}`}
                            </p>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                              {r.status === "pending" && (
                              <Button size="sm" onClick={() => { setProcessingRequest(r); setPaymentError(null); }} className="bg-primary text-black hover:bg-primary/90 text-xs font-bold">
                                Process Payment
                              </Button>
                            )}
                          </div>
                        </div>

                        {snapshot && (
                          <div className="mt-4 bg-black/30 border border-border rounded-lg p-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                            <div>
                              <p className="text-white/30 uppercase tracking-wider mb-0.5">Method</p>
                              <p className="text-white/80 capitalize">{snapshotMethod === "paypal" ? "PayPal" : `Bank Transfer (${snapshotCurrency})`}</p>
                            </div>
                            {snapshotMethod === "bank_transfer" && (
                              <div>
                                <p className="text-white/30 uppercase tracking-wider mb-0.5">Type</p>
                                <p className="text-white/80 uppercase">{snapshotBankType}</p>
                              </div>
                            )}
                            {Object.entries(snapshot).map(([k, v]) => (
                              <div key={k}>
                                <p className="text-white/30 uppercase tracking-wider mb-0.5">{k.replace(/([A-Z])/g, " $1")}</p>
                                <p className="text-white/80 font-mono break-all">{v}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Support Tickets */}
          {tab === "support" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">SUPPORT TICKETS</h1>
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-2 space-y-3 max-h-[70vh] overflow-y-auto pr-1">
                  {tickets.length === 0 && (
                    <div className="text-center py-12 text-white/30"><LifeBuoy className="w-10 h-10 mx-auto mb-3" /><p>No tickets</p></div>
                  )}
                  {tickets.map((t) => {
                    const s = TICKET_STATUS[t.status] ?? TICKET_STATUS.open;
                    return (
                      <div
                        key={t.id}
                        onClick={() => selectTicket(t)}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${selectedTicket?.id === t.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-white/20"}`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="text-white font-medium text-sm truncate">{t.subject}</div>
                            <div className="text-white/40 text-xs">{t.userName} · {new Date(t.createdAt).toLocaleDateString()}</div>
                            <span className={`text-xs capitalize ${t.priority === "urgent" ? "text-red-400" : t.priority === "high" ? "text-orange-400" : "text-white/30"}`}>
                              {t.priority}
                            </span>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full border shrink-0 ${s.color}`}>{s.label}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="lg:col-span-3">
                  {!selectedTicket ? (
                    <div className="flex items-center justify-center h-64 text-white/20 text-center">
                      <div><LifeBuoy className="w-12 h-12 mx-auto mb-3" /><p>Select a ticket</p></div>
                    </div>
                  ) : (
                    <div className="bg-card border border-border rounded-xl overflow-hidden">
                      <div className="p-4 border-b border-border flex items-center justify-between">
                        <div>
                          <h3 className="text-white font-bold">{selectedTicket.subject}</h3>
                          <div className="text-white/40 text-xs mt-0.5">{selectedTicket.userName} · {selectedTicket.userEmail}</div>
                        </div>
                        <select
                          className="bg-input border border-border rounded-lg px-2 py-1 text-white text-xs focus:outline-none"
                          value={selectedTicket.status}
                          onChange={async (e) => {
                            const updated = await api.support.updateStatus(selectedTicket.id, e.target.value);
                            setSelectedTicket(updated);
                            setTickets((ts) => ts.map((t) => t.id === updated.id ? updated : t));
                          }}
                        >
                          {Object.entries(TICKET_STATUS).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
                        </select>
                      </div>
                      <div className="p-4 max-h-64 overflow-y-auto flex flex-col gap-3">
                        {ticketMessages.map((msg) => (
                          <div key={msg.id} className={`flex ${msg.isStaff ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${msg.isStaff ? "bg-primary text-black font-medium" : "bg-card border border-border text-white/80"}`}>
                              {!msg.isStaff && <div className="text-xs text-white/40 mb-1">Client</div>}
                              {msg.message}
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="p-4 flex gap-3 border-t border-border">
                        <Textarea placeholder="Reply to client..." rows={2} value={ticketReply} onChange={(e) => setTicketReply(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendTicketReply(); } }} className="resize-none" />
                        <Button onClick={sendTicketReply} className="bg-primary text-black hover:bg-primary/90 shrink-0"><Send className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* All Users */}
          {tab === "users" && user.role === "admin" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">ALL USERS</h1>
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left px-4 py-3 text-white/50 font-medium">Name</th>
                      <th className="text-left px-4 py-3 text-white/50 font-medium hidden sm:table-cell">Email</th>
                      <th className="text-left px-4 py-3 text-white/50 font-medium">Role</th>
                      <th className="text-left px-4 py-3 text-white/50 font-medium hidden md:table-cell">Status</th>
                      <th className="text-left px-4 py-3 text-white/50 font-medium hidden md:table-cell">Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-white/2">
                        <td className="px-4 py-3 text-white font-medium">{u.name}</td>
                        <td className="px-4 py-3 text-white/50 hidden sm:table-cell">{u.email}</td>
                        <td className="px-4 py-3">
                          <select
                            className="bg-input border border-border rounded-lg px-2 py-1 text-white text-xs focus:outline-none"
                            value={u.role}
                            onChange={(e) => updateUserRole(u.id, e.target.value)}
                          >
                            <option value="client">Client</option>
                            <option value="verified_artist">Verified Artist</option>
                            <option value="moderator">Moderator</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          {u.isBlocked ? (
                            <span className="text-xs text-red-400 flex items-center gap-1"><ShieldOff className="w-3 h-3" /> Blocked</span>
                          ) : (
                            <span className="text-xs text-green-400">Active</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-white/40 hidden md:table-cell">{new Date(u.createdAt ?? "").toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Blog */}
          {tab === "blog" && user.role === "admin" && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h1 className="font-display text-4xl text-white">BLOG</h1>
                {!blogForm && (
                  <Button
                    onClick={() => { setBlogForm({ isPublished: false, author: "Nazy Empire", category: "General" }); setBlogEditingId(null); setBlogError(null); setBlogPreviewMode(false); }}
                    className="bg-primary text-black hover:bg-primary/90 font-bold gap-2"
                  >
                    <Plus className="w-4 h-4" /> New Post
                  </Button>
                )}
              </div>

              {/* Editor */}
              {blogForm && (
                <div className="mb-10">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-white font-semibold text-lg">{blogEditingId ? "Edit Post" : "New Post"}</h2>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setBlogPreviewMode((v) => !v)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-white/50 text-xs hover:text-white hover:border-white/20 transition-colors"
                      >
                        {blogPreviewMode ? <><EyeOff className="w-3.5 h-3.5" /> Edit</> : <><Eye className="w-3.5 h-3.5" /> Preview</>}
                      </button>
                      <button
                        type="button"
                        onClick={() => { setBlogForm(null); setBlogEditingId(null); setBlogError(null); setBlogPreviewMode(false); }}
                        className="px-3 py-1.5 rounded-lg border border-border text-white/50 text-xs hover:text-white hover:border-white/20 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>

                  {blogPreviewMode ? (
                    <div className="bg-card border border-border rounded-xl p-6 max-h-[70vh] overflow-y-auto">
                      {blogForm.featuredImage && <img src={blogForm.featuredImage} alt="Featured" className="w-full max-h-64 object-cover rounded-lg mb-6" />}
                      <p className="text-primary text-xs font-medium mb-2">{blogForm.category}</p>
                      <h2 className="font-display text-3xl text-white mb-3">{blogForm.title || "Untitled"}</h2>
                      {blogForm.excerpt && <p className="text-white/60 mb-6 leading-relaxed">{blogForm.excerpt}</p>}
                      <div className="border-t border-border pt-6 text-white/70 leading-relaxed whitespace-pre-wrap">{blogForm.content}</div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                      {/* Main fields */}
                      <div className="xl:col-span-2 space-y-4">
                        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                          <p className="text-white/50 text-xs uppercase tracking-wider font-medium border-b border-border pb-2">Post Content</p>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Title <span className="text-red-400">*</span></label>
                            <Input
                              value={blogForm.title || ""}
                              onChange={(e) => {
                                const t = e.target.value;
                                setBlogForm((f) => ({ ...f, title: t, slug: f?.slug || blogEditingId ? f?.slug || "" : blogSlugify(t) }));
                              }}
                              placeholder="Post title"
                              className="bg-input border-border text-white"
                            />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Slug (URL) <span className="text-red-400">*</span></label>
                            <Input
                              value={blogForm.slug || ""}
                              onChange={(e) => setBlogForm((f) => ({ ...f, slug: e.target.value }))}
                              placeholder="post-url-slug"
                              className="bg-input border-border text-white font-mono text-sm"
                            />
                            <p className="text-white/30 text-xs mt-1">/blog/{blogForm.slug || "post-slug"}</p>
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Excerpt / Short Description</label>
                            <Textarea
                              rows={3}
                              value={blogForm.excerpt || ""}
                              onChange={(e) => setBlogForm((f) => ({ ...f, excerpt: e.target.value }))}
                              placeholder="A short summary shown in listings and search results"
                              className="bg-input border-border text-white resize-none"
                            />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Content <span className="text-red-400">*</span></label>
                            <p className="text-white/30 text-xs mb-2">Supports ## Headings, ### Sub-headings, **bold**, - bullet lists, &gt; blockquotes</p>
                            <Textarea
                              rows={18}
                              value={blogForm.content || ""}
                              onChange={(e) => setBlogForm((f) => ({ ...f, content: e.target.value }))}
                              placeholder="Write your article content here..."
                              className="bg-input border-border text-white resize-y font-mono text-sm"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Sidebar */}
                      <div className="space-y-4">
                        {/* Publish settings */}
                        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                          <p className="text-white/50 text-xs uppercase tracking-wider font-medium border-b border-border pb-2">Publish</p>
                          <label className="flex items-center gap-3 cursor-pointer">
                            <div
                              onClick={() => setBlogForm((f) => ({ ...f, isPublished: !f?.isPublished }))}
                              className={`w-10 h-6 rounded-full transition-colors relative ${blogForm.isPublished ? "bg-primary" : "bg-white/20"}`}
                            >
                              <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${blogForm.isPublished ? "left-5" : "left-1"}`} />
                            </div>
                            <span className="text-white text-sm">{blogForm.isPublished ? "Published" : "Draft"}</span>
                          </label>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Author</label>
                            <Input value={blogForm.author || ""} onChange={(e) => setBlogForm((f) => ({ ...f, author: e.target.value }))} placeholder="Nazy Empire" className="bg-input border-border text-white" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Category</label>
                            <Input value={blogForm.category || ""} onChange={(e) => setBlogForm((f) => ({ ...f, category: e.target.value }))} placeholder="e.g. Music Distribution" className="bg-input border-border text-white" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Tags (comma-separated)</label>
                            <Input value={blogForm.tags || ""} onChange={(e) => setBlogForm((f) => ({ ...f, tags: e.target.value }))} placeholder="music, nigeria, spotify" className="bg-input border-border text-white" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Featured Image URL</label>
                            <Input value={blogForm.featuredImage || ""} onChange={(e) => setBlogForm((f) => ({ ...f, featuredImage: e.target.value }))} placeholder="https://..." className="bg-input border-border text-white" />
                          </div>
                        </div>

                        {/* SEO */}
                        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                          <p className="text-white/50 text-xs uppercase tracking-wider font-medium border-b border-border pb-2">SEO Settings</p>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Meta Title <span className="text-white/30">(max 60 chars)</span></label>
                            <Input
                              value={blogForm.metaTitle || ""}
                              onChange={(e) => setBlogForm((f) => ({ ...f, metaTitle: e.target.value }))}
                              placeholder={blogForm.title || "Page title for Google"}
                              className="bg-input border-border text-white"
                              maxLength={60}
                            />
                            <p className="text-white/30 text-xs mt-1">{(blogForm.metaTitle || "").length}/60</p>
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Meta Description <span className="text-white/30">(max 160 chars)</span></label>
                            <Textarea
                              rows={3}
                              value={blogForm.metaDescription || ""}
                              onChange={(e) => setBlogForm((f) => ({ ...f, metaDescription: e.target.value }))}
                              placeholder={blogForm.excerpt || "Description for Google search results"}
                              className="bg-input border-border text-white resize-none"
                              maxLength={160}
                            />
                            <p className="text-white/30 text-xs mt-1">{(blogForm.metaDescription || "").length}/160</p>
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Meta Keywords</label>
                            <Input value={blogForm.metaKeywords || ""} onChange={(e) => setBlogForm((f) => ({ ...f, metaKeywords: e.target.value }))} placeholder="keyword1, keyword2, keyword3" className="bg-input border-border text-white" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">Canonical URL</label>
                            <Input value={blogForm.canonicalUrl || ""} onChange={(e) => setBlogForm((f) => ({ ...f, canonicalUrl: e.target.value }))} placeholder="https://nazyempire.com/blog/..." className="bg-input border-border text-white" />
                          </div>
                        </div>

                        {/* Open Graph */}
                        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
                          <p className="text-white/50 text-xs uppercase tracking-wider font-medium border-b border-border pb-2">Open Graph (Social Sharing)</p>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">OG Title</label>
                            <Input value={blogForm.ogTitle || ""} onChange={(e) => setBlogForm((f) => ({ ...f, ogTitle: e.target.value }))} placeholder={blogForm.metaTitle || blogForm.title || ""} className="bg-input border-border text-white" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">OG Description</label>
                            <Textarea rows={2} value={blogForm.ogDescription || ""} onChange={(e) => setBlogForm((f) => ({ ...f, ogDescription: e.target.value }))} placeholder={blogForm.metaDescription || blogForm.excerpt || ""} className="bg-input border-border text-white resize-none" />
                          </div>
                          <div>
                            <label className="text-white/50 text-xs block mb-1">OG Image URL</label>
                            <Input value={blogForm.ogImage || ""} onChange={(e) => setBlogForm((f) => ({ ...f, ogImage: e.target.value }))} placeholder={blogForm.featuredImage || "https://..."} className="bg-input border-border text-white" />
                            <p className="text-white/30 text-xs mt-1">Shown when shared on WhatsApp, Twitter, Facebook. Recommended: 1200×630px</p>
                          </div>
                          {/* Preview card */}
                          {(blogForm.ogImage || blogForm.featuredImage) && (
                            <div className="border border-border rounded-lg overflow-hidden text-xs">
                              <img src={blogForm.ogImage || blogForm.featuredImage || ""} alt="" className="w-full h-28 object-cover" />
                              <div className="p-2 bg-zinc-900">
                                <p className="text-white/30 text-xs">nazyempire.com</p>
                                <p className="text-white font-medium">{blogForm.ogTitle || blogForm.metaTitle || blogForm.title}</p>
                                <p className="text-white/50 line-clamp-1">{blogForm.ogDescription || blogForm.metaDescription || blogForm.excerpt}</p>
                              </div>
                            </div>
                          )}
                        </div>

                        {blogError && <p className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg p-3">{blogError}</p>}
                        <Button onClick={saveBlogPost} disabled={blogSaving} className="w-full bg-primary text-black hover:bg-primary/90 font-bold">
                          {blogSaving ? "Saving…" : blogEditingId ? "Update Post" : "Publish Post"}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Posts list */}
              {!blogForm && (
                <div className="space-y-3">
                  {blogPosts.length === 0 && (
                    <div className="text-center py-16 text-white/30">
                      <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40" />
                      <p>No blog posts yet — create your first one.</p>
                    </div>
                  )}
                  {blogPosts.map((post) => (
                    <div key={post.id} className="bg-card border border-border rounded-xl p-4 flex items-start gap-4">
                      {post.featuredImage && (
                        <img src={post.featuredImage} alt={post.title} className="w-20 h-16 object-cover rounded-lg shrink-0 hidden sm:block" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${post.isPublished ? "bg-green-500/10 text-green-400 border-green-500/20" : "bg-white/5 text-white/40 border-white/10"}`}>
                            {post.isPublished ? "Published" : "Draft"}
                          </span>
                          {post.category && (
                            <span className="flex items-center gap-1 text-xs text-primary/70">
                              <Tag className="w-3 h-3" /> {post.category}
                            </span>
                          )}
                        </div>
                        <h3 className="text-white font-semibold truncate">{post.title}</h3>
                        {post.excerpt && <p className="text-white/40 text-sm truncate mt-0.5">{post.excerpt}</p>}
                        <div className="flex items-center gap-3 text-white/30 text-xs mt-1.5">
                          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : new Date(post.createdAt).toLocaleDateString()}</span>
                          <a href={`/blog/${post.slug}`} target="_blank" rel="noreferrer" className="text-primary/60 hover:text-primary transition-colors">View →</a>
                        </div>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => { setBlogForm(post); setBlogEditingId(post.id); setBlogError(null); setBlogPreviewMode(false); }}
                          className="p-2 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors"
                          title="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteBlogPost(post.id)}
                          className="p-2 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Settings */}
          {/* Artist Orders */}
          {tab === "artist_orders" && (
            <AdminArtistOrders />
          )}

          {/* Affiliates */}
          {tab === "affiliates" && user.role === "admin" && (
            <div>
              <h1 className="font-display text-4xl text-white mb-6">AFFILIATES</h1>

              {/* Sub-tabs */}
              <div className="flex gap-2 mb-6">
                {(["applications", "withdrawals", "commissions"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setAffSubTab(s)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${affSubTab === s ? "bg-primary text-black" : "text-white/50 hover:text-white"}`}
                  >
                    {s}
                    {s === "applications" && affApps.filter((a) => a.status === "pending").length > 0 && (
                      <span className="ml-1.5 bg-yellow-500 text-black text-xs px-1.5 py-0.5 rounded-full font-bold">
                        {affApps.filter((a) => a.status === "pending").length}
                      </span>
                    )}
                    {s === "withdrawals" && affWithdrawals.filter((w) => w.status === "pending").length > 0 && (
                      <span className="ml-1.5 bg-yellow-500 text-black text-xs px-1.5 py-0.5 rounded-full font-bold">
                        {affWithdrawals.filter((w) => w.status === "pending").length}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {affLoading && <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" /></div>}

              {/* Applications */}
              {!affLoading && affSubTab === "applications" && (
                <div className="space-y-4">
                  {affApps.length === 0 && (
                    <div className="text-center py-12 text-white/30"><Share2 className="w-10 h-10 mx-auto mb-3" /><p>No affiliate applications yet.</p></div>
                  )}
                  {affApps.map((a) => {
                    const s = { pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20", approved: "bg-green-500/10 text-green-400 border-green-500/20", rejected: "bg-red-500/10 text-red-400 border-red-500/20" }[a.status];
                    return (
                      <div key={a.id} className="bg-card border border-border rounded-xl p-5 space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <p className="text-white font-semibold">{a.userName ?? "—"}</p>
                            <p className="text-white/40 text-xs">{a.userEmail} · {new Date(a.createdAt).toLocaleDateString()}</p>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full border shrink-0 capitalize ${s}`}>{a.status}</span>
                        </div>
                        <p className="text-white/70 text-sm">{a.reason}</p>
                        {a.platform && <p className="text-white/40 text-xs">Platform: {a.platform}</p>}
                        {a.adminNotes && <p className="text-white/50 text-xs italic">Notes: {a.adminNotes}</p>}
                        {a.status === "pending" && (
                          <div className="space-y-2 pt-1">
                            <input
                              className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                              placeholder="Admin notes (optional)"
                              value={affAppNotes[a.id] ?? ""}
                              onChange={(e) => setAffAppNotes((n) => ({ ...n, [a.id]: e.target.value }))}
                            />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => reviewAffApp(a.id, "approved")} className="bg-green-600 hover:bg-green-700 text-white font-bold">
                                <CheckCircle className="w-3.5 h-3.5 mr-1" /> Approve
                              </Button>
                              <Button size="sm" onClick={() => reviewAffApp(a.id, "rejected")} variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
                                <XCircle className="w-3.5 h-3.5 mr-1" /> Reject
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Withdrawals */}
              {!affLoading && affSubTab === "withdrawals" && (
                <div className="space-y-4">
                  {affWithdrawals.length === 0 && (
                    <div className="text-center py-12 text-white/30"><DollarSign className="w-10 h-10 mx-auto mb-3" /><p>No withdrawal requests yet.</p></div>
                  )}
                  {affWithdrawals.map((w) => {
                    const sc = { pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20", approved: "bg-blue-500/10 text-blue-400 border-blue-500/20", paid: "bg-green-500/10 text-green-400 border-green-500/20", rejected: "bg-red-500/10 text-red-400 border-red-500/20" }[w.status];
                    return (
                      <div key={w.id} className="bg-card border border-border rounded-xl p-5 space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <p className="text-white font-semibold">{w.userName ?? "—"} <span className="text-primary font-bold">₦{w.amount.toLocaleString("en-NG", { minimumFractionDigits: 2 })}</span></p>
                            <p className="text-white/40 text-xs">{w.userEmail} · {new Date(w.createdAt).toLocaleDateString()}</p>
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full border shrink-0 capitalize ${sc}`}>{w.status}</span>
                        </div>
                        {w.notes && <p className="text-white/60 text-sm">{w.notes}</p>}
                        {w.adminNotes && <p className="text-white/40 text-xs italic">Notes: {w.adminNotes}</p>}
                        {(w.status === "pending" || w.status === "approved") && (
                          <div className="space-y-2 pt-1">
                            <input
                              className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                              placeholder="Admin notes (optional)"
                              value={affWdNotes[w.id] ?? ""}
                              onChange={(e) => setAffWdNotes((n) => ({ ...n, [w.id]: e.target.value }))}
                            />
                            <div className="flex gap-2 flex-wrap">
                              {w.status === "pending" && (
                                <Button size="sm" onClick={() => updateAffWithdrawal(w.id, "approved")} className="bg-blue-600 hover:bg-blue-700 text-white font-bold">
                                  <CheckCircle className="w-3.5 h-3.5 mr-1" /> Approve
                                </Button>
                              )}
                              <Button size="sm" onClick={() => updateAffWithdrawal(w.id, "paid")} className="bg-green-600 hover:bg-green-700 text-white font-bold">
                                <DollarSign className="w-3.5 h-3.5 mr-1" /> Mark Paid
                              </Button>
                              <Button size="sm" onClick={() => updateAffWithdrawal(w.id, "rejected")} variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
                                <XCircle className="w-3.5 h-3.5 mr-1" /> Reject
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Commissions */}
              {!affLoading && affSubTab === "commissions" && (
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  {affCommissions.length === 0 ? (
                    <div className="text-center py-12 text-white/30"><DollarSign className="w-10 h-10 mx-auto mb-3" /><p>No commissions yet.</p></div>
                  ) : (
                    <table className="w-full text-sm">
                      <thead className="border-b border-border">
                        <tr className="text-white/40 text-xs uppercase">
                          <th className="text-left px-5 py-3">Affiliate</th>
                          <th className="text-left px-5 py-3">Project</th>
                          <th className="text-right px-5 py-3">Commission</th>
                          <th className="text-right px-5 py-3">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {affCommissions.map((c) => (
                          <tr key={c.id}>
                            <td className="px-5 py-3">
                              <p className="text-white">{c.affiliateName ?? "—"}</p>
                              <p className="text-white/40 text-xs">{c.affiliateEmail}</p>
                            </td>
                            <td className="px-5 py-3 text-white/60">{c.projectRef}</td>
                            <td className="px-5 py-3 text-right">
                              <p className="text-primary font-bold">₦{c.commission.toLocaleString("en-NG", { minimumFractionDigits: 2 })}</p>
                              <p className="text-white/30 text-xs capitalize">{c.status}</p>
                            </td>
                            <td className="px-5 py-3 text-right text-white/40">{new Date(c.createdAt).toLocaleDateString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}
            </div>
          )}

          {tab === "settings" && user.role === "admin" && (
            <div className="max-w-2xl">
              <h1 className="font-display text-4xl text-white mb-6">SETTINGS</h1>
              <div className="bg-card border border-border rounded-xl p-6 space-y-4">
                {settings.map((s) => (
                  <div key={s.id} className="space-y-1">
                    <label className="text-white/50 text-xs uppercase tracking-wider">{s.key.replace(/_/g, " ")}</label>
                    <textarea
                      rows={s.value.length > 80 ? 4 : 1}
                      className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                      value={settingsEdits[s.key] ?? s.value}
                      onChange={(e) => setSettingsEdits((edits) => ({ ...edits, [s.key]: e.target.value }))}
                    />
                  </div>
                ))}
                {Object.keys(settingsEdits).length > 0 && (
                  <Button onClick={saveSettings} className="bg-primary text-black hover:bg-primary/90 font-bold">
                    Save Changes ({Object.keys(settingsEdits).length} modified)
                  </Button>
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {processingRequest && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 backdrop-blur-sm px-4 py-8 overflow-y-auto" onClick={() => setProcessingRequest(null)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md bg-[#0b0b0b] border border-white/10 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-white font-bold text-lg">Process Payment</h2>
              <button type="button" onClick={() => setProcessingRequest(null)} className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-black/30 border border-border rounded-lg p-4">
              <p className="text-white font-bold text-xl">₦{processingRequest.amountNgn.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
              <p className="text-white/40 text-xs mt-0.5">{processingRequest.userName} · {processingRequest.userEmail}</p>
            </div>

            {paymentError && <p className="text-red-400 text-sm">{paymentError}</p>}

            <div className="flex gap-3 pt-1">
              <button type="button" onClick={() => setProcessingRequest(null)} className="flex-1 py-2.5 rounded-lg border border-border text-white/60 text-sm font-medium hover:border-white/20 transition-colors">
                Cancel
              </button>
              <Button onClick={submitMarkPaid} className="flex-1 bg-primary text-black hover:bg-primary/90 font-bold">
                Mark as Paid
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
