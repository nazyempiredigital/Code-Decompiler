import { Link } from "wouter";
import { Globe, Shield, Zap, Users, Music, Server, ArrowRight, CheckCircle } from "lucide-react";

export default function About() {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative bg-zinc-950 py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="container mx-auto px-4 max-w-5xl text-center">
          <p className="text-primary text-xs font-semibold tracking-[0.3em] uppercase mb-4">Our Story</p>
          <h1 className="font-display text-5xl md:text-7xl text-white mb-6 leading-none">
            ABOUT <span className="text-primary">NAZY EMPIRE</span>
          </h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto leading-relaxed">
            Africa's premier technology and entertainment company, headquartered in Enugu, Nigeria.
            We build digital infrastructure that empowers African businesses to compete on the world stage.
          </p>
        </div>
      </section>

      {/* Identity & Registration */}
      <section className="py-16 bg-black border-y border-white/10">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { label: "Legal Name", value: "NAZY EMPIRE DIGITAL" },
              { label: "CAC Registration", value: "BN 9657494" },
              { label: "Registration Type", value: "Business Name (BN), Nigeria" },
              { label: "Jurisdiction", value: "Enugu State, Federal Republic of Nigeria" },
              { label: "Year Established", value: "2026" },
              { label: "Contact", value: "info@nazyempire.com" },
            ].map((item) => (
              <div key={item.label} className="bg-white/3 border border-white/10 rounded-xl p-5">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-1">{item.label}</p>
                <p className="text-white font-semibold text-sm">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-24 bg-zinc-950">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-primary text-xs font-semibold tracking-[0.3em] uppercase mb-4">What Drives Us</p>
              <h2 className="font-display text-4xl text-white mb-6 leading-tight">OUR MISSION & VISION</h2>
              <p className="text-white/50 leading-relaxed mb-5">
                Our mission is to democratise access to world-class digital technology for African businesses and creators.
                We believe every entrepreneur, brand, and artist on the continent deserves the same digital infrastructure
                that Fortune 500 companies enjoy — without the Fortune 500 price tag.
              </p>
              <p className="text-white/50 leading-relaxed">
                Our vision is a fully connected Africa where local businesses dominate their markets online, where African
                artists distribute their music globally, and where the continent's digital economy is built on trusted,
                home-grown platforms.
              </p>
            </div>
            <div className="space-y-4">
              {[
                { icon: Zap, title: "Speed First", body: "We deliver fast, reliable, production-ready digital products without the agency bloat." },
                { icon: Shield, title: "Trust & Transparency", body: "No hidden fees, no vague timelines. Every engagement is governed by a clear, binding agreement." },
                { icon: Users, title: "Client Ownership", body: "You own every deliverable outright upon full payment. No lock-in, no ransom code." },
                { icon: Globe, title: "Global Standards, African Roots", body: "International quality benchmarks applied to the unique context of African markets and regulations." },
              ].map(({ icon: Icon, title, body }) => (
                <div key={title} className="flex gap-4 bg-white/3 border border-white/10 rounded-xl p-5">
                  <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm mb-1">{title}</p>
                    <p className="text-white/45 text-sm leading-relaxed">{body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-14">
            <p className="text-primary text-xs font-semibold tracking-[0.3em] uppercase mb-4">What We Do</p>
            <h2 className="font-display text-4xl text-white">OUR SERVICES</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                icon: Globe,
                title: "Website & App Development",
                href: "/web-development",
                body: "Custom websites and mobile applications — from corporate portals and e-commerce stores to SaaS platforms and restaurant systems — built to international standards and optimised for Nigerian connectivity.",
                items: ["Business websites & landing pages", "E-commerce stores with Paystack", "Mobile apps (iOS & Android)", "Custom web applications & portals"],
              },
              {
                icon: Shield,
                title: "Domain Registration",
                href: "/domains",
                body: "Register and manage your domain name through our ICANN-adjacent registration service. We offer .com, .ng, .africa, and 300+ other extensions with full DNS management.",
                items: [".com, .ng, .africa & 300+ TLDs", "Full DNS management", "Domain privacy protection", "Auto-renewal management"],
              },
              {
                icon: Server,
                title: "Web Hosting",
                href: "/hosting",
                body: "Enterprise-grade hosting with 99.9% uptime SLA, SSL certificates, daily backups, and cPanel access. Shared, VPS, and dedicated options available.",
                items: ["99.9% uptime SLA", "Free SSL certificate", "Daily automated backups", "cPanel control panel"],
              },
              {
                icon: Music,
                title: "Music Distribution",
                href: "/music-distribution",
                body: "Distribute your music to Spotify, Apple Music, YouTube Music, Boomplay, and 150+ global platforms. Keep 100% of your royalties.",
                items: ["150+ global streaming platforms", "100% royalty retention", "ISRC & UPC generation", "Real-time royalty analytics"],
              },
            ].map(({ icon: Icon, title, href, body, items }) => (
              <div key={title} className="bg-zinc-950 border border-white/10 rounded-2xl p-7 flex flex-col">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-5">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-white font-bold text-lg mb-3">{title}</h3>
                <p className="text-white/45 text-sm leading-relaxed mb-5 flex-1">{body}</p>
                <ul className="space-y-2 mb-6">
                  {items.map((item) => (
                    <li key={item} className="flex items-center gap-2 text-white/50 text-sm">
                      <CheckCircle className="w-3.5 h-3.5 text-primary shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link href={href} className="inline-flex items-center gap-1.5 text-primary text-sm font-semibold hover:gap-2.5 transition-all">
                  Learn more <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-zinc-950">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-14">
            <p className="text-primary text-xs font-semibold tracking-[0.3em] uppercase mb-4">How We Work</p>
            <h2 className="font-display text-4xl text-white">OUR COMMITMENTS</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "No Hidden Charges", body: "The price quoted in your order confirmation is the price you pay. VAT (where applicable) is stated upfront. No surprise invoices." },
              { title: "Your Data, Your Rights", body: "We process personal data under Nigeria's NDPR framework and respect internationally recognised data rights. We will never sell your information." },
              { title: "Intellectual Property", body: "Every line of code, every design asset, every deliverable becomes your property upon receipt of full payment. No licensing traps." },
              { title: "Clear Timelines", body: "Every project has a written timeline. If we miss a milestone due to our fault, we communicate immediately and make it right." },
              { title: "Secure Payments", body: "All transactions are processed by Paystack, a PCI-DSS Level 1 certified payment gateway. We never store card data." },
              { title: "Dispute Resolution", body: "If you are unhappy, contact us first. We resolve the vast majority of disputes amicably within 5 business days, without lawyers." },
            ].map(({ title, body }) => (
              <div key={title} className="bg-black border border-white/10 rounded-xl p-6">
                <p className="text-primary font-bold text-sm mb-2">{title}</p>
                <p className="text-white/45 text-sm leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4 max-w-2xl text-center">
          <h2 className="font-display text-4xl text-white mb-5">READY TO BUILD YOUR EMPIRE?</h2>
          <p className="text-white/50 mb-8">Tell us about your project and get a free, no-obligation quote within 24 hours.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/order" className="px-8 py-4 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-colors">
              Start a Project
            </Link>
            <Link href="/contact" className="px-8 py-4 bg-white/5 border border-white/20 text-white rounded-xl hover:bg-white/10 transition-colors">
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
