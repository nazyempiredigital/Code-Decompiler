import { LegalPage } from "@/components/legal-page";
import { Link } from "wouter";

export default function TermsOfSale() {
  return (
    <LegalPage
      title="TERMS OF SALE"
      subtitle="These Terms of Sale govern all transactions — purchases, subscriptions, and orders — made through the NAZY EMPIRE DIGITAL website. They supplement our Terms & Conditions and together form the complete commercial agreement between you and us."
      effectiveDate="10 July 2026"
      lastReviewed="10 July 2026"
      sections={[
        {
          heading: "1. Seller Identity",
          content: (
            <>
              <p><strong>NAZY EMPIRE DIGITAL</strong><br />
              CAC Business Name Registration No. BN 9657494<br />
              Enugu State, Federal Republic of Nigeria<br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
              <p>All sales are final subject to the refund provisions set out in Clause 6 below.</p>
            </>
          ),
        },
        {
          heading: "2. Placing an Order",
          content: (
            <>
              <p>Orders may be placed through the website's order form. By submitting an order, you:</p>
              <ul>
                <li>Confirm that you are at least 18 years of age;</li>
                <li>Confirm that all information provided is accurate and complete;</li>
                <li>Acknowledge that you have read and agree to these Terms of Sale and the general <Link href="/terms">Terms & Conditions</Link>.</li>
              </ul>
              <p>An order constitutes an offer to purchase. No binding contract is formed until you receive a written Order Confirmation from NAZY EMPIRE DIGITAL. We reserve the right to reject any order at our sole discretion, in which case any payment received will be refunded in full.</p>
            </>
          ),
        },
        {
          heading: "3. Pricing",
          content: (
            <>
              <p>All prices are in <strong>Nigerian Naira (NGN)</strong> and are inclusive of any service charges stated on the order form. Where Value Added Tax (VAT) applies under Nigerian law, it will be separately identified on the invoice.</p>
              <p>Prices published on the website are indicative. The binding price for your specific order is stated in the Order Confirmation or quotation agreed in writing. The Company reserves the right to correct obvious pricing errors at any time before an Order Confirmation is issued; you will be notified and given the option to proceed at the correct price or cancel for a full refund.</p>
            </>
          ),
        },
        {
          heading: "4. Payment Methods and Processing",
          content: (
            <>
              <p>Accepted payment methods are those made available through <strong>Paystack</strong> at the time of checkout, including debit/credit cards, bank transfers, and USSD. Paystack is PCI-DSS Level 1 certified.</p>
              <p>We do not store, process, or have access to your payment card details at any time. All card data is transmitted directly to Paystack's secure servers.</p>
              <p>Your payment is charged at the time of order. If your payment fails or is reversed, your order will be placed on hold and no services will be initiated until payment clears. The Company is not responsible for declined transactions due to your bank's fraud controls or insufficient funds.</p>
            </>
          ),
        },
        {
          heading: "5. Service-Specific Payment Terms",
          content: (
            <>
              <h3>5.1 Website & App Development</h3>
              <ul>
                <li>Projects up to ₦499,999: Full payment required before commencement.</li>
                <li>Projects ₦500,000 and above: 50% non-refundable deposit before commencement; balance due upon delivery of final deliverable and before handover of files/credentials.</li>
                <li>Change requests beyond agreed scope will be quoted and invoiced separately before implementation.</li>
              </ul>
              <h3>5.2 Domain Registration</h3>
              <ul>
                <li>Full payment required for the selected registration period (1–10 years).</li>
                <li>Renewal fees will be communicated at least 30 days before expiry. Failure to renew before the expiry date may result in domain release; the Company is not liable for loss of a domain due to Client failure to pay renewal fees.</li>
                <li>Domain registration fees are passed directly to the domain registry and are non-refundable once registration is processed.</li>
              </ul>
              <h3>5.3 Web Hosting</h3>
              <ul>
                <li>Hosting subscriptions are billed monthly or annually in advance.</li>
                <li>Annual plans receive any applicable discount, which is forfeited on cancellation.</li>
                <li>Services are suspended if a renewal invoice remains unpaid for more than 7 days after the due date; terminated after 30 days.</li>
              </ul>
              <h3>5.4 Music Distribution</h3>
              <ul>
                <li>Music distribution is provided at <strong>no upfront or subscription fee</strong> to the Artist.</li>
                <li>The Company earns a <strong>15% commission</strong> on all net royalties generated from distributed releases. The Artist receives the remaining <strong>85%</strong>. There are no other fees or deductions beyond mandatory third-party withholdings.</li>
                <li>Royalties are collected by the Company from DSPs on a monthly or quarterly cycle. DSPs typically remit with a 2–3 month lag from the stream or sale date. Royalty balances are updated in the Artist's dashboard as payments are received.</li>
                <li><strong>Minimum payout threshold:</strong> ₦10,000 (ten thousand Naira). Balances below this amount carry forward without expiry. Withdrawal requests are processed within 7–14 business days.</li>
                <li>Platform go-live timing is subject to each DSP's individual review and content processing schedule, which is outside the Company's control. Submission is not a guarantee of acceptance on any specific platform.</li>
                <li>The full terms governing the distribution relationship — including the grant of rights, territory, takedown policy, and anti-fraud obligations — are set out in Clauses 10 and 11 of the <Link href="/terms">Terms &amp; Conditions</Link>, which form part of this agreement.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "6. Refund and Cancellation Policy",
          content: (
            <>
              <p>Our refund policy is designed to be fair while recognising that we commit time and resources immediately upon receipt of payment.</p>
              <h3>6.1 Development Projects</h3>
              <ul>
                <li><strong>Within 24 hours of payment, before work begins:</strong> Full refund, minus any Paystack transaction fees (typically 1.5% + ₦100).</li>
                <li><strong>After work has commenced:</strong> No refund. If the Client wishes to cancel, they forfeit any deposit and any payments made for work completed to date. The Company may invoice for additional work done if the Client cancels after only a deposit was taken.</li>
                <li><strong>Unsatisfactory delivery:</strong> Where the Company fails to deliver a material feature expressly included in the Order Confirmation, the Client must notify us in writing within 14 days of delivery. We will rectify the issue at no additional charge. If we are unable to do so within a reasonable time, a partial refund proportionate to the undelivered work may be issued.</li>
              </ul>
              <h3>6.2 Domain Registration</h3>
              <p>No refunds after registration is submitted to the registry. Domains may be transferred to another registrar at any time; transfer fees may apply.</p>
              <h3>6.3 Web Hosting</h3>
              <ul>
                <li><strong>First 7 days (new customers only):</strong> Full refund if requested in writing and no significant bandwidth or storage has been consumed.</li>
                <li><strong>After 7 days:</strong> Pro-rata refund for remaining complete months, minus a ₦5,000 administration fee, at the Company's sole discretion. No refund for the first month or for annual plans after the first 7 days.</li>
              </ul>
              <h3>6.4 Music Distribution</h3>
              <p>Music distribution carries no upfront fee; therefore no monetary refund applies to the distribution service itself. The Company earns solely through its 15% royalty share.</p>
              <p><strong>Takedown / Release removal:</strong> An Artist may request removal of a release from all distribution platforms at any time by submitting a written takedown request to <a href="mailto:info@nazyempire.com">info@nazyempire.com</a> with the subject line <strong>"TAKEDOWN REQUEST – [Artist Name] – [Release Title]"</strong>. The Company will acknowledge the request within 3 business days and submit removal orders to all DSPs within 7 business days thereafter. Full removal from all platforms typically takes <strong>14 days or more</strong> from acknowledgement, as each DSP operates on its own schedule. Royalties accrued up to the effective removal date remain payable to the Artist.</p>
              <p><strong>Anti-fraud and forfeiture:</strong> Where an Artist's account is found to be in breach of the Anti-Fraud and Artificial Streaming Policy (Clause 11 of the Terms &amp; Conditions), the Company reserves the right to freeze and permanently forfeit the Artist's entire outstanding royalty balance. No refund or compensation will be payable in such cases. See Clause 11 of the <Link href="/terms">Terms &amp; Conditions</Link> for the full policy.</p>
              <h3>6.5 Refund Process</h3>
              <p>All refund requests must be submitted in writing to <a href="mailto:info@nazyempire.com">info@nazyempire.com</a> with the subject line "REFUND REQUEST – [Order Number]". We will acknowledge your request within 2 business days and issue a decision within 7 business days. Approved refunds are processed back to the original payment method within 5–10 business days, subject to Paystack's processing times.</p>
            </>
          ),
        },
        {
          heading: "7. Chargebacks and Disputes",
          content: (
            <>
              <p>We encourage Clients to contact us directly to resolve payment disputes before initiating a chargeback with their bank. Filing a fraudulent or unjustified chargeback is a breach of these Terms and may result in:</p>
              <ul>
                <li>Immediate suspension of all active services;</li>
                <li>Referral to debt-collection proceedings for any legitimate outstanding amounts;</li>
                <li>Reporting to relevant fraud-prevention agencies where warranted.</li>
              </ul>
              <p>Where a chargeback is initiated, the Company reserves the right to provide the payment processor and the Client's issuing bank with full evidence of the contracted services and delivery, including communications, delivery confirmations, and these Terms.</p>
            </>
          ),
        },
        {
          heading: "8. Delivery of Digital Services",
          content: (
            <>
              <p>All services are delivered digitally. "Delivery" is deemed to occur as follows:</p>
              <ul>
                <li><strong>Development projects:</strong> When the completed deliverable is published to the live environment or when login credentials/files are transmitted to the Client's email, whichever is earlier.</li>
                <li><strong>Domain registration:</strong> When the domain is active in the registry and DNS propagation has commenced (typically within 24–48 hours).</li>
                <li><strong>Hosting:</strong> When the hosting account credentials are emailed to the Client.</li>
                <li><strong>Music distribution:</strong> When the release data has been successfully submitted to distribution partners. Platform go-live times vary (typically 1–5 business days per platform). The 15%/85% royalty split applies from the first payment received from any platform.</li>
              </ul>
              <p>Risk of loss and title for digital deliverables pass to you upon delivery.</p>
            </>
          ),
        },
        {
          heading: "9. Taxes",
          content: (
            <p>Prices quoted are exclusive of VAT unless otherwise stated. Where applicable under the Value Added Tax Act (as amended) of Nigeria or any other applicable taxing statute, VAT will be added to the invoice. You are solely responsible for any other taxes, duties, or levies applicable in your jurisdiction. The Company is not responsible for any tax obligations you may have in your country of residence.</p>
          ),
        },
        {
          heading: "10. Governing Law",
          content: (
            <p>These Terms of Sale are governed by the laws of the Federal Republic of Nigeria. Any disputes shall be resolved as set out in the general <Link href="/terms">Terms & Conditions</Link>.</p>
          ),
        },
        {
          heading: "11. Contact",
          content: (
            <>
              <p>For order inquiries, invoicing, or payment issues:</p>
              <p><strong>NAZY EMPIRE DIGITAL</strong><br />
              CAC BN 9657494<br />
              Enugu, Nigeria<br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
            </>
          ),
        },
      ]}
    />
  );
}
