import { LegalPage } from "@/components/legal-page";

export default function Accessibility() {
  return (
    <LegalPage
      title="ACCESSIBILITY STATEMENT"
      subtitle="NAZY EMPIRE DIGITAL is committed to ensuring that our website is accessible to everyone, including persons with disabilities. We strive to meet recognised international accessibility standards and to continually improve the experience for all users."
      effectiveDate="10 July 2026"
      lastReviewed="10 July 2026"
      sections={[
        {
          heading: "1. Our Commitment",
          content: (
            <p>We believe in equal access to digital services for all users, regardless of ability. We are working to ensure that our website, <strong>nazyempire.com</strong>, conforms to the <strong>Web Content Accessibility Guidelines (WCAG) 2.1, Level AA</strong>, published by the World Wide Web Consortium (W3C). These guidelines explain how to make web content more accessible to people with a wide range of disabilities, including visual, auditory, cognitive, and motor impairments.</p>
          ),
        },
        {
          heading: "2. Current Conformance Status",
          content: (
            <>
              <p>We assess our website's accessibility on an ongoing basis. As of the effective date of this Statement, our website partially conforms to WCAG 2.1 Level AA. "Partially conforms" means that some content does not yet fully meet all of the success criteria.</p>
              <p>Known areas where we are actively working to improve conformance include:</p>
              <ul>
                <li>Ensuring all images have descriptive and meaningful alternative text.</li>
                <li>Improving the colour contrast ratio of certain secondary text elements to meet the 4.5:1 minimum standard.</li>
                <li>Enhancing keyboard navigation for interactive components including modal dialogs, sliders, and dropdowns.</li>
                <li>Ensuring all form inputs have programmatically associated labels visible to assistive technologies.</li>
                <li>Providing captions and transcripts for any future audio or video content.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "3. Technical Specifications",
          content: (
            <>
              <p>Accessibility of this website relies on the following technologies:</p>
              <ul>
                <li>HTML5</li>
                <li>CSS3 (including Tailwind CSS)</li>
                <li>JavaScript (React 19)</li>
                <li>WAI-ARIA (Web Accessibility Initiative – Accessible Rich Internet Applications)</li>
              </ul>
              <p>These technologies are relied upon for conformance with the accessibility standards applied.</p>
            </>
          ),
        },
        {
          heading: "4. Browser and Assistive Technology Compatibility",
          content: (
            <>
              <p>We aim to support the following environments:</p>
              <ul>
                <li><strong>Browsers:</strong> The two most recent stable versions of Chrome, Firefox, Safari, and Microsoft Edge.</li>
                <li><strong>Screen readers:</strong> NVDA (Windows), JAWS (Windows), VoiceOver (macOS/iOS), TalkBack (Android).</li>
                <li><strong>Operating systems:</strong> Windows 10+, macOS 12+, iOS 15+, Android 10+.</li>
              </ul>
              <p>Older or non-standard browsers and assistive technology combinations may not be fully supported.</p>
            </>
          ),
        },
        {
          heading: "5. Known Limitations",
          content: (
            <>
              <p>Despite our best efforts, some content on our website may not yet be fully accessible:</p>
              <ul>
                <li><strong>Portfolio image slider:</strong> Keyboard navigation for the auto-advancing image carousel is partially implemented. We are working to add full ARIA live-region announcements and improved keyboard controls. As a workaround, all portfolio projects are also listed in the admin dashboard.</li>
                <li><strong>Third-party payment widget:</strong> The Paystack payment checkout modal is controlled by Paystack and we cannot guarantee its full WCAG 2.1 AA compliance. Paystack publishes its own accessibility documentation.</li>
                <li><strong>PDF documents:</strong> Any downloadable PDFs (e.g., invoices) may not be fully accessible. We will endeavour to provide accessible HTML alternatives upon request.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "6. Feedback and Contact",
          content: (
            <>
              <p>We welcome your feedback on the accessibility of our website. If you experience any accessibility barriers or need information in a different format, please contact us:</p>
              <p><strong>NAZY EMPIRE DIGITAL</strong><br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a><br />
              Subject: <strong>Accessibility Feedback</strong><br />
              Enugu, Nigeria</p>
              <p>We will try to respond to accessibility feedback within <strong>5 business days</strong>. We are committed to providing the information you need in an accessible format where it is reasonably practicable to do so.</p>
            </>
          ),
        },
        {
          heading: "7. Formal Complaints",
          content: (
            <p>If you are not satisfied with our response to your accessibility feedback, you may contact the relevant national accessibility enforcement body in your country. In Nigeria, matters relating to digital inclusion may be directed to the <strong>Federal Ministry of Communications, Innovation and Digital Economy</strong> and the <strong>National Information Technology Development Agency (NITDA)</strong>.</p>
          ),
        },
        {
          heading: "8. Assessment Approach",
          content: (
            <>
              <p>NAZY EMPIRE DIGITAL assesses the accessibility of this website through the following approaches:</p>
              <ul>
                <li>Self-evaluation using automated accessibility testing tools.</li>
                <li>Manual testing with keyboard-only navigation.</li>
                <li>Testing with screen readers (VoiceOver and NVDA).</li>
                <li>User feedback and bug reports.</li>
              </ul>
              <p>We intend to commission an independent accessibility audit within the next 12 months and will update this Statement with the findings.</p>
            </>
          ),
        },
        {
          heading: "9. Updates to this Statement",
          content: (
            <p>This Accessibility Statement is reviewed and updated at least annually, and whenever significant changes are made to the website. The "Last reviewed" date at the top of this page indicates when the statement was last evaluated.</p>
          ),
        },
      ]}
    />
  );
}
