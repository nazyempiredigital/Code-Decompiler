import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Music, Globe, LogOut, CheckCircle, Clock, XCircle, ArrowRight, FileText, ShieldCheck, PenLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { AuthModal } from "@/components/auth-modal";
import { api, type ArtistApplication } from "@/lib/api";

const GENRES = [
  "Afrobeats", "Afropop", "Amapiano", "Highlife", "Afro-Soul", "Afro-Fusion",
  "Hip Hop", "R&B", "Gospel", "Reggae", "Dancehall", "Pop", "Jazz", "Classical", "Other",
];

export default function ApplyArtist() {
  const { user, logout, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [authModal, setAuthModal] = useState<"login" | "register" | null>(null);
  const [existing, setExisting] = useState<ArtistApplication | null | undefined>(undefined);
  const [form, setForm] = useState({ stageName: "", bio: "", genre: "", socialLinks: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [agreesToTerms, setAgreesToTerms] = useState(false);

  const BIO_MAX_CHARS = 1000;
  const BIO_MAX_WORDS = 250;

  function countWords(text: string) {
    return text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
  }

  const bioChars = form.bio.length;
  const bioWords = countWords(form.bio);
  const bioAtLimit = bioChars >= BIO_MAX_CHARS || bioWords >= BIO_MAX_WORDS;
  const bioNearLimit = bioChars >= BIO_MAX_CHARS * 0.85 || bioWords >= BIO_MAX_WORDS * 0.85;

  function handleBioChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    const value = e.target.value;
    if (value.length > BIO_MAX_CHARS) return;
    if (countWords(value) > BIO_MAX_WORDS) return;
    setForm((f) => ({ ...f, bio: value }));
  }

  useEffect(() => {
    if (user) {
      if (user.role === "verified_artist" || user.role === "admin") {
        setLocation("/artist-dashboard");
        return;
      }
      api.artistApplications.my().then(setExisting).catch(() => setExisting(null));
    }
  }, [user]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!agreesToTerms) {
      setError("Please agree to the Terms & Conditions and Privacy Policy.");
      return;
    }
    if (!form.stageName || !form.bio || !form.genre) {
      setError("Please fill all required fields.");
      return;
    }
    if (bioChars > BIO_MAX_CHARS || bioWords > BIO_MAX_WORDS) {
      setError(`Bio must be at most ${BIO_MAX_WORDS} words and ${BIO_MAX_CHARS} characters.`);
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      const app = await api.artistApplications.apply(form);
      setExisting(app);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Submission failed");
    } finally {
      setSubmitting(false);
    }
  }

  const canSubmit = agreesToTerms && !!form.stageName && !!form.bio && !!form.genre;

  // ─── Loading ────────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // ─── Not logged in ───────────────────────────────────────────────────────────
  if (!user) {
    return (
      <>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-sm w-full text-center">
            <Music className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="font-display text-4xl text-white mb-2">BECOME AN ARTIST</h1>
            <p className="text-white/50 mb-6">Login or create an account to apply as a verified artist.</p>
            <div className="flex flex-col gap-3">
              <Button onClick={() => setAuthModal("login")} className="bg-primary text-black hover:bg-primary/90 font-bold">Login</Button>
              <Button variant="outline" onClick={() => setAuthModal("register")} className="border-white/20 text-white">Create Account</Button>
            </div>
          </div>
        </div>
        {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSwitch={(m) => setAuthModal(m)} />}
      </>
    );
  }

  // ─── Main ────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-black">
      {/* Nav */}
      <div className="bg-black/90 backdrop-blur-md border-b border-white/10 px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Globe className="w-6 h-6 text-primary" />
          <span className="font-display text-xl tracking-wider text-white">NAZY <span className="text-primary">EMPIRE</span></span>
        </Link>
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="text-white/50 hover:text-white text-sm">Dashboard</Link>
          <Button variant="ghost" size="sm" onClick={logout} className="text-white/50 hover:text-white">
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-12">
        {/* Hero */}
        <div className="text-center mb-10">
          <Music className="w-14 h-14 text-primary mx-auto mb-4" />
          <h1 className="font-display text-5xl text-white mb-3">BECOME A VERIFIED ARTIST</h1>
          <p className="text-white/50">Submit your application to unlock the Artist Dashboard and start distributing your music for free.</p>
        </div>

        {/* Loading existing check */}
        {existing === undefined && (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        {/* Status views (pending / approved / rejected) */}
        {existing !== undefined && existing !== null && (
          <div className={`rounded-2xl border p-8 text-center ${
            existing.status === "approved" ? "border-green-500/30 bg-green-500/5" :
            existing.status === "rejected" ? "border-red-500/30 bg-red-500/5" :
            "border-primary/30 bg-primary/5"
          }`}>
            {existing.status === "pending" && (
              <>
                <Clock className="w-12 h-12 text-primary mx-auto mb-4" />
                <h2 className="text-white font-bold text-xl mb-2">Application Under Review</h2>
                <p className="text-white/50">Your application has been submitted and is being reviewed by our team. We'll notify you once a decision has been made.</p>
                <div className="mt-6 p-4 bg-card border border-border rounded-xl text-left">
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Stage Name</p>
                  <p className="text-white font-semibold">{existing.stageName}</p>
                  <p className="text-white/40 text-xs uppercase tracking-wider mt-3 mb-1">Genre</p>
                  <p className="text-white/70">{existing.genre}</p>
                </div>
              </>
            )}
            {existing.status === "approved" && (
              <>
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                <h2 className="text-white font-bold text-xl mb-2">Application Approved!</h2>
                <p className="text-white/50 mb-6">Congratulations! You are now a Verified Artist. Access your Artist Dashboard to start uploading music.</p>
                <Link href="/artist-dashboard">
                  <Button className="bg-primary text-black hover:bg-primary/90 font-bold">
                    Go to Artist Dashboard <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </>
            )}
            {existing.status === "rejected" && (
              <>
                <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h2 className="text-white font-bold text-xl mb-2">Application Not Approved</h2>
                <p className="text-white/50 mb-2">Unfortunately your application was not approved at this time.</p>
                {existing.adminNotes && (
                  <div className="mt-4 p-4 bg-card border border-border rounded-xl text-left">
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Feedback</p>
                    <p className="text-white/70 text-sm">{existing.adminNotes}</p>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Application form (only shown when no existing application) */}
        {existing === null && (
          <div className="space-y-6">

            {/* ── Application Form ─────────────────────────────────── */}
            <form onSubmit={submit} className="bg-card border border-border rounded-2xl overflow-hidden">
              {/* Header */}
              <div className="flex items-center gap-3 px-6 py-5 border-b border-white/8">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 bg-primary text-black">
                  1
                </div>
                <div>
                  <p className="font-semibold text-sm text-white">Your Application Details</p>
                  <p className="text-white/30 text-xs mt-0.5">Fill in your artist info below</p>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Fields */}
                <div className="space-y-2">
                  <label className="text-white/70 text-sm font-medium">Stage Name <span className="text-primary">*</span></label>
                  <input
                    className="w-full bg-input border border-border rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Your artist/stage name"
                    value={form.stageName}
                    onChange={(e) => setForm((f) => ({ ...f, stageName: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-white/70 text-sm font-medium">Primary Genre <span className="text-primary">*</span></label>
                  <select
                    className="w-full bg-input border border-border rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    value={form.genre}
                    onChange={(e) => setForm((f) => ({ ...f, genre: e.target.value }))}
                  >
                    <option value="">Select your genre</option>
                    {GENRES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-white/70 text-sm font-medium">Bio / About You <span className="text-primary">*</span></label>
                  <textarea
                    rows={5}
                    className={`w-full bg-input border rounded-lg px-4 py-3 text-white resize-none focus:outline-none focus:ring-2 focus:ring-primary ${bioAtLimit ? "border-red-500/60" : "border-border"}`}
                    placeholder="Tell us about yourself, your music, and your goals..."
                    value={form.bio}
                    onChange={handleBioChange}
                  />
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-white/30">Max 250 words · 1000 characters</span>
                    <span className={bioAtLimit ? "text-red-400 font-medium" : bioNearLimit ? "text-yellow-400" : "text-white/30"}>
                      {bioWords} / 250 words · {bioChars} / 1000 chars
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-white/70 text-sm font-medium">Social Media Links <span className="text-white/30">(optional)</span></label>
                  <input
                    className="w-full bg-input border border-border rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Instagram, Spotify, YouTube, etc."
                    value={form.socialLinks}
                    onChange={(e) => setForm((f) => ({ ...f, socialLinks: e.target.value }))}
                  />
                </div>

                {/* ── Terms & Policy Agreement ───────────────────────────── */}
                <div className="rounded-xl border border-white/10 p-4 space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <ShieldCheck className="w-4 h-4 text-primary" />
                    <span className="text-white/60 text-xs font-semibold uppercase tracking-wider">Legal Agreement</span>
                  </div>

                  <label className="flex items-start gap-3 cursor-pointer group">
                    <div className="relative mt-0.5 shrink-0">
                      <input
                        type="checkbox"
                        className="sr-only peer"
                        checked={agreesToTerms}
                        onChange={(e) => setAgreesToTerms(e.target.checked)}
                      />
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${agreesToTerms ? "bg-primary border-primary" : "border-white/30 group-hover:border-white/50"}`}>
                        {agreesToTerms && <CheckCircle className="w-3 h-3 text-black" />}
                      </div>
                    </div>
                    <span className="text-white/60 text-sm leading-relaxed group-hover:text-white/80 transition-colors">
                      I have read and agree to NAZY EMPIRE DIGITAL's{" "}
                      <Link href="/terms" target="_blank" className="text-primary underline underline-offset-2 hover:text-primary/80">
                        Terms &amp; Conditions
                      </Link>
                      {" "}(including the Digital Music Distribution Agreement, Anti-Fraud Policy, Indemnification Clause, and Limitation of Liability) and the{" "}
                      <Link href="/privacy" target="_blank" className="text-primary underline underline-offset-2 hover:text-primary/80">
                        Privacy Policy
                      </Link>
                      . I understand that these documents are legally binding.
                    </span>
                  </label>

                  {/* Quick summary of key obligations */}
                  <div className="mt-3 pt-3 border-t border-white/8 grid grid-cols-1 gap-2">
                    {[
                      { icon: FileText, text: "I own or have fully cleared all rights in any music I upload" },
                      { icon: ShieldCheck, text: "I will not use bots or artificial means to inflate stream counts" },
                      { icon: PenLine,   text: "I accept the 85/15 royalty split and payout terms" },
                    ].map(({ icon: Icon, text }) => (
                      <div key={text} className="flex items-center gap-2 text-white/35 text-xs">
                        <Icon className="w-3 h-3 shrink-0 text-primary/50" />
                        <span>{text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Error */}
                {error && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                    <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                {/* Submit */}
                <button
                  type="submit"
                  disabled={submitting || !canSubmit}
                  className={`w-full font-bold py-3.5 text-base rounded-lg transition-all duration-300 ${
                    canSubmit
                      ? "bg-primary text-black hover:brightness-110 shadow-[0_0_24px_rgba(234,179,8,0.35)] cursor-pointer"
                      : "bg-white/8 text-white/30 cursor-not-allowed"
                  }`}
                >
                  {submitting
                    ? "Submitting…"
                    : !agreesToTerms
                    ? "Agree to Terms to Continue"
                    : "Submit Application →"}
                </button>

                <p className="text-white/25 text-xs text-center">Applications are reviewed within 1–3 business days. You'll receive a notification with the decision.</p>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
