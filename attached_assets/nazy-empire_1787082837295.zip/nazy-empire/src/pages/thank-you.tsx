import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";

export default function ThankYou() {
  const [location] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const reference = params.get("reference") ?? params.get("trxref");
  const [status, setStatus] = useState<"verifying" | "success" | "error">("verifying");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!reference) {
      setStatus("success");
      return;
    }
    api.payments.verify(reference)
      .then((r) => {
        setStatus("success");
        setMessage(`Project ID: ${r.projectId}`);
      })
      .catch((err) => {
        setStatus("error");
        setMessage(err instanceof Error ? err.message : "Verification failed");
      });
  }, [reference]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg w-full text-center"
      >
        {status === "verifying" && (
          <>
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-6" />
            <h1 className="font-display text-4xl text-white mb-2">VERIFYING PAYMENT</h1>
            <p className="text-white/50">Please wait while we confirm your payment...</p>
          </>
        )}
        {status === "success" && (
          <>
            <CheckCircle className="w-20 h-20 text-primary mx-auto mb-6" />
            <h1 className="font-display text-5xl text-white mb-4">PAYMENT CONFIRMED!</h1>
            <p className="text-white/60 mb-2">
              Your payment has been confirmed and your project is now in progress.
            </p>
            {message && <p className="text-primary font-medium mb-6">{message}</p>}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Link href="/dashboard">
                <Button className="bg-primary text-black hover:bg-primary/90 font-bold">
                  View Dashboard <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Link href="/">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/5">
                  Back to Home
                </Button>
              </Link>
            </div>
          </>
        )}
        {status === "error" && (
          <>
            <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">⚠️</span>
            </div>
            <h1 className="font-display text-5xl text-white mb-4">VERIFICATION ISSUE</h1>
            <p className="text-white/60 mb-2">{message}</p>
            <p className="text-white/40 text-sm mb-8">
              If you completed payment, please check your dashboard. Your project may still have been created.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button className="bg-primary text-black hover:bg-primary/90 font-bold">
                  View Dashboard
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/5">
                  Contact Support
                </Button>
              </Link>
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
}
