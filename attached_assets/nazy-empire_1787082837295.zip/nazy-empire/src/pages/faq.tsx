import { useState, useRef } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Code, Globe, Server, Music, HelpCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FAQItem {
  q: string;
  a: string;
}

interface FAQSection {
  id: string;
  label: string;
  icon: React.ElementType;
  color: string;
  items: FAQItem[];
}

const FAQ_SECTIONS: FAQSection[] = [
  {
    id: "general",
    label: "General",
    icon: HelpCircle,
    color: "text-white",
    items: [
      {
        q: "What is Nazy Empire?",
        a: "Nazy Empire Digital is Africa's premier technology and entertainment company, headquartered in Enugu, Nigeria (CAC BN 9657494). We offer website & app development, domain registration, web hosting, and music distribution — everything a modern African business or artist needs to thrive online.",
      },
      {
        q: "How do I get started?",
        a: "Create a free account, then choose the service you need. For website projects, click 'Start a Project' to submit your brief. For domains and hosting, browse our plans and checkout directly. For music distribution, apply for a verified artist account and submit your first release.",
      },
      {
        q: "What payment methods do you accept?",
        a: "We accept all major debit and credit cards, as well as bank transfers, through Paystack — Nigeria's most trusted payment gateway. All transactions are processed in NGN and secured with 256-bit encryption.",
      },
      {
        q: "Do you offer refunds?",
        a: "Refund eligibility depends on the service. Domain registrations are non-refundable once the domain is registered with the registry. Hosting plans can be refunded within 7 days if no resources have been consumed. Website development deposits are non-refundable once work has begun. Please review our Terms of Sale for full details.",
      },
      {
        q: "How do I reach your support team?",
        a: "Open a support ticket from your dashboard at any time — this is the fastest way to get help. You can also email us at info@nazyempire.com or call +234 706 049 9236. Our team responds to tickets within a few hours on business days.",
      },
      {
        q: "Is my data safe with Nazy Empire?",
        a: "Yes. We are NDPR-compliant (Nigeria Data Protection Regulation) and follow industry best practices for data security. We never sell your personal data to third parties. See our Privacy Policy for full details.",
      },
    ],
  },
  {
    id: "web-development",
    label: "Website & App Development",
    icon: Code,
    color: "text-blue-400",
    items: [
      {
        q: "What types of websites and apps do you build?",
        a: "We build landing pages, business websites, portfolios, e-commerce stores, booking platforms, web applications, and mobile apps (iOS & Android). Whether you need a simple one-pager or a fully custom platform with user accounts and payments, we can build it.",
      },
      {
        q: "How long does it take to complete a project?",
        a: "Timelines depend on complexity. A standard business website typically takes 1–2 weeks. E-commerce stores take 2–4 weeks. Custom web apps and mobile apps are scoped individually and can range from 4 to 12 weeks. Your project manager will give you a precise timeline after the initial brief.",
      },
      {
        q: "Do I own the website after it's delivered?",
        a: "Yes — completely. Once the final payment is made, you own all the code, design assets, and content. We hand over full source files and transfer all accounts to you.",
      },
      {
        q: "What do you need from me to start?",
        a: "A completed project brief (submitted through our order form), your logo and brand assets if you have them, any reference websites you like, and a 50% deposit to kick off the project. We'll handle the rest.",
      },
      {
        q: "Do you offer website maintenance after launch?",
        a: "Yes. We offer ongoing maintenance plans that cover security updates, content changes, performance monitoring, and technical support. Ask about our monthly retainer options when you submit your project.",
      },
      {
        q: "Can you redesign my existing website?",
        a: "Absolutely. Redesigns are one of our most common projects. Share your current site URL and what you'd like to improve, and we'll scope the work and provide a quote.",
      },
      {
        q: "What technologies do you use?",
        a: "We use modern, production-proven stacks — React, Next.js, Node.js, TypeScript, and PostgreSQL for web apps; React Native and Expo for mobile. For simpler sites we also use WordPress where it's the right fit. We recommend the best tool for your specific needs, not just what's trending.",
      },
    ],
  },
  {
    id: "domains",
    label: "Domain Registration",
    icon: Globe,
    color: "text-green-400",
    items: [
      {
        q: "What domain extensions (TLDs) do you support?",
        a: "We support all major international TLDs including .com, .org, .net, .io, and .co, as well as African TLDs such as .ng, .com.ng, .org.ng, .gov.ng, and .edu.ng. We also support many country-code and new generic TLDs. Use our domain search to check availability.",
      },
      {
        q: "How long does domain registration take?",
        a: "Most domain registrations are instant or complete within a few minutes. Nigerian .ng domains may take up to 24 hours to propagate. Once registered, your domain is live and yours.",
      },
      {
        q: "Can I transfer a domain I already own?",
        a: "Yes. You can transfer domains from any other registrar to Nazy Empire. You'll need your domain's EPP/auth code from your current registrar. Transfers maintain your existing expiry date and usually complete within 5–7 days.",
      },
      {
        q: "What happens if I let my domain expire?",
        a: "We send reminder emails before expiry. After expiry, most domains enter a grace period (usually 30 days) during which you can still renew at the standard price. After the grace period, the domain may enter redemption (higher fee to recover) and then become available to the public. Renew on time to avoid losing your domain.",
      },
      {
        q: "Do you offer WHOIS privacy protection?",
        a: "Yes. WHOIS privacy hides your personal contact details from the public WHOIS database, protecting you from spam and unwanted solicitation. It is available for supported TLDs and can be added during registration or anytime from your dashboard.",
      },
      {
        q: "Can I point my domain to a website hosted elsewhere?",
        a: "Yes. You can update your domain's DNS records (A, CNAME, MX, TXT, etc.) from your dashboard to point to any hosting provider or service worldwide.",
      },
    ],
  },
  {
    id: "hosting",
    label: "Web Hosting",
    icon: Server,
    color: "text-orange-400",
    items: [
      {
        q: "What hosting plans do you offer?",
        a: "We offer shared hosting plans suited to personal sites and small businesses, as well as VPS and dedicated options for high-traffic or resource-intensive sites. All plans include SSD storage, free SSL, and 24/7 monitoring. View the full comparison on our Hosting page.",
      },
      {
        q: "What uptime do you guarantee?",
        a: "We guarantee 99.9% uptime on all hosting plans. Our infrastructure is built on redundant servers with automated failover, so your site stays online even if individual components fail.",
      },
      {
        q: "Do SSL certificates come included?",
        a: "Yes. Every hosting plan includes a free Let's Encrypt SSL certificate, automatically installed and renewed. Your site will serve over HTTPS with no extra cost or manual setup required.",
      },
      {
        q: "Can I host multiple websites on one plan?",
        a: "This depends on your plan tier. Our mid-range and higher plans support multiple domains and websites under one account. Check the plan details on the Hosting page or contact us if you're unsure which plan fits your needs.",
      },
      {
        q: "How do I migrate my existing website to Nazy Empire?",
        a: "We offer free website migration assistance for new hosting customers. Share your current host's credentials with our team and we'll handle the migration for you, including files, databases, and email accounts — with zero downtime.",
      },
      {
        q: "Do you offer email hosting?",
        a: "Yes. Business email hosting (e.g. you@yourcompany.com) is available on all plans. You can manage email accounts from your hosting dashboard and access mail via webmail or any email client (Outlook, Gmail, Apple Mail, etc.).",
      },
      {
        q: "What control panel do you use?",
        a: "We use cPanel — the industry-standard hosting control panel — giving you a familiar, intuitive interface to manage files, databases, emails, subdomains, and more.",
      },
    ],
  },
  {
    id: "music-distribution",
    label: "Music Distribution",
    icon: Music,
    color: "text-primary",
    items: [
      {
        q: "Which platforms do you distribute to?",
        a: "We distribute to 100+ platforms worldwide, including Spotify, Apple Music, Amazon Music, YouTube Music, Boomplay, Audiomack, Tidal, Deezer, Pandora, TikTok, Instagram/Facebook, and many more. Your music reaches every major market — global and African.",
      },
      {
        q: "How much does music distribution cost?",
        a: "Our distribution plans are designed to be accessible for independent African artists. Pricing is listed on the Music Distribution page. There are no hidden fees — the price you see covers distribution to all supported platforms.",
      },
      {
        q: "How long does it take for my music to go live?",
        a: "Once your release is submitted and approved, it typically takes 3–7 business days to appear on most platforms. Some platforms like Spotify and Apple Music may take up to 2 weeks. We recommend submitting at least 2 weeks before your intended release date.",
      },
      {
        q: "What percentage of royalties do I keep?",
        a: "Artists keep 85% of all royalties earned. Nazy Empire retains a 15% platform fee to cover distribution costs, administration, and ongoing platform maintenance. There are no additional deductions.",
      },
      {
        q: "How and when do I get paid?",
        a: "Royalties are reported and credited to your artist dashboard as they are received from each platform (typically monthly, with a lag of 2–3 months from the stream date). Once your balance reaches the minimum withdrawal threshold of ₦10,000, you can submit a withdrawal request and we'll process payment to your nominated bank account or PayPal.",
      },
      {
        q: "Do I need to be a verified artist to distribute music?",
        a: "Yes. You must apply for a verified artist account and be approved by our team before submitting releases. The application requires your stage name, a short bio, genre, and at least one social media profile. Approval typically takes 1–3 business days.",
      },
      {
        q: "What audio and artwork requirements are there?",
        a: "Audio must be submitted as a WAV or FLAC file at 16-bit / 44.1kHz (CD quality) minimum. Cover artwork must be a square JPEG or PNG at least 3000×3000px, free of explicit text unless the release is marked explicit, and must not infringe any third-party copyrights.",
      },
      {
        q: "Can I set a specific release date?",
        a: "Yes. When submitting your release, you can specify a future release date. We recommend choosing a date at least 2 weeks out to ensure all platforms have time to process your release before it goes live.",
      },
      {
        q: "Can I take down or update a release after it's live?",
        a: "Yes. You can request a takedown from your artist dashboard at any time, though it may take up to 7 days to be removed from all platforms. Metadata updates (title corrections, credits, etc.) are also possible — contact support with the change request.",
      },
      {
        q: "Do I retain ownership of my music?",
        a: "Absolutely. You retain 100% ownership and copyright of your music at all times. Nazy Empire acts only as your distributor — we never claim ownership of your creative work.",
      },
    ],
  },
];

function AccordionItem({ item, isOpen, onToggle }: { item: FAQItem; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-white/10 last:border-0">
      <button
        onClick={onToggle}
        className="w-full flex items-start justify-between gap-4 py-5 text-left group"
      >
        <span className={`text-sm md:text-base font-medium transition-colors ${isOpen ? "text-primary" : "text-white group-hover:text-white/80"}`}>
          {item.q}
        </span>
        <ChevronDown
          className={`w-4 h-4 shrink-0 mt-0.5 text-white/40 transition-transform duration-300 ${isOpen ? "rotate-180 text-primary" : ""}`}
        />
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            key="answer"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <p className="text-white/50 text-sm leading-relaxed pb-5">{item.a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({});
  const [activeSection, setActiveSection] = useState("general");
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});

  function toggleItem(key: string) {
    setOpenItems((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  function scrollToSection(id: string) {
    setActiveSection(id);
    sectionRefs.current[id]?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative bg-zinc-950 py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
        <div className="container mx-auto px-4 max-w-4xl text-center relative">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <p className="text-primary text-xs font-semibold tracking-[0.3em] uppercase mb-4">Help Center</p>
            <h1 className="font-display text-5xl md:text-7xl text-white mb-6 leading-none">
              FREQUENTLY ASKED <span className="text-primary">QUESTIONS</span>
            </h1>
            <p className="text-white/50 text-lg max-w-2xl mx-auto leading-relaxed">
              Everything you need to know about our services. Can't find an answer?{" "}
              <Link href="/contact" className="text-primary hover:underline">Contact us</Link> and we'll get back to you within a few hours.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Sticky section tabs */}
      <div className="sticky top-16 z-40 bg-black/95 backdrop-blur-md border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto py-3 scrollbar-hide">
            {FAQ_SECTIONS.map((section) => {
              const Icon = section.icon;
              const isActive = activeSection === section.id;
              return (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all shrink-0 ${
                    isActive
                      ? "bg-primary text-black"
                      : "text-white/50 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {section.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* FAQ body */}
      <div className="bg-black">
        <div className="container mx-auto px-4 max-w-3xl py-16 space-y-20">
          {FAQ_SECTIONS.map((section, si) => {
            const Icon = section.icon;
            return (
              <section
                key={section.id}
                ref={(el) => { sectionRefs.current[section.id] = el; }}
                id={section.id}
              >
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: si * 0.05 }}
                >
                  {/* Section header */}
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                      <Icon className={`w-5 h-5 ${section.color}`} />
                    </div>
                    <div>
                      <h2 className="text-white font-bold text-xl">{section.label}</h2>
                      <p className="text-white/30 text-xs">{section.items.length} questions</p>
                    </div>
                  </div>

                  {/* Accordion */}
                  <div className="bg-white/3 border border-white/10 rounded-2xl px-6">
                    {section.items.map((item, i) => (
                      <AccordionItem
                        key={i}
                        item={item}
                        isOpen={!!openItems[`${section.id}-${i}`]}
                        onToggle={() => toggleItem(`${section.id}-${i}`)}
                      />
                    ))}
                  </div>
                </motion.div>
              </section>
            );
          })}
        </div>
      </div>

      {/* CTA */}
      <section className="bg-zinc-950 border-t border-white/10 py-20">
        <div className="container mx-auto px-4 max-w-2xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="font-display text-3xl md:text-4xl text-white mb-4">STILL HAVE QUESTIONS?</h2>
            <p className="text-white/50 mb-8">
              Our team is happy to help. Reach out and we'll get back to you within a few hours.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/contact">
                <Button className="bg-primary text-black hover:bg-primary/90 font-bold px-8">
                  Contact Us <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Link href="/signup">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8">
                  Create an Account
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
