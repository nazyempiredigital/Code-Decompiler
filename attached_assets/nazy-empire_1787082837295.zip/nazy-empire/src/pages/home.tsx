import { motion } from "framer-motion";
import { Link } from "wouter";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { PortfolioSlider } from "@/components/portfolio-slider";
import {
  Globe, Music, Server, Code, Shield, Zap, Star, ArrowRight, CheckCircle, BookOpen, Calendar, Tag,
} from "lucide-react";
import { api, type BlogPost } from "@/lib/api";

const SERVICES = [
  {
    icon: Code,
    title: "Website & App Development",
    description:
      "Custom websites and mobile/web apps built to exceed your expectations. From landing pages to full e-commerce platforms.",
    href: "/web-development",
  },
  {
    icon: Globe,
    title: "Domain Registration",
    description:
      "Secure your brand's online identity with premium domain names at competitive prices across all major TLDs.",
    href: "/domains",
  },
  {
    icon: Server,
    title: "Web Hosting",
    description:
      "Lightning-fast, reliable hosting with 99.9% uptime guarantee. Your site stays online so you can focus on growth.",
    href: "/hosting",
  },
  {
    icon: Music,
    title: "Music Distribution",
    description:
      "Get your music on Spotify, Apple Music, Boomplay, and 100+ platforms worldwide. Artists keep 85% of their royalties.",
    href: "/music-distribution",
  },
];

const STATS = [
  { label: "Projects Completed", value: "50+" },
  { label: "Happy Clients", value: "300+" },
  { label: "Countries Served", value: "15+" },
  { label: "Years of Excellence", value: "5+" },
];

const WHY_US = [
  { icon: Zap, title: "Lightning Fast Delivery", description: "We deliver projects on time, every time. Our streamlined process ensures efficiency without compromising quality." },
  { icon: Shield, title: "Secure & Reliable", description: "Enterprise-grade security on all projects. Your data and your clients' data are always protected." },
  { icon: Star, title: "Premium Quality", description: "We don't cut corners. Every pixel, every line of code is crafted to perfection." },
  { icon: CheckCircle, title: "Ongoing Support", description: "We're with you long after launch. Our team is available to help you grow your online presence." },
];

const TESTIMONIALS = [
  { name: "Chukwu Sonia", role: "CEO, DV Digital Hub", text: "Nazy Empire transformed our online presence completely. The website they built for us has doubled our leads!" },
  { name: "Chukwudi Eze", role: "Recording Artist", text: "My music is now on every major platform. The distribution process was smooth and I got my first royalties within 3 months." },
  { name: "Fatima Al-Hassan", role: "E-commerce Owner", text: "From domain to hosting to a full online store — they handled everything. Professional, fast, and affordable." },
];

function formatDate(d: string | null | undefined) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-NG", { year: "numeric", month: "long", day: "numeric" });
}

export default function Home() {
  const [latestPosts, setLatestPosts] = useState<BlogPost[]>([]);
  useEffect(() => {
    api.blog.list(2).then(setLatestPosts).catch(() => {});
    // Capture affiliate referral code from ?ref= query param
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) {
      localStorage.setItem("affiliateRef", ref);
    }
  }, []);

  return (
    <div className="overflow-hidden">
      <section className="relative min-h-screen flex items-center bg-gradient-to-b from-black via-zinc-950 to-zinc-900 pt-16">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent" />
        </div>
        <div className="container mx-auto px-4 py-20 relative">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-block px-4 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
                Africa's Technology & Entertainment Company
              </span>
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-6xl md:text-8xl lg:text-9xl tracking-wider mb-6"
            >
              BUILD YOUR <span className="text-gold-gradient">EMPIRE</span> ONLINE
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-10"
            >
              Premium website & app development, domain registration, hosting, and music distribution services.
              We bring African creativity to the world stage.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link href="/order">
                <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold text-base px-8">
                  Start Your Project <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/services">
                <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 text-base px-8">
                  View Services
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="bg-primary/5 border-y border-primary/10 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="font-display text-5xl text-primary">{stat.value}</div>
                <div className="text-white/50 text-sm mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-5xl md:text-6xl text-white mb-4">OUR SERVICES</h2>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">Everything you need to establish and grow your digital presence</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {SERVICES.map((service, i) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="group"
                >
                  <Link href={service.href}>
                    <div className="bg-card border border-border hover:border-primary/40 rounded-xl p-6 h-full transition-all duration-300 cursor-pointer hover:bg-card/80">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="text-white font-semibold text-lg mb-2">{service.title}</h3>
                      <p className="text-white/50 text-sm leading-relaxed">{service.description}</p>
                      <div className="mt-4 flex items-center text-primary text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                        Learn more <ArrowRight className="ml-1 w-4 h-4" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="font-display text-5xl md:text-6xl text-white mb-4">RECENT PROJECTS</h2>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">A glimpse of what we've built for our clients across Africa and beyond</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <PortfolioSlider limit={5} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.25 }}
            className="flex justify-center mt-10"
          >
            <Link href="/projects">
              <Button
                variant="outline"
                size="lg"
                className="border-primary/40 text-primary hover:bg-primary/10 hover:border-primary font-semibold px-8 gap-2"
              >
                Explore Our Full Portfolio <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-5xl md:text-6xl text-white mb-4">WHY CHOOSE US</h2>
            <p className="text-white/50 text-lg">We set the standard for digital excellence in Africa</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {WHY_US.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex gap-4 p-6 bg-card border border-border rounded-xl"
                >
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold mb-1">{item.title}</h3>
                    <p className="text-white/50 text-sm">{item.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-5xl md:text-6xl text-white mb-4">WHAT CLIENTS SAY</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-xl p-6"
              >
                <div className="flex mb-4">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 text-primary fill-primary" />)}
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div>
                  <div className="text-white font-medium text-sm">{t.name}</div>
                  <div className="text-white/40 text-xs">{t.role}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog preview */}
      {latestPosts.length > 0 && (
        <section className="py-24 bg-black border-t border-white/5">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12"
            >
              <div>
                <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium mb-3">
                  <BookOpen className="w-3.5 h-3.5" /> From Our Blog
                </span>
                <h2 className="font-display text-4xl md:text-5xl text-white">LATEST INSIGHTS</h2>
              </div>
              <Link href="/blog">
                <Button variant="outline" className="border-primary/30 text-primary hover:bg-primary/10 hover:border-primary gap-2 shrink-0">
                  See Full Blog <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {latestPosts.map((post, i) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link href={`/blog/${post.slug}`}>
                    <div className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/40 transition-colors cursor-pointer flex flex-col h-full">
                      {post.featuredImage ? (
                        <div className="h-52 overflow-hidden bg-zinc-900">
                          <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        </div>
                      ) : (
                        <div className="h-52 bg-gradient-to-br from-primary/10 to-zinc-900 flex items-center justify-center">
                          <BookOpen className="w-10 h-10 text-primary/20" />
                        </div>
                      )}
                      <div className="p-6 flex flex-col flex-1">
                        {post.category && (
                          <span className="inline-flex items-center gap-1 text-primary text-xs font-medium mb-2">
                            <Tag className="w-3 h-3" /> {post.category}
                          </span>
                        )}
                        <h3 className="font-semibold text-white text-lg mb-2 group-hover:text-primary transition-colors line-clamp-2">{post.title}</h3>
                        {post.excerpt && <p className="text-white/50 text-sm leading-relaxed mb-4 line-clamp-2 flex-1">{post.excerpt}</p>}
                        <div className="flex items-center justify-between text-white/30 text-xs mt-auto pt-4 border-t border-border">
                          <span>{post.author || "Nazy Empire"}</span>
                          {post.publishedAt && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{formatDate(post.publishedAt)}</span>}
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-24 bg-gradient-to-b from-black to-zinc-950">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-5xl md:text-7xl text-white mb-6">
              READY TO BUILD YOUR <span className="text-gold-gradient">EMPIRE?</span>
            </h2>
            <p className="text-white/50 text-lg mb-10 max-w-2xl mx-auto">
              Join hundreds of African businesses and creators who trust us with their digital journey.
            </p>
            <Link href="/order">
              <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold text-lg px-12 py-6">
                Start Your Project Today <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
