import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Server, Zap, Shield, Clock, ArrowRight, CheckCircle, Cpu } from "lucide-react";

const PLANS = [
  {
    name: "Starter",
    price: "₦1,391.25/mo",
    annual: "₦16,695.00/yr",
    features: ["8GB Webspace", "30GB Bandwidth", "10 Subdomains", "2 Addon Domains", "Free SSL", "Unlimited Emails", "Unlimited DB"],
    bestFor: "Blogs, landing pages & small business sites",
  },
  {
    name: "Business",
    price: "₦1,947.75/mo",
    annual: "₦23,373.00/yr",
    features: ["15GB Webspace", "45GB Bandwidth", "15 Subdomains", "3 Addon Domains", "Free SSL", "Unlimited Emails", "Unlimited DB"],
    popular: true,
    bestFor: "Growing businesses & professional websites",
  },
  {
    name: "Professional",
    price: "₦2,504.25/mo",
    annual: "₦30,051.00/yr",
    features: ["30GB Webspace", "60GB Bandwidth", "20 Subdomains", "5 Addon Domains", "Free SSL", "Unlimited Emails", "Unlimited DB"],
    bestFor: "High-traffic websites & content platforms",
  },
  {
    name: "Enterprise",
    price: "₦3,060.75/mo",
    annual: "₦36,729.00/yr",
    features: ["120GB Webspace", "150GB Bandwidth", "40 Subdomains", "10 Addon Domains", "Free SSL", "Unlimited Emails", "Unlimited DB"],
    bestFor: "Large enterprises & multi-site deployments",
  },
];

const VPS_PLANS = [
  {
    name: "Starter VPS",
    price: "₦20,833/mo",
    annual: "₦250,000/yr",
    features: ["2 vCPU Cores", "4 GB RAM", "80 GB SSD/NVMe Storage", "2 TB Monthly Transfer", "1 Dedicated IPv4"],
    bestFor: "High-traffic WordPress, small e-commerce & testing environments",
  },
  {
    name: "Pro Business VPS",
    price: "₦58,333/mo",
    annual: "₦700,000/yr",
    features: ["4 vCPU Cores", "12 GB RAM", "250 GB NVMe Storage", "5 TB Monthly Transfer", "2 Dedicated IPv4"],
    popular: true,
    bestFor: "Multi-vendor marketplaces, high-volume databases & corporate email",
  },
  {
    name: "Elite High-Performance VPS",
    price: "₦166,666/mo",
    annual: "₦2,000,000/yr",
    features: ["12 vCPU Cores", "32 GB RAM", "600 GB Enterprise NVMe", "Unmetered / 15 TB Transfer", "3 Dedicated IPv4"],
    bestFor: "Custom mobile app backends, intensive SaaS platforms & large financial portals",
  },
];

export default function Hosting() {
  return (
    <div className="pt-16">
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24 text-center">
        <div className="container mx-auto px-4">
          <Server className="w-16 h-16 text-primary mx-auto mb-6" />
          <h1 className="font-display text-6xl md:text-7xl text-white mb-4">WEB HOSTING</h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Lightning-fast, reliable hosting with 99.9% uptime. Your website stays online, always.
          </p>
        </div>
      </section>

      {/* Shared Hosting Plans */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-4xl text-white mb-2">SHARED HOSTING PLANS</h2>
            <p className="text-white/40 text-sm">Ideal for websites, blogs, and small to medium businesses</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {PLANS.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative bg-card border rounded-xl p-6 flex flex-col ${plan.popular ? "border-primary shadow-lg shadow-primary/10" : "border-border"}`}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-black text-xs font-bold px-4 py-1 rounded-full">
                    POPULAR
                  </span>
                )}
                <h3 className="text-white text-xl font-bold mb-1">{plan.name}</h3>
                <div className="font-display text-2xl text-primary leading-tight">{plan.price}</div>
                <div className="text-white/35 text-xs mb-1">{plan.annual}</div>
                <p className="text-white/30 text-xs italic mb-4">{plan.bestFor}</p>
                <ul className="space-y-2 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-white/70 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href="/order" className="block mt-6">
                  <Button className={`w-full ${plan.popular ? "bg-primary text-black hover:bg-primary/90" : "border-white/20 text-white hover:bg-white/5"}`} variant={plan.popular ? "default" : "outline"}>
                    Get Started
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* VPS Plans */}
      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-4">
              <Cpu className="w-4 h-4" /> Virtual Private Servers
            </div>
            <h2 className="font-display text-4xl text-white mb-2">VPS HOSTING PLANS</h2>
            <p className="text-white/40 text-sm max-w-xl mx-auto">
              Dedicated resources, root access, and enterprise-grade NVMe storage. Required for Business Apps, E-commerce, E-learning, and Custom Web Applications.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {VPS_PLANS.map((plan, i) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative bg-card border rounded-xl p-6 flex flex-col ${plan.popular ? "border-primary shadow-lg shadow-primary/10" : "border-border"}`}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-black text-xs font-bold px-4 py-1 rounded-full">
                    RECOMMENDED
                  </span>
                )}
                <div className="flex items-center gap-2 mb-3">
                  <Cpu className="w-4 h-4 text-primary" />
                  <h3 className="text-white text-lg font-bold">{plan.name}</h3>
                </div>
                <div className="font-display text-2xl text-primary leading-tight">{plan.price}</div>
                <div className="text-white/35 text-xs mb-1">{plan.annual}</div>
                <p className="text-white/30 text-xs italic mb-4">{plan.bestFor}</p>
                <ul className="space-y-2 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-white/70 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href="/order" className="block mt-6">
                  <Button className={`w-full ${plan.popular ? "bg-primary text-black hover:bg-primary/90" : "border-white/20 text-white hover:bg-white/5"}`} variant={plan.popular ? "default" : "outline"}>
                    Get Started
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { icon: Zap, title: "Lightning Fast", description: "NVMe SSD storage and optimized servers for blazing speeds." },
              { icon: Clock, title: "99.9% Uptime", description: "We guarantee your site stays online with our reliable infrastructure." },
              { icon: Shield, title: "Free SSL", description: "Every hosting plan includes a free SSL certificate for security." },
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="text-center p-6"
                >
                  <Icon className="w-10 h-10 text-primary mx-auto mb-4" />
                  <h3 className="text-white font-semibold text-lg mb-2">{f.title}</h3>
                  <p className="text-white/50 text-sm">{f.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary/5 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-5xl text-white mb-4">NEED HOSTING?</h2>
          <p className="text-white/50 mb-8">Add hosting to your website order or contact us for standalone hosting.</p>
          <Link href="/contact">
            <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold">
              Get Hosting <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
