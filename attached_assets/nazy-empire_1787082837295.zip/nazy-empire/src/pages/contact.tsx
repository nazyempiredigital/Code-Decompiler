import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Phone, MapPin, Send, CheckCircle } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setSubmitted(true);
  }

  return (
    <div className="pt-16">
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24 text-center">
        <div className="container mx-auto px-4">
          <Mail className="w-16 h-16 text-primary mx-auto mb-6" />
          <h1 className="font-display text-6xl md:text-7xl text-white mb-4">CONTACT US</h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Have a project in mind? We'd love to hear from you. Send us a message and we'll get back to you within 24 hours.
          </p>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 max-w-5xl mx-auto">
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-3xl text-white mb-6">GET IN TOUCH</h2>
                <p className="text-white/50 text-sm">We're available Monday–Friday, 9am–6pm WAT.</p>
              </div>
              {[
                { icon: Mail, label: "Email", value: "info@nazyempire.com" },
                { icon: Phone, label: "Phone", value: "+234 706 049 9236" },
                { icon: MapPin, label: "Location", value: "Enugu, Nigeria" },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="text-white/40 text-xs mb-0.5">{item.label}</div>
                      <div className="text-white text-sm">{item.value}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="lg:col-span-2">
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center h-full py-16 text-center"
                >
                  <CheckCircle className="w-16 h-16 text-primary mb-4" />
                  <h3 className="text-white text-2xl font-bold mb-2">Message Sent!</h3>
                  <p className="text-white/50">We'll get back to you within 24 hours.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4 bg-card border border-border rounded-xl p-8">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label>Your Name</Label>
                      <Input placeholder="John Doe" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
                    </div>
                    <div className="space-y-1">
                      <Label>Email Address</Label>
                      <Input type="email" placeholder="you@example.com" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label>Subject</Label>
                    <Input placeholder="How can we help?" value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} required />
                  </div>
                  <div className="space-y-1">
                    <Label>Message</Label>
                    <Textarea placeholder="Tell us about your project..." rows={6} value={form.message} onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} required />
                  </div>
                  <Button type="submit" disabled={loading} className="w-full bg-primary text-black hover:bg-primary/90 font-bold">
                    {loading ? "Sending..." : <>Send Message <Send className="ml-2 w-4 h-4" /></>}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
