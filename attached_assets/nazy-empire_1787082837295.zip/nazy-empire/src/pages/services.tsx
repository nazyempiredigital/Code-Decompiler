import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Code, Globe, Server, Music, ArrowRight } from "lucide-react";

const SERVICES = [
  { icon: Code, title: "Website & App Development", href: "/web-development", description: "Custom websites and mobile/web apps tailored to your needs. From simple landing pages to complex web and app platforms.", features: ["Landing Pages", "E-commerce Stores & Apps", "Business Websites & Apps", "Custom Web & Mobile Apps"] },
  { icon: Globe, title: "Domain Registration", href: "/domains", description: "Secure your brand's online identity with premium domain names.", features: [".com, .org, .net", "African TLDs (.ng, .com.ng)", "Domain transfers", "WHOIS privacy"] },
  { icon: Server, title: "Web Hosting", href: "/hosting", description: "Fast, reliable hosting with 99.9% uptime guarantee.", features: ["SSD Storage", "Free SSL Certificate", "Daily Backups", "24/7 Support"] },
  { icon: Music, title: "Music Distribution", href: "/music-distribution", description: "Get your music heard globally on all major platforms.", features: ["Spotify, Apple Music", "Boomplay & 100+ more", "Keep 85% royalties", "Analytics Dashboard"] },
];

export default function Services() {
  return (
    <div className="pt-16">
      <section className="bg-zinc-950 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-6xl md:text-7xl text-white mb-4">OUR SERVICES</h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">Comprehensive digital services to help you build and grow online</p>
        </div>
      </section>
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div
                  key={s.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-card border border-border rounded-xl p-8"
                >
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <h2 className="text-white text-2xl font-bold mb-3">{s.title}</h2>
                  <p className="text-white/50 mb-6">{s.description}</p>
                  <ul className="space-y-2 mb-6">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-white/70 text-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link href={s.href}>
                    <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-black">
                      Learn More <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      <section className="py-20 bg-zinc-950 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-5xl text-white mb-4">READY TO GET STARTED?</h2>
          <p className="text-white/50 mb-8">Place your order and we'll get to work right away.</p>
          <Link href="/order">
            <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold">
              Order Now <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
