import { LegalPage } from "@/components/legal-page";

export default function DMCA() {
  return (
    <LegalPage
      title="DMCA NOTICE & TAKEDOWN POLICY"
      subtitle="NAZY EMPIRE DIGITAL respects intellectual property rights and expects its users and clients to do the same. This policy explains how to submit a copyright takedown notice and how we handle such requests."
      effectiveDate="10 July 2026"
      lastReviewed="10 July 2026"
      sections={[
        {
          heading: "1. Our Commitment to Copyright Compliance",
          content: (
            <>
              <p>NAZY EMPIRE DIGITAL is committed to complying with the copyright laws of the Federal Republic of Nigeria (including the <strong>Copyright Act 2022</strong>) and, to the extent applicable to our international users, the United States <strong>Digital Millennium Copyright Act (DMCA), 17 U.S.C. § 512</strong> and equivalent legislation in other jurisdictions.</p>
              <p>We will respond to notices of alleged copyright infringement that comply with the requirements set out in this Policy. We reserve the right to remove content alleged to be infringing, to terminate the accounts of repeat infringers, and to cooperate with law enforcement authorities.</p>
            </>
          ),
        },
        {
          heading: "2. Designated Copyright Agent",
          content: (
            <>
              <p>To submit a copyright takedown notice, send it to our designated Copyright Agent:</p>
              <p><strong>Copyright Agent — NAZY EMPIRE DIGITAL</strong><br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a><br />
              Subject line: <strong>DMCA TAKEDOWN NOTICE</strong><br />
              Address: Enugu State, Nigeria</p>
              <p>We strongly encourage notices to be submitted by email for fastest processing. Only notices that comply with the requirements in Clause 3 will be acted upon.</p>
            </>
          ),
        },
        {
          heading: "3. Requirements for a Valid Takedown Notice",
          content: (
            <>
              <p>To be valid under both the Nigerian Copyright Act 2022 and the US DMCA (17 U.S.C. § 512(c)(3)), your written notice must include <strong>all</strong> of the following:</p>
              <ol>
                <li><strong>Identification of the copyrighted work:</strong> A clear description of the copyrighted work you claim has been infringed. If multiple works are covered by a single notice, a representative list is acceptable.</li>
                <li><strong>Identification of the infringing material:</strong> A clear description of the material you believe is infringing and its location on our website (provide the full URL or URLs where possible).</li>
                <li><strong>Your contact information:</strong> Your full legal name, mailing address, telephone number, and email address.</li>
                <li><strong>Good faith statement:</strong> A statement that you have a good faith belief that use of the material in the manner complained of is not authorised by the copyright owner, its agent, or the law.</li>
                <li><strong>Accuracy statement:</strong> A statement that the information in the notice is accurate and, under penalty of perjury, that you are the copyright owner or authorised to act on behalf of the copyright owner.</li>
                <li><strong>Signature:</strong> A physical or electronic signature of the copyright owner or a person authorised to act on their behalf.</li>
              </ol>
              <p><strong>Warning:</strong> Under 17 U.S.C. § 512(f), any person who knowingly materially misrepresents that material or activity is infringing may be subject to liability for damages, including costs and attorneys' fees. We will forward defective or bad-faith notices to our legal advisors and may take appropriate action against complainants who abuse this process.</p>
            </>
          ),
        },
        {
          heading: "4. How We Process Notices",
          content: (
            <>
              <p>Upon receipt of a valid and complete takedown notice, we will:</p>
              <ol>
                <li>Acknowledge receipt of the notice within <strong>3 business days</strong>.</li>
                <li>Promptly investigate the claim and, where the notice is valid, remove or disable access to the allegedly infringing material pending resolution.</li>
                <li>Notify the user or client responsible for the content that we have received a takedown notice (without disclosing the complainant's personal contact details beyond what is necessary).</li>
                <li>Inform the notifying party of our action.</li>
              </ol>
              <p>We aim to process valid notices within <strong>10 business days</strong>. Complex cases involving third-party hosting, large content volumes, or disputed ownership may take longer.</p>
            </>
          ),
        },
        {
          heading: "5. Counter-Notification Procedure",
          content: (
            <>
              <p>If you believe your content was removed or disabled by mistake or misidentification, you may submit a counter-notification. To be valid, your counter-notification must include:</p>
              <ol>
                <li>Your full legal name, address, telephone number, and email address.</li>
                <li>Identification of the material that has been removed and the URL or location where it previously appeared.</li>
                <li>A statement under penalty of perjury that you have a good faith belief that the material was removed or disabled as a result of mistake or misidentification.</li>
                <li>A statement that you consent to the jurisdiction of the Federal courts for your judicial district in the United States (if you are in the US) or the courts of Lagos State, Nigeria (for all other users), and that you will accept service of process from the person who submitted the original notice or their agent.</li>
                <li>Your physical or electronic signature.</li>
              </ol>
              <p>Send your counter-notification to the Copyright Agent address in Clause 2, with the subject line <strong>DMCA COUNTER-NOTIFICATION</strong>.</p>
              <p>We will forward a copy of your counter-notification to the original complainant. If the complainant does not notify us that they have filed a court action within 10–14 business days of receiving the counter-notification, we may restore the removed content at our sole discretion.</p>
            </>
          ),
        },
        {
          heading: "6. Repeat Infringer Policy",
          content: (
            <>
              <p>In accordance with the DMCA (17 U.S.C. § 512(i)) and the Nigerian Copyright Act 2022, NAZY EMPIRE DIGITAL maintains and enforces a strict repeat infringer policy. We will <strong>permanently close the account</strong> of any user determined to be a repeat infringer of intellectual property rights.</p>
              <p><strong>"Repeat infringer"</strong> means any user:</p>
              <ul>
                <li>Against whom we have received <strong>two or more valid and actionable takedown notices</strong> within any rolling 12-month period;</li>
                <li>Who has been found to have <strong>wilfully uploaded content they do not own</strong> — including unauthorised samples, sound-alikes, or recordings owned by third parties — on more than one occasion; or</li>
                <li>Who has submitted any content that a court, arbitrator, or DSP has determined constitutes copyright infringement.</li>
              </ul>
              <p><strong>Consequences of repeat infringement:</strong></p>
              <ul>
                <li>The user's account will be <strong>permanently and irrevocably closed</strong>, with no right of reinstatement;</li>
                <li><strong>All releases</strong> associated with the account will be removed from every distribution platform;</li>
                <li><strong>Any outstanding royalty balance</strong> in the user's account will be <strong>permanently forfeited</strong> and will not be disbursed. This forfeiture reflects the costs incurred by the Company in processing infringement claims, managing DSP relationships, and handling associated legal exposure;</li>
                <li>The Company reserves the right to report the user to the Nigerian Copyright Commission, relevant DSPs, and law enforcement authorities where warranted.</li>
              </ul>
              <p>Determinations of repeat infringer status are made by the Company at its sole discretion, after review of the evidence. A user who believes they have been incorrectly designated as a repeat infringer may submit a written appeal to <a href="mailto:info@nazyempire.com">info@nazyempire.com</a> within 14 days of notification.</p>
            </>
          ),
        },
        {
          heading: "7. Scope — Client-Uploaded and Hosted Content",
          content: (
            <>
              <p>NAZY EMPIRE DIGITAL provides services to clients who may upload, host, or distribute content through our platforms (e.g., websites we build and host, music we distribute). The Company does not proactively monitor all such client-generated content but will act expeditiously upon receiving a valid takedown notice.</p>
              <p>Clients are responsible under our <a href="/terms">Terms & Conditions</a> for ensuring that all content they upload, publish, or request us to distribute complies with all applicable intellectual property laws. We reserve the right to suspend or terminate services for clients who repeatedly cause copyright complaints, regardless of whether we receive a formal court order.</p>
            </>
          ),
        },
        {
          heading: "8. Music Distribution — Third-Party Copyright Claims and Artist Liability",
          content: (
            <>
              <p>NAZY EMPIRE DIGITAL acts solely as a <strong>distribution intermediary</strong>. We do not produce, curate, or take editorial responsibility for the recordings submitted by Artists. The Artist is <strong>solely and fully liable</strong> for all content submitted for distribution.</p>

              <h3>8.1 Third-Party Copyright Claims Against Distributed Music</h3>
              <p>If you are a <strong>rights holder</strong> (songwriter, composer, label, publisher, or other copyright owner) and you believe that a recording distributed through NAZY EMPIRE DIGITAL infringes your copyright, you may submit a formal claim as follows:</p>
              <ol>
                <li><strong>Email our Copyright Agent</strong> at <a href="mailto:info@nazyempire.com">info@nazyempire.com</a> with the subject line <strong>"MUSIC COPYRIGHT CLAIM"</strong>.</li>
                <li>Include in your email:
                  <ul>
                    <li>Your full legal name, contact email, and phone number;</li>
                    <li>The name of the work you own and evidence of your ownership (e.g., registration, publishing agreement, or original creation evidence);</li>
                    <li>The name of the infringing release, Artist name, and any streaming platform links where the infringing content appears;</li>
                    <li>A clear description of how the infringing content uses your work (e.g., interpolation, direct sample, full reproduction);</li>
                    <li>A good-faith statement that you believe the use is unauthorised;</li>
                    <li>A statement under penalty of perjury that the information you provide is accurate and that you are the rights holder or authorised to act on their behalf;</li>
                    <li>Your physical or electronic signature.</li>
                  </ul>
                </li>
                <li>We will <strong>acknowledge your claim within 3 business days</strong> and investigate promptly.</li>
                <li>Where the claim is valid and complete, we will take emergency action to <strong>remove or suspend the infringing release</strong> from all DSPs as soon as practicable (typically within 7–10 business days), pending resolution.</li>
                <li>We will notify the Artist that a claim has been received (without disclosing your personal contact details) and provide them with an opportunity to respond or submit a counter-notice.</li>
                <li>We will keep you informed of the outcome of our investigation.</li>
              </ol>
              <p>For claims involving content hosted on DSPs directly (rather than through our platform), you should also submit a separate takedown notice directly to each DSP, as they operate their own independent content moderation processes.</p>

              <h3>8.2 Artist Representations and Indemnity</h3>
              <p>By submitting a music release through our distribution service, the Artist represents, warrants, and agrees that:</p>
              <ul>
                <li>They own or control all rights in and to the recording, including the master recording and any underlying musical composition;</li>
                <li>They have obtained all necessary licences, clearances, and consents from co-writers, publishers, sample rights holders, session musicians, and any other rights holders whose work appears in the recording;</li>
                <li>The content does not violate any applicable law, including but not limited to copyright law, defamation law, obscenity law, or the Nigerian Copyright Act 2022;</li>
                <li>Distribution of the recording will not infringe the intellectual property, privacy, or any other rights of any third party;</li>
                <li>They accept full legal and financial responsibility for any claim, demand, fine, or proceeding arising from the content of the submitted recording.</li>
              </ul>
              <p>A valid third-party claim may result in <strong>immediate removal of the release from all platforms without prior notice</strong> to the Artist. The Artist agrees to <strong>fully indemnify and hold harmless</strong> NAZY EMPIRE DIGITAL, its officers, employees, and agents from and against any losses, damages, costs, and expenses (including reasonable legal fees) arising from any infringing or unlawful content they submit for distribution.</p>

              <h3>8.3 Repeat Copyright Infringement by Artists</h3>
              <p>Any Artist who uploads unauthorised samples, misappropriated recordings, or content to which they do not hold the necessary rights — on more than one occasion — will be treated as a <strong>repeat infringer</strong> under Clause 6 of this Policy. Consequences include <strong>permanent account closure and forfeiture of any outstanding royalty balance</strong>. See Clause 6 for the full repeat infringer policy.</p>
            </>
          ),
        },
        {
          heading: "9. Nigerian Copyright Law",
          content: (
            <p>In addition to DMCA compliance, all content hosted or distributed through NAZY EMPIRE DIGITAL's services is subject to the <strong>Copyright Act 2022</strong> of the Federal Republic of Nigeria. Copyright in a work subsists from the moment of creation and registration is not required under Nigerian law. The Nigerian Copyright Commission (NCC) is the regulatory body for copyright matters in Nigeria: <a href="https://copyright.gov.ng" target="_blank" rel="noopener noreferrer">copyright.gov.ng</a>.</p>
          ),
        },
        {
          heading: "10. No Legal Advice",
          content: (
            <p>Nothing in this Policy constitutes legal advice. If you are uncertain about your copyright rights or obligations, you should seek independent legal advice. NAZY EMPIRE DIGITAL cannot advise you on the merits of any particular copyright claim.</p>
          ),
        },
        {
          heading: "11. Contact",
          content: (
            <>
              <p>For all copyright-related notices and inquiries:</p>
              <p><strong>Copyright Agent — NAZY EMPIRE DIGITAL</strong><br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a><br />
              Subject: DMCA TAKEDOWN NOTICE or DMCA COUNTER-NOTIFICATION<br />
              Enugu, Nigeria</p>
            </>
          ),
        },
      ]}
    />
  );
}
