import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Code, Monitor, ShoppingCart, Briefcase, ArrowRight, CheckCircle } from "lucide-react";

const WEBSITE_TYPES = [
  { icon: Monitor, name: "Landing Page", price: "From ₦32,000", description: "Perfect for product launches, events, and promotional campaigns." },
  { icon: Briefcase, name: "Business Website & App", price: "From ₦80,000", description: "Professional multi-page sites and companion apps for established businesses." },
  { icon: ShoppingCart, name: "E-commerce Store & App", price: "From ₦256,000", description: "Full online store and shopping app with payment gateway and inventory management." },
  { icon: Code, name: "Custom Web & Mobile Application", price: "From ₦400,000", description: "Complex web and mobile apps with custom functionality and integrations." },
];

const PROCESS = [
  { step: "01", title: "Submit Order", description: "Fill out our detailed order form with your project requirements." },
  { step: "02", title: "Make Payment", description: "Secure payment via Paystack. Your project starts after payment confirmation." },
  { step: "03", title: "Development", description: "Our team builds your website & app to your specifications." },
  { step: "04", title: "Review & Launch", description: "You review, we refine, then we launch your site and app live." },
];

export default function WebDevelopment() {
  return (
    <div className="pt-16">
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Code className="w-16 h-16 text-primary mx-auto mb-6" />
            <h1 className="font-display text-6xl md:text-7xl text-white mb-4">WEBSITE & APP DEVELOPMENT</h1>
            <p className="text-white/50 text-lg">Premium websites and apps built to convert visitors into customers.</p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-12">WHAT WE BUILD</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {WEBSITE_TYPES.map((t, i) => {
              const Icon = t.icon;
              return (
                <motion.div
                  key={t.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-card border border-border rounded-xl p-6"
                >
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="text-white font-semibold text-lg mb-1">{t.name}</h3>
                  <p className="text-primary text-sm font-medium mb-3">{t.price}</p>
                  <p className="text-white/50 text-sm">{t.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-12">OUR PROCESS</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {PROCESS.map((p, i) => (
              <motion.div
                key={p.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div className="font-display text-6xl text-primary/20 mb-2">{p.step}</div>
                <h3 className="text-white font-semibold mb-2">{p.title}</h3>
                <p className="text-white/50 text-sm">{p.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-12">WHAT'S INCLUDED</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {[
              "Responsive mobile-first design",
              "SEO-optimized structure",
              "Fast loading speed",
              "Secure HTTPS",
              "Contact forms & CTAs",
              "Social media integration",
              "Google Analytics setup",
              "1 month post-launch support",
            ].map((f) => (
              <div key={f} className="flex items-center gap-3 p-4 bg-card border border-border rounded-lg">
                <CheckCircle className="w-5 h-5 text-primary shrink-0" />
                <span className="text-white/80 text-sm">{f}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary/5 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-5xl text-white mb-4">START YOUR PROJECT</h2>
          <p className="text-white/50 mb-8">Ready to get a professional website & app? Place your order now.</p>
          <Link href="/order">
            <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold">
              Order Now <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
