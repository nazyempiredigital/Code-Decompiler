import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black pt-16">
      <div className="text-center">
        <div className="font-display text-[200px] leading-none text-white/5">404</div>
        <h1 className="font-display text-6xl text-white mb-4 -mt-16">PAGE NOT FOUND</h1>
        <p className="text-white/50 mb-8">The page you're looking for doesn't exist.</p>
        <Link href="/">
          <Button className="bg-primary text-black hover:bg-primary/90 font-bold">
            <Home className="mr-2 w-4 h-4" /> Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}
