import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  Globe, User, LogOut, FolderOpen, MessageSquare, Send,
  Download, Music, LifeBuoy, Plus, ChevronDown, ArrowRight, Trash2,
  Share2, Copy, CheckCircle,
} from "lucide-react";
import { ProfileDropdown } from "@/components/profile-dropdown";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/auth";
import { AuthModal } from "@/components/auth-modal";
import { NotificationBell } from "@/components/notification-bell";
import { BrandLockup } from "@/components/mic-logo";
import { api, type Project, type Message, type SupportTicket, type TicketMessage, type AffiliateApplication, type AffiliateEarnings, type AffiliateWithdrawal } from "@/lib/api";

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending_review:             { label: "Pending Review",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  awaiting_payment:           { label: "Awaiting Payment",  color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  in_progress:                { label: "In Progress",       color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  waiting_for_client_feedback:{ label: "Awaiting Feedback", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  completed:                  { label: "Completed",         color: "bg-green-500/10 text-green-400 border-green-500/20" },
  delivered:                  { label: "Delivered",         color: "bg-primary/10 text-primary border-primary/20" },
};

const TICKET_STATUS: Record<string, { label: string; color: string }> = {
  open:        { label: "Open",        color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  in_progress: { label: "In Progress", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  resolved:    { label: "Resolved",    color: "bg-green-500/10 text-green-400 border-green-500/20" },
  closed:      { label: "Closed",      color: "bg-white/10 text-white/40 border-white/10" },
};

type DashTab = "projects" | "support" | "profile" | "affiliate";

const fmtNaira = (n: number | string) =>
  "₦" + Number(n).toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export default function Dashboard() {
  const { user, logout, isLoading } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const [, setLocation] = useLocation();
  const [authModal, setAuthModal] = useState<"login" | "register" | null>(null);
  const [tab, setTab] = useState<DashTab>("projects");

  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [paying, setPaying] = useState<number | null>(null);

  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketMessages, setTicketMessages] = useState<TicketMessage[]>([]);
  const [newTicketMsg, setNewTicketMsg] = useState("");
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [newTicket, setNewTicket] = useState({ subject: "", message: "", priority: "normal" });
  const [creatingTicket, setCreatingTicket] = useState(false);

  useEffect(() => {
    if (user) {
      loadProjects();
      loadTickets();
    }
  }, [user]);

  useEffect(() => { if (tab === "affiliate") loadAffiliateData(); }, [tab]);

  async function loadAffiliateData() {
    if (affLoaded) return;
    setAffLoaded(true);
    try {
      const data = await api.affiliates.myApplication();
      setAffApp(data.application);
      setAffIsAffiliate(data.isAffiliate);
      setAffReferralCode(data.referralCode);
      if (data.isAffiliate) {
        const [link, earnings, withdrawals] = await Promise.all([
          api.affiliates.referralLink(),
          api.affiliates.earnings(),
          api.affiliates.withdrawals(),
        ]);
        setAffReferralLink(link.referralLink);
        setAffEarnings(earnings);
        setAffWithdrawals(withdrawals);
      }
    } catch {}
  }

  async function loadProjects() {
    try { setProjects(await api.projects.list()); } catch {}
  }

  async function loadTickets() {
    try { setTickets(await api.support.myTickets()); } catch {}
  }

  async function selectProject(p: Project) {
    setSelectedProject(p);
    const msgs = await api.projects.messages(p.id).catch(() => []);
    setMessages(msgs);
  }

  // ── Affiliate state ────────────────────────────────────────────────────
  const [affApp, setAffApp] = useState<AffiliateApplication | null>(null);
  const [affIsAffiliate, setAffIsAffiliate] = useState(false);
  const [affReferralCode, setAffReferralCode] = useState<string | null>(null);
  const [affReferralLink, setAffReferralLink] = useState<string | null>(null);
  const [affEarnings, setAffEarnings] = useState<AffiliateEarnings | null>(null);
  const [affWithdrawals, setAffWithdrawals] = useState<AffiliateWithdrawal[]>([]);
  const [affApplyReason, setAffApplyReason] = useState("");
  const [affApplyPlatform, setAffApplyPlatform] = useState("");
  const [affApplying, setAffApplying] = useState(false);
  const [affApplyError, setAffApplyError] = useState<string | null>(null);
  const [affWithdrawAmount, setAffWithdrawAmount] = useState("");
  const [affWithdrawNotes, setAffWithdrawNotes] = useState("");
  const [affWithdrawing, setAffWithdrawing] = useState(false);
  const [affWithdrawError, setAffWithdrawError] = useState<string | null>(null);
  const [affWithdrawSuccess, setAffWithdrawSuccess] = useState(false);
  const [affCopied, setAffCopied] = useState(false);
  const [affLoaded, setAffLoaded] = useState(false);

  const [deletingProject, setDeletingProject] = useState<number | null>(null);

  async function deleteProject(p: Project) {
    if (p.status !== "awaiting_payment") return;
    if (!confirm("Delete this project? This cannot be undone.")) return;
    setDeletingProject(p.id);
    try {
      await api.projects.delete(p.id);
      setProjects((ps) => ps.filter((x) => x.id !== p.id));
      if (selectedProject?.id === p.id) {
        setSelectedProject(null);
        setMessages([]);
      }
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to delete project");
    } finally {
      setDeletingProject(null);
    }
  }

  async function sendMessage() {
    if (!selectedProject || !newMessage.trim()) return;
    try {
      const msg = await api.projects.sendMessage(selectedProject.id, newMessage.trim());
      setMessages((m) => [...m, msg]);
      setNewMessage("");
    } catch {}
  }

  async function selectTicket(t: SupportTicket) {
    setSelectedTicket(t);
    const msgs = await api.support.messages(t.id).catch(() => []);
    setTicketMessages(msgs);
  }

  async function sendTicketMessage() {
    if (!selectedTicket || !newTicketMsg.trim()) return;
    try {
      const msg = await api.support.sendMessage(selectedTicket.id, newTicketMsg.trim());
      setTicketMessages((m) => [...m, msg]);
      setNewTicketMsg("");
    } catch {}
  }

  async function createTicket(e: React.FormEvent) {
    e.preventDefault();
    if (!newTicket.subject || !newTicket.message) return;
    setCreatingTicket(true);
    try {
      const t = await api.support.create(newTicket.subject, newTicket.message, newTicket.priority);
      setTickets((ts) => [t, ...ts]);
      setShowNewTicket(false);
      setNewTicket({ subject: "", message: "", priority: "normal" });
      selectTicket(t);
    } catch {
    } finally { setCreatingTicket(false); }
  }

  async function handlePayProject(project: Project) {
    setPaying(project.id);
    try {
      const payData = await api.payments.initialize(project.id);
      const scriptId = "paystack-js";
      if (!document.getElementById(scriptId)) {
        await new Promise<void>((resolve) => {
          const script = document.createElement("script");
          script.id = scriptId;
          script.src = "https://js.paystack.co/v1/inline.js";
          script.onload = () => resolve();
          document.head.appendChild(script);
        });
      }
      const handler = (window as any).PaystackPop.setup({
        key: payData.publicKey,
        email: payData.email,
        amount: payData.amountKobo,
        ref: payData.reference,
        onClose() { setPaying(null); },
        callback(response: { reference: string }) {
          setLocation(`/thank-you?reference=${response.reference}`);
        },
      });
      handler.openIframe();
    } catch (err) {
      alert(err instanceof Error ? err.message : "Payment failed");
      setPaying(null);
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <div className="min-h-screen bg-black flex items-center justify-center p-4">
          <div className="max-w-sm w-full text-center">
            <Globe className="w-12 h-12 text-primary mx-auto mb-4" />
            <h1 className="font-display text-4xl text-white mb-2">DASHBOARD</h1>
            <p className="text-white/50 mb-6">Login to access your dashboard.</p>
            <div className="flex flex-col gap-3">
              <Button onClick={() => setAuthModal("login")} className="bg-primary text-black hover:bg-primary/90 font-bold">Login</Button>
              <Button variant="outline" onClick={() => setAuthModal("register")} className="border-white/20 text-white">Create Account</Button>
            </div>
          </div>
        </div>
        {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSwitch={(m) => setAuthModal(m)} />}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      <div className="bg-black/90 backdrop-blur-md border-b border-white/10 px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <BrandLockup iconSize="w-6 h-7" textSize="text-xl" />
        </Link>
        <div className="flex items-center gap-4">
          <NotificationBell />
          <span className="text-white/50 text-sm hidden sm:block">Hi, {user.name.split(" ")[0]}</span>
          <ProfileDropdown
            open={profileOpen}
            onClose={() => setProfileOpen(false)}
            onToggle={() => setProfileOpen((v) => !v)}
          />
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {(user.role === "verified_artist" || user.role === "admin") && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-primary/5 border border-primary/20 rounded-xl flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <Music className="w-5 h-5 text-primary" />
              <div>
                <p className="text-white font-medium text-sm">Artist Studio</p>
                <p className="text-white/40 text-xs">Upload music, manage releases and track royalties</p>
              </div>
            </div>
            <Link href="/artist-dashboard">
              <Button size="sm" className="bg-primary text-black hover:bg-primary/90 font-bold">
                Open Studio <ArrowRight className="ml-1 w-3 h-3" />
              </Button>
            </Link>
          </motion.div>
        )}

        {user.role === "client" && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-white/3 border border-white/10 rounded-xl flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <Music className="w-5 h-5 text-white/40" />
              <div>
                <p className="text-white/70 font-medium text-sm">Want to distribute your music?</p>
                <p className="text-white/30 text-xs">Apply to become a Verified Artist — free distribution, keep 85%</p>
              </div>
            </div>
            <Link href="/apply-artist">
              <Button size="sm" variant="outline" className="border-white/20 text-white/70 hover:text-white text-xs">
                Apply Now
              </Button>
            </Link>
          </motion.div>
        )}

        <div className="flex flex-wrap gap-2 mb-8">
          {([
            { id: "projects",  label: "My Projects", icon: FolderOpen },
            { id: "support",   label: "Support",     icon: LifeBuoy },
            { id: "affiliate", label: "Affiliate",   icon: Share2 },
            { id: "profile",   label: "Profile",     icon: User },
          ] as const).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab === id ? "bg-primary text-black" : "text-white/50 hover:text-white"
              }`}
            >
              <Icon className="w-4 h-4" /> {label}
            </button>
          ))}
        </div>

        {tab === "projects" && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-white font-semibold">Your Projects ({projects.length})</h2>
                <Link href="/order">
                  <Button size="sm" className="bg-primary text-black hover:bg-primary/90 text-xs font-bold">+ New Order</Button>
                </Link>
              </div>
              {projects.length === 0 && (
                <div className="text-center py-16 text-white/30">
                  <FolderOpen className="w-10 h-10 mx-auto mb-3" />
                  <p>No projects yet.</p>
                  <Link href="/order" className="text-primary hover:underline text-sm mt-2 inline-block">Place your first order</Link>
                </div>
              )}
              {projects.map((p) => {
                const status = STATUS_LABELS[p.status] ?? { label: p.status, color: "bg-white/10 text-white/50 border-white/10" };
                return (
                  <div
                    key={p.id}
                    onClick={() => selectProject(p)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedProject?.id === p.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-white/20"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="text-white font-medium text-sm">{p.websiteType}</div>
                        <div className="text-white/40 text-xs">{p.projectId}</div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${status.color}`}>{status.label}</span>
                        {p.status === "awaiting_payment" && (
                          <button
                            onClick={(e) => { e.stopPropagation(); deleteProject(p); }}
                            disabled={deletingProject === p.id}
                            title="Delete project"
                            className="p-1 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-colors disabled:opacity-50"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-primary font-bold">{fmtNaira(p.totalAmount)}</span>
                      {p.paymentStatus === "unpaid" && (
                        <Button
                          size="sm"
                          className="bg-primary text-black hover:bg-primary/90 text-xs h-7 font-bold"
                          disabled={paying === p.id}
                          onClick={(e) => { e.stopPropagation(); handlePayProject(p); }}
                        >
                          {paying === p.id ? "..." : "Pay Now"}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="lg:col-span-3">
              {!selectedProject ? (
                <div className="flex items-center justify-center h-64 text-white/20 text-center">
                  <div><MessageSquare className="w-12 h-12 mx-auto mb-3" /><p>Select a project to view details</p></div>
                </div>
              ) : (
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="p-6 border-b border-border">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-white font-bold text-lg">{selectedProject.websiteType}</h3>
                        <div className="text-white/40 text-sm">{selectedProject.projectId}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-primary font-bold text-xl">{fmtNaira(selectedProject.totalAmount)}</div>
                        <div className={`text-xs px-2 py-0.5 rounded-full border inline-block mt-1 ${STATUS_LABELS[selectedProject.status]?.color ?? "bg-white/10 text-white/50"}`}>
                          {STATUS_LABELS[selectedProject.status]?.label ?? selectedProject.status}
                        </div>
                      </div>
                    </div>
                    {selectedProject.description && <p className="text-white/50 text-sm mt-3">{selectedProject.description}</p>}
                  </div>
                  {(selectedProject.completedFiles?.length ?? 0) > 0 && (
                    <div className="p-4 border-b border-border">
                      <h4 className="text-white font-medium text-sm mb-3 flex items-center gap-2">
                        <Download className="w-4 h-4 text-primary" /> Completed Files
                      </h4>
                      <div className="space-y-2">
                        {selectedProject.completedFiles.map((url, i) => (
                          <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-primary hover:underline text-sm">
                            <Download className="w-3 h-3" /> File {i + 1}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="p-4 border-b border-border max-h-64 overflow-y-auto flex flex-col gap-3">
                    {messages.length === 0 && <p className="text-white/30 text-sm text-center py-4">No messages yet</p>}
                    {messages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.isAdmin ? "justify-start" : "justify-end"}`}>
                        <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${msg.isAdmin ? "bg-card border border-border text-white/80" : "bg-primary text-black font-medium"}`}>
                          {msg.isAdmin && <div className="text-xs text-white/40 mb-1">Support</div>}
                          {msg.content}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-4 flex gap-3">
                    <Textarea
                      placeholder="Send a message..."
                      rows={2}
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                      className="resize-none"
                    />
                    <Button onClick={sendMessage} className="bg-primary text-black hover:bg-primary/90 shrink-0">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "support" && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-white font-semibold">Support Tickets ({tickets.length})</h2>
                <Button size="sm" onClick={() => setShowNewTicket(true)} className="bg-primary text-black hover:bg-primary/90 text-xs font-bold">
                  <Plus className="w-3 h-3 mr-1" /> New Ticket
                </Button>
              </div>

              {showNewTicket && (
                <form onSubmit={createTicket} className="bg-card border border-primary/30 rounded-xl p-4 space-y-3">
                  <h3 className="text-white font-medium text-sm">New Support Ticket</h3>
                  <input
                    className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Subject"
                    value={newTicket.subject}
                    onChange={(e) => setNewTicket((t) => ({ ...t, subject: e.target.value }))}
                  />
                  <textarea
                    rows={3}
                    className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Describe your issue..."
                    value={newTicket.message}
                    onChange={(e) => setNewTicket((t) => ({ ...t, message: e.target.value }))}
                  />
                  <select
                    className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    value={newTicket.priority}
                    onChange={(e) => setNewTicket((t) => ({ ...t, priority: e.target.value }))}
                  >
                    <option value="low">Low Priority</option>
                    <option value="normal">Normal Priority</option>
                    <option value="high">High Priority</option>
                    <option value="urgent">Urgent</option>
                  </select>
                  <div className="flex gap-2">
                    <Button type="button" size="sm" variant="outline" onClick={() => setShowNewTicket(false)} className="border-white/20 text-white/70 flex-1">Cancel</Button>
                    <Button type="submit" size="sm" disabled={creatingTicket} className="bg-primary text-black hover:bg-primary/90 font-bold flex-1">
                      {creatingTicket ? "..." : "Submit"}
                    </Button>
                  </div>
                </form>
              )}

              {tickets.length === 0 && !showNewTicket && (
                <div className="text-center py-12 text-white/30">
                  <LifeBuoy className="w-10 h-10 mx-auto mb-3" />
                  <p>No support tickets yet.</p>
                </div>
              )}
              {tickets.map((t) => {
                const s = TICKET_STATUS[t.status] ?? TICKET_STATUS.open;
                return (
                  <div
                    key={t.id}
                    onClick={() => selectTicket(t)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedTicket?.id === t.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-white/20"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-white font-medium text-sm truncate">{t.subject}</div>
                        <div className="text-white/40 text-xs mt-0.5">{new Date(t.createdAt).toLocaleDateString()}</div>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border shrink-0 ${s.color}`}>{s.label}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="lg:col-span-3">
              {!selectedTicket ? (
                <div className="flex items-center justify-center h-64 text-white/20 text-center">
                  <div><LifeBuoy className="w-12 h-12 mx-auto mb-3" /><p>Select a ticket to view</p></div>
                </div>
              ) : (
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="p-4 border-b border-border flex items-center justify-between">
                    <div>
                      <h3 className="text-white font-bold">{selectedTicket.subject}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full border inline-block mt-1 ${TICKET_STATUS[selectedTicket.status]?.color}`}>
                        {TICKET_STATUS[selectedTicket.status]?.label}
                      </span>
                    </div>
                  </div>
                  <div className="p-4 max-h-72 overflow-y-auto flex flex-col gap-3">
                    {ticketMessages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.isStaff ? "justify-start" : "justify-end"}`}>
                        <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${msg.isStaff ? "bg-card border border-border text-white/80" : "bg-primary text-black font-medium"}`}>
                          {msg.isStaff && <div className="text-xs text-white/40 mb-1">Support Team</div>}
                          {msg.message}
                        </div>
                      </div>
                    ))}
                  </div>
                  {selectedTicket.status !== "closed" && selectedTicket.status !== "resolved" && (
                    <div className="p-4 flex gap-3 border-t border-border">
                      <Textarea
                        placeholder="Reply..."
                        rows={2}
                        value={newTicketMsg}
                        onChange={(e) => setNewTicketMsg(e.target.value)}
                        onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendTicketMessage(); } }}
                        className="resize-none"
                      />
                      <Button onClick={sendTicketMessage} className="bg-primary text-black hover:bg-primary/90 shrink-0">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "affiliate" && <AffiliateTab
          app={affApp} setApp={setAffApp}
          isAffiliate={affIsAffiliate} setIsAffiliate={setAffIsAffiliate}
          referralCode={affReferralCode} referralLink={affReferralLink}
          earnings={affEarnings} setEarnings={setAffEarnings}
          withdrawals={affWithdrawals} setWithdrawals={setAffWithdrawals}
          applyReason={affApplyReason} setApplyReason={setAffApplyReason}
          applyPlatform={affApplyPlatform} setApplyPlatform={setAffApplyPlatform}
          applying={affApplying} setApplying={setAffApplying}
          applyError={affApplyError} setApplyError={setAffApplyError}
          withdrawAmount={affWithdrawAmount} setWithdrawAmount={setAffWithdrawAmount}
          withdrawNotes={affWithdrawNotes} setWithdrawNotes={setAffWithdrawNotes}
          withdrawing={affWithdrawing} setWithdrawing={setAffWithdrawing}
          withdrawError={affWithdrawError} setWithdrawError={setAffWithdrawError}
          withdrawSuccess={affWithdrawSuccess} setWithdrawSuccess={setAffWithdrawSuccess}
          copied={affCopied} setCopied={setAffCopied}
          onLoad={loadAffiliateData}
        />}

        {tab === "profile" && <ProfileTab user={user} />}
      </div>
    </div>
  );
}

const fmtN = (n: number) => "₦" + n.toLocaleString("en-NG", { minimumFractionDigits: 2 });

interface AffiliateTabProps {
  app: AffiliateApplication | null; setApp: (a: AffiliateApplication) => void;
  isAffiliate: boolean; setIsAffiliate: (v: boolean) => void;
  referralCode: string | null; referralLink: string | null;
  earnings: AffiliateEarnings | null; setEarnings: (e: AffiliateEarnings) => void;
  withdrawals: AffiliateWithdrawal[]; setWithdrawals: (w: AffiliateWithdrawal[]) => void;
  applyReason: string; setApplyReason: (v: string) => void;
  applyPlatform: string; setApplyPlatform: (v: string) => void;
  applying: boolean; setApplying: (v: boolean) => void;
  applyError: string | null; setApplyError: (v: string | null) => void;
  withdrawAmount: string; setWithdrawAmount: (v: string) => void;
  withdrawNotes: string; setWithdrawNotes: (v: string) => void;
  withdrawing: boolean; setWithdrawing: (v: boolean) => void;
  withdrawError: string | null; setWithdrawError: (v: string | null) => void;
  withdrawSuccess: boolean; setWithdrawSuccess: (v: boolean) => void;
  copied: boolean; setCopied: (v: boolean) => void;
  onLoad: () => void;
}

const AFF_STATUS: Record<string, { label: string; color: string }> = {
  pending:  { label: "Under Review", color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20" },
  approved: { label: "Approved",     color: "text-green-400 bg-green-500/10 border-green-500/20" },
  rejected: { label: "Not Approved", color: "text-red-400 bg-red-500/10 border-red-500/20" },
};

const WD_STATUS: Record<string, { label: string; color: string }> = {
  pending:  { label: "Pending",  color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20" },
  approved: { label: "Approved", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
  paid:     { label: "Paid",     color: "text-green-400 bg-green-500/10 border-green-500/20" },
  rejected: { label: "Rejected", color: "text-red-400 bg-red-500/10 border-red-500/20" },
};

function AffiliateTab({
  app, setApp, isAffiliate, referralCode, referralLink,
  earnings, setEarnings, withdrawals, setWithdrawals,
  applyReason, setApplyReason, applyPlatform, setApplyPlatform,
  applying, setApplying, applyError, setApplyError,
  withdrawAmount, setWithdrawAmount, withdrawNotes, setWithdrawNotes,
  withdrawing, setWithdrawing, withdrawError, setWithdrawError,
  withdrawSuccess, setWithdrawSuccess, copied, setCopied, onLoad,
}: AffiliateTabProps) {
  useEffect(() => { onLoad(); }, []);

  async function handleApply(e: React.FormEvent) {
    e.preventDefault();
    if (!applyReason.trim()) { setApplyError("Please explain why you want to be an affiliate."); return; }
    setApplying(true); setApplyError(null);
    try {
      const result = await api.affiliates.apply(applyReason.trim(), applyPlatform.trim() || undefined);
      setApp(result);
    } catch (err) { setApplyError(err instanceof Error ? err.message : "Failed to submit"); }
    setApplying(false);
  }

  async function handleWithdraw(e: React.FormEvent) {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (!amt || amt <= 0) { setWithdrawError("Enter a valid amount."); return; }
    setWithdrawing(true); setWithdrawError(null); setWithdrawSuccess(false);
    try {
      const row = await api.affiliates.withdraw(amt, withdrawNotes.trim() || undefined);
      setWithdrawals([row, ...withdrawals]);
      if (earnings) setEarnings({ ...earnings, availableBalance: earnings.availableBalance - amt, canWithdraw: (earnings.availableBalance - amt) >= earnings.minWithdrawal });
      setWithdrawAmount(""); setWithdrawNotes(""); setWithdrawSuccess(true);
    } catch (err) { setWithdrawError(err instanceof Error ? err.message : "Failed"); }
    setWithdrawing(false);
  }

  function copyLink() {
    if (!referralLink) return;
    navigator.clipboard.writeText(referralLink).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  }

  return (
    <div className="max-w-2xl space-y-6">
      <h2 className="font-display text-3xl text-white">AFFILIATE PROGRAMME</h2>
      <p className="text-white/40 text-sm">Earn 5% commission on every completed project you refer.</p>

      {/* Not yet applied */}
      {!app && !isAffiliate && (
        <form onSubmit={handleApply} className="bg-card border border-border rounded-xl p-6 space-y-4">
          <h3 className="text-white font-bold text-lg">Apply to Become an Affiliate</h3>
          <p className="text-white/40 text-sm">Tell us a bit about yourself and how you plan to refer clients.</p>
          <div className="space-y-1">
            <label className="text-white/50 text-sm">Why do you want to be an affiliate? *</label>
            <textarea
              rows={3}
              className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="e.g. I run a digital marketing blog and regularly advise businesses on web development..."
              value={applyReason}
              onChange={(e) => setApplyReason(e.target.value)}
            />
          </div>
          <div className="space-y-1">
            <label className="text-white/50 text-sm">Website / Social Media (optional)</label>
            <input
              className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="https://yourblog.com or @yourhandle"
              value={applyPlatform}
              onChange={(e) => setApplyPlatform(e.target.value)}
            />
          </div>
          {applyError && <p className="text-red-400 text-sm">{applyError}</p>}
          <Button type="submit" disabled={applying} className="bg-primary text-black hover:bg-primary/90 font-bold">
            {applying ? "Submitting..." : "Submit Application"}
          </Button>
        </form>
      )}

      {/* Application submitted, pending */}
      {app && !isAffiliate && (
        <div className="bg-card border border-border rounded-xl p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-bold">Application Status</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full border ${AFF_STATUS[app.status]?.color}`}>
              {AFF_STATUS[app.status]?.label ?? app.status}
            </span>
          </div>
          <p className="text-white/40 text-sm">
            {app.status === "pending" && "Your application is being reviewed. We'll notify you once it's processed."}
            {app.status === "rejected" && (app.adminNotes ? `Not approved: ${app.adminNotes}` : "Your application was not approved at this time.")}
          </p>
          <p className="text-white/30 text-xs">Submitted {new Date(app.createdAt).toLocaleDateString()}</p>
        </div>
      )}

      {/* Approved affiliate */}
      {isAffiliate && (
        <>
          {/* Referral link card */}
          <div className="bg-card border border-primary/20 rounded-xl p-6 space-y-3">
            <div className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-primary" />
              <h3 className="text-white font-bold">Your Referral Link</h3>
            </div>
            <p className="text-white/40 text-xs">Share this link — when someone places a project through it, you earn 5% commission.</p>
            <div className="flex items-center gap-2">
              <input
                readOnly
                className="flex-1 bg-black/40 border border-border rounded-lg px-3 py-2 text-primary text-sm font-mono"
                value={referralLink ?? `nazyempire.com?ref=${referralCode}`}
              />
              <Button onClick={copyLink} size="sm" className="bg-primary text-black hover:bg-primary/90 font-bold shrink-0">
                {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? "Copied!" : "Copy"}
              </Button>
            </div>
            <p className="text-white/30 text-xs">Your code: <span className="font-mono text-white/50">{referralCode}</span></p>
          </div>

          {/* Earnings summary */}
          {earnings && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: "Total Earned",  value: fmtN(earnings.totalCommissions) },
                { label: "Available",     value: fmtN(earnings.availableBalance) },
                { label: "Projects",      value: String(earnings.referredProjects) },
                { label: "Commission",    value: `${earnings.commissionRate}%` },
              ].map(({ label, value }) => (
                <div key={label} className="bg-card border border-border rounded-xl p-4">
                  <p className="text-white font-bold text-lg">{value}</p>
                  <p className="text-white/40 text-xs mt-0.5">{label}</p>
                </div>
              ))}
            </div>
          )}

          {/* Withdraw form */}
          {earnings && (
            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="text-white font-bold">Request Withdrawal</h3>
              {earnings.canWithdraw ? (
                <form onSubmit={handleWithdraw} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-white/50 text-sm">Amount (min ₦10,000, max {fmtN(earnings.availableBalance)})</label>
                    <input
                      type="number"
                      min="10000"
                      max={earnings.availableBalance}
                      step="100"
                      className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="e.g. 15000"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-white/50 text-sm">Notes / Bank details (optional)</label>
                    <input
                      className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Bank name, account number..."
                      value={withdrawNotes}
                      onChange={(e) => setWithdrawNotes(e.target.value)}
                    />
                  </div>
                  {withdrawError && <p className="text-red-400 text-sm">{withdrawError}</p>}
                  {withdrawSuccess && <p className="text-green-400 text-sm">Withdrawal request submitted!</p>}
                  <Button type="submit" disabled={withdrawing} className="bg-primary text-black hover:bg-primary/90 font-bold">
                    {withdrawing ? "Submitting..." : "Request Withdrawal"}
                  </Button>
                </form>
              ) : (
                <div className="text-center py-4">
                  <p className="text-white/40 text-sm">Minimum withdrawal is ₦10,000.</p>
                  <p className="text-white/30 text-xs mt-1">You need {fmtN(earnings.shortfall)} more to withdraw.</p>
                </div>
              )}
            </div>
          )}

          {/* Commission history */}
          {earnings && earnings.commissions.length > 0 && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="text-white font-semibold">Commission History</h3>
              </div>
              <div className="divide-y divide-border">
                {earnings.commissions.map((c) => (
                  <div key={c.id} className="px-5 py-3 flex items-center justify-between gap-4">
                    <div>
                      <p className="text-white text-sm font-medium">{c.projectRef}</p>
                      <p className="text-white/40 text-xs">{new Date(c.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-primary font-bold text-sm">+{fmtN(c.commission)}</p>
                      <p className="text-white/30 text-xs">{c.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Withdrawal history */}
          {withdrawals.length > 0 && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="text-white font-semibold">Withdrawal History</h3>
              </div>
              <div className="divide-y divide-border">
                {withdrawals.map((w) => {
                  const s = WD_STATUS[w.status] ?? WD_STATUS.pending;
                  return (
                    <div key={w.id} className="px-5 py-3 flex items-center justify-between gap-4">
                      <div>
                        <p className="text-white text-sm font-medium">{fmtN(w.amount)}</p>
                        <p className="text-white/40 text-xs">{new Date(w.createdAt).toLocaleDateString()}</p>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border ${s.color}`}>{s.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ProfileTab({ user }: { user: ReturnType<typeof useAuth>["user"] }) {
  const { login } = useAuth();
  const [form, setForm] = useState({
    name: user?.name ?? "", phone: user?.phone ?? "",
    company: user?.company ?? "", country: user?.country ?? "",
  });
  const [pwForm, setPwForm] = useState({ current: "", newPw: "", confirm: "" });
  const [saving, setSaving] = useState(false);
  const [changingPw, setChangingPw] = useState(false);
  const [msg, setMsg] = useState("");
  const [pwMsg, setPwMsg] = useState("");

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMsg("");
    try {
      await api.auth.updateProfile(form);
      setMsg("Profile updated!");
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Failed");
    } finally { setSaving(false); }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pwForm.newPw !== pwForm.confirm) { setPwMsg("Passwords don't match"); return; }
    setChangingPw(true);
    setPwMsg("");
    try {
      await api.auth.changePassword(pwForm.current, pwForm.newPw);
      setPwMsg("Password changed!");
      setPwForm({ current: "", newPw: "", confirm: "" });
    } catch (err) {
      setPwMsg(err instanceof Error ? err.message : "Failed");
    } finally { setChangingPw(false); }
  }

  return (
    <div className="max-w-lg space-y-6">
      <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
          <User className="w-5 h-5 text-primary" />
        </div>
        <div>
          <p className="text-white font-semibold">{user?.name}</p>
          <p className="text-white/40 text-xs capitalize">{user?.role?.replace("_", " ")}</p>
        </div>
      </div>

      <form onSubmit={saveProfile} className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h2 className="text-white font-bold text-lg">Profile Information</h2>
        <div className="space-y-1">
          <label className="text-white/50 text-sm">Name</label>
          <input className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
        </div>
        <div className="space-y-1">
          <label className="text-white/50 text-sm">Email (cannot change)</label>
          <input disabled className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white/30 text-sm" value={user?.email} />
        </div>
        <div className="space-y-1">
          <label className="text-white/50 text-sm">Phone</label>
          <input className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-white/50 text-sm">Company</label>
            <input className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary" value={form.company} onChange={(e) => setForm((f) => ({ ...f, company: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <label className="text-white/50 text-sm">Country</label>
            <input className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary" value={form.country} onChange={(e) => setForm((f) => ({ ...f, country: e.target.value }))} />
          </div>
        </div>
        {msg && <p className={`text-sm ${msg.includes("!") ? "text-green-400" : "text-destructive"}`}>{msg}</p>}
        <Button type="submit" disabled={saving} className="bg-primary text-black hover:bg-primary/90 font-bold">
          {saving ? "Saving..." : "Save Profile"}
        </Button>
      </form>

      <form onSubmit={changePassword} className="bg-card border border-border rounded-xl p-6 space-y-4">
        <h2 className="text-white font-bold text-lg">Change Password</h2>
        {[
          { key: "current", label: "Current Password" },
          { key: "newPw",   label: "New Password" },
          { key: "confirm", label: "Confirm New Password" },
        ].map(({ key, label }) => (
          <div key={key} className="space-y-1">
            <label className="text-white/50 text-sm">{label}</label>
            <input
              type="password"
              className="w-full bg-input border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={pwForm[key as keyof typeof pwForm]}
              onChange={(e) => setPwForm((f) => ({ ...f, [key]: e.target.value }))}
            />
          </div>
        ))}
        {pwMsg && <p className={`text-sm ${pwMsg.includes("!") ? "text-green-400" : "text-destructive"}`}>{pwMsg}</p>}
        <Button type="submit" disabled={changingPw} variant="outline" className="border-white/20 text-white">
          {changingPw ? "Changing..." : "Change Password"}
        </Button>
      </form>
    </div>
  );
}
