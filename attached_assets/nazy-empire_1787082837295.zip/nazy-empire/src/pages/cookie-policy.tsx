import { LegalPage } from "@/components/legal-page";
import { Link } from "wouter";

export default function CookiePolicy() {
  return (
    <LegalPage
      title="COOKIE POLICY"
      subtitle="This Cookie Policy explains what cookies and similar technologies are used on the NAZY EMPIRE DIGITAL website, why we use them, and how you can manage your preferences."
      effectiveDate="10 July 2026"
      lastReviewed="10 July 2026"
      sections={[
        {
          heading: "1. What Are Cookies?",
          content: (
            <>
              <p>Cookies are small text files placed on your device (computer, smartphone, or tablet) by a website when you visit it. They are widely used to make websites work, improve user experience, and provide analytical information to site owners.</p>
              <p>Similar technologies include:</p>
              <ul>
                <li><strong>Local storage / session storage:</strong> Browser-side storage mechanisms that persist data without expiry (local storage) or only for the session (session storage).</li>
                <li><strong>Pixel tags / web beacons:</strong> Tiny invisible images embedded in pages or emails used to track user behaviour.</li>
                <li><strong>Device fingerprinting:</strong> Collecting hardware and software attributes to identify devices.</li>
              </ul>
              <p>References to "cookies" in this Policy include all such similar technologies unless stated otherwise.</p>
            </>
          ),
        },
        {
          heading: "2. Cookies We Use",
          content: (
            <>
              <h3>2.1 Strictly Necessary Cookies</h3>
              <p>These cookies are essential for the website to function and cannot be disabled. They do not store any personally identifiable information.</p>
              <ul>
                <li><strong>Session / authentication token:</strong> Keeps you logged in during your session. Without this cookie, you would need to log in on every page. Expires: end of browser session or JWT token expiry (typically 7 days).</li>
                <li><strong>CSRF protection token:</strong> Protects form submissions from cross-site request forgery attacks. Expires: session.</li>
              </ul>
              <h3>2.2 Functional Cookies</h3>
              <p>These cookies enable enhanced functionality and personalisation. Disabling them may affect your experience.</p>
              <ul>
                <li><strong>User preferences:</strong> Stores preferences such as selected service category or UI state. Expires: 30 days.</li>
              </ul>
              <h3>2.3 Analytics Cookies</h3>
              <p>We may use analytics tools that place cookies to help us understand how visitors interact with the website (pages visited, time spent, referral sources). The data is aggregated and anonymised and does not identify you personally.</p>
              <ul>
                <li>Analytics cookies are not placed without your consent where consent is required by applicable law.</li>
                <li>Typical expiry: 13–26 months.</li>
              </ul>
              <h3>2.4 Third-Party Cookies (Paystack)</h3>
              <p>When you initiate a payment, Paystack's checkout widget may set cookies for fraud-prevention, session continuity, and PCI compliance purposes. These are governed by <a href="https://paystack.com/terms" target="_blank" rel="noopener noreferrer">Paystack's Privacy Policy</a>. We have no access to or control over these cookies.</p>
              <h3>2.5 Advertising / Tracking Cookies</h3>
              <p>We do not currently use advertising or cross-site tracking cookies. If we introduce such cookies in the future, we will update this Policy, obtain consent where required, and give you the ability to opt out before they are placed.</p>
            </>
          ),
        },
        {
          heading: "3. Legal Basis for Using Cookies",
          content: (
            <>
              <p>Under the Nigeria Data Protection Act 2023 and aligned international standards:</p>
              <ul>
                <li><strong>Strictly necessary cookies</strong> are placed on the basis of our legitimate interest to provide a functioning website. No consent is required for these.</li>
                <li><strong>Functional and analytics cookies</strong> are placed on the basis of your consent, where such consent is required. By continuing to use the website after being presented with the cookie notice, or by actively accepting cookies, you consent to the use of these cookies.</li>
                <li>You may withdraw your consent at any time by following the instructions in Clause 4.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "4. How to Manage Cookies",
          content: (
            <>
              <p>You have several options for controlling cookies:</p>
              <h3>4.1 Browser Settings</h3>
              <p>You can configure your browser to block, delete, or alert you about cookies. The steps to do this vary by browser:</p>
              <ul>
                <li><strong>Chrome:</strong> Settings → Privacy and security → Cookies and other site data.</li>
                <li><strong>Firefox:</strong> Settings → Privacy & Security → Cookies and Site Data.</li>
                <li><strong>Safari:</strong> Preferences → Privacy → Manage Website Data.</li>
                <li><strong>Edge:</strong> Settings → Privacy, search, and services → Cookies.</li>
              </ul>
              <p>Please note that blocking strictly necessary cookies will impair the functionality of the website (e.g., you will not be able to remain logged in).</p>
              <h3>4.2 Opt-Out Tools</h3>
              <p>For analytics cookies, you may be able to opt out via your browser settings or by installing your analytics provider's opt-out browser extension.</p>
              <h3>4.3 Mobile Devices</h3>
              <p>On mobile devices, you can manage cookies through your browser settings. You may also use your device's "Limit Ad Tracking" (iOS) or "Opt Out of Ads Personalization" (Android) settings to restrict cookie-based advertising (though we do not currently use advertising cookies).</p>
            </>
          ),
        },
        {
          heading: "5. Impact of Disabling Cookies",
          content: (
            <>
              <p>Disabling non-essential cookies will not prevent you from using the core informational parts of the website. However, you may experience:</p>
              <ul>
                <li>Being logged out at the end of each browser session.</li>
                <li>Loss of saved preferences.</li>
                <li>Reduced ability to receive personalised content.</li>
              </ul>
              <p>Disabling strictly necessary cookies will prevent you from logging in, placing orders, or using any authenticated feature of the website.</p>
            </>
          ),
        },
        {
          heading: "6. Do Not Track",
          content: (
            <p>Some browsers include a "Do Not Track" (DNT) feature. Our website does not currently respond to DNT signals in a standardised way, as there is no universally accepted standard for DNT. We will revisit this as standards develop.</p>
          ),
        },
        {
          heading: "7. Changes to this Cookie Policy",
          content: (
            <p>We may update this Cookie Policy to reflect changes in the cookies we use or in applicable legal requirements. We will update the "Last reviewed" date at the top of this page. For material changes, we will notify you via a notice on the website. Your continued use of the website after any change constitutes acceptance of the revised Policy.</p>
          ),
        },
        {
          heading: "8. Further Information",
          content: (
            <>
              <p>For more information about how we use your personal data, please read our <Link href="/privacy">Privacy Policy</Link>.</p>
              <p>For any questions about our use of cookies:<br />
              <strong>NAZY EMPIRE DIGITAL</strong><br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
            </>
          ),
        },
      ]}
    />
  );
}
