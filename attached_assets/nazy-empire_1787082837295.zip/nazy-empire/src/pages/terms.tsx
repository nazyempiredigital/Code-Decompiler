import { LegalPage } from "@/components/legal-page";
import { Link } from "wouter";

export default function Terms() {
  return (
    <LegalPage
      title="TERMS & CONDITIONS"
      subtitle="Please read these Terms and Conditions carefully before using any service offered by NAZY EMPIRE DIGITAL. By placing an order, creating an account, or otherwise accessing our services, you confirm that you have read, understood, and agree to be bound by these Terms."
      effectiveDate="10 July 2026"
      lastReviewed="17 July 2026"
      sections={[
        {
          heading: "1. Parties and Binding Agreement",
          content: (
            <>
              <p>These Terms and Conditions ("Terms") constitute a legally binding agreement between <strong>NAZY EMPIRE DIGITAL</strong> (CAC Business Name Registration No. BN 9657494, Lagos State, Nigeria; hereinafter "the Company", "we", "us", or "our") and the individual or legal entity accessing or using any service offered by the Company ("Client", "you", or "your").</p>
              <p>By using our website (<strong>nazyempire.com</strong>), placing an order, creating an account, or communicating with us for the purpose of procuring services, you irrevocably agree to these Terms. If you do not agree, you must immediately cease using the website and our services.</p>
              <p>If you are accepting these Terms on behalf of a company or other legal entity, you represent and warrant that you have authority to bind that entity, and "you" refers to that entity.</p>
            </>
          ),
        },
        {
          heading: "2. Business Name and Registration",
          content: (
            <>
              <p>NAZY EMPIRE DIGITAL is a registered business name under the Companies and Allied Matters Act (CAMA) 2020 of the Federal Republic of Nigeria, registered with the Corporate Affairs Commission (CAC) under Business Name Registration Number <strong>BN 9657494</strong>. The Company is not a limited liability company and the proprietor may bear personal liability for the business's obligations as provided under Nigerian law.</p>
              <p>Nothing in these Terms shall be construed to create a partnership, joint venture, agency, employment, or franchise relationship between you and the Company.</p>
            </>
          ),
        },
        {
          heading: "3. Description of Services",
          content: (
            <>
              <p>The Company offers the following digital services:</p>
              <ul>
                <li><strong>Website & App Development</strong> — Custom design and development of websites and mobile applications, including but not limited to corporate websites, e-commerce platforms, restaurant systems, e-learning portals, and custom web applications.</li>
                <li><strong>Domain Registration</strong> — Registration, transfer, and management of domain names across generic and country-code top-level domains (gTLDs and ccTLDs).</li>
                <li><strong>Web Hosting</strong> — Shared, VPS, and dedicated web hosting services including SSL provisioning, DNS management, and email hosting.</li>
                <li><strong>Music Distribution</strong> — Digital distribution of audio recordings to streaming platforms and digital stores worldwide.</li>
              </ul>
              <p>The Company reserves the right to add, modify, or discontinue any service at any time with reasonable notice to affected clients. Specific deliverables, timelines, and pricing for each engagement are governed by the Order Confirmation or Service Agreement issued at the time of order.</p>
            </>
          ),
        },
        {
          heading: "4. Eligibility",
          content: (
            <>
              <p>You must be at least 18 years of age to use our services. By using this website or placing an order, you represent and warrant that you are 18 years of age or older, have the legal capacity to enter into a binding contract under applicable law, and will use our services only for lawful purposes.</p>
              <p>The Company reserves the right to refuse service to any person or entity at its sole discretion, including for compliance, ethical, or legal reasons.</p>
            </>
          ),
        },
        {
          heading: "5. Orders and Contract Formation",
          content: (
            <>
              <p>A binding contract between you and the Company is formed only when: (a) you submit an order through the website or in writing; (b) the Company sends you a written Order Confirmation or issues an invoice; and (c) you make the required payment or deposit as specified.</p>
              <p>Order confirmations are sent via email. You are responsible for ensuring that your email address on record is current and monitored. The Company is not liable for missed communications sent to a stale or incorrect email address.</p>
              <p>Quotations or estimates provided before an Order Confirmation are non-binding and subject to change.</p>
            </>
          ),
        },
        {
          heading: "6. Pricing and Payment",
          content: (
            <>
              <p>All prices are quoted and invoiced in <strong>Nigerian Naira (NGN)</strong> unless an alternative currency is expressly agreed in writing. Prices displayed on the website are indicative and subject to variation based on project scope.</p>
              <p>All payments are processed securely through <strong>Paystack</strong>, a PCI-DSS Level 1 certified payment gateway. The Company does not store, process, or have access to your payment card details. By proceeding with payment, you also agree to Paystack's Terms of Service.</p>
              <p>Unless otherwise stated in the Order Confirmation:</p>
              <ul>
                <li>Full payment is required before work commences on development projects valued under ₦500,000.</li>
                <li>Projects valued at ₦500,000 or above require a 50% non-refundable deposit before commencement, with the balance due upon delivery of the final deliverable and before handover.</li>
                <li>Domain registration and hosting fees are payable in full and in advance for the selected subscription period.</li>
                <li>Music distribution carries <strong>no upfront subscription fee</strong>. The Company retains <strong>15%</strong> of all royalties earned, with <strong>85%</strong> remitted to the Artist. Royalties are remitted in accordance with the payment schedule communicated at the time of registration.</li>
              </ul>
              <p>Where applicable under the Value Added Tax Act (as amended) of Nigeria, VAT will be added to the invoice amount and is the responsibility of the Client.</p>
              <p>Invoices unpaid after 7 days of the due date may incur a late payment fee of 5% per month on the outstanding balance. The Company may suspend services or withhold deliverables pending clearance of outstanding balances.</p>
            </>
          ),
        },
        {
          heading: "7. Client Obligations",
          content: (
            <>
              <p>You agree to:</p>
              <ul>
                <li>Provide accurate, complete, and timely information, materials, and feedback required for the Company to perform the services.</li>
                <li>Ensure that any content, images, trademarks, or other materials supplied to the Company do not infringe the intellectual property rights, privacy rights, or any other rights of third parties.</li>
                <li>Respond to requests for approval or feedback within the timeframe specified in the Order Confirmation. Delays caused by Client non-responsiveness will extend project timelines accordingly and do not entitle the Client to a refund or price reduction.</li>
                <li>Not use our services to create, distribute, or promote content that is unlawful, defamatory, obscene, fraudulent, or that violates any applicable law.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "8. Delivery and Timelines",
          content: (
            <>
              <p>Project timelines are estimates provided in good faith based on information available at the time of the Order Confirmation. The Company will use reasonable efforts to meet agreed timelines.</p>
              <p>The Company shall not be liable for delays arising from: (a) late or incomplete provision of materials or information by the Client; (b) Client-requested changes to scope after commencement; (c) force majeure events (see Clause 21); (d) third-party service dependencies outside the Company's reasonable control (e.g., domain registrar processing times, payment gateway issues, app store review periods).</p>
              <p>Where a material delay attributable to the Company occurs, the Client's sole remedy shall be an extension of the delivery timeline, unless otherwise agreed in writing.</p>
            </>
          ),
        },
        {
          heading: "9. Intellectual Property Rights",
          content: (
            <>
              <p><strong>Client-supplied materials:</strong> You retain all intellectual property rights in any content, data, logos, trade marks, images, or other materials you provide to the Company. You grant the Company a non-exclusive, royalty-free licence to use such materials solely for the purpose of delivering the contracted services.</p>
              <p><strong>Deliverables:</strong> Upon receipt of full and final payment, all intellectual property rights in the bespoke deliverables produced specifically for the Client (including source code, design files, and written content) vest in and are assigned to the Client.</p>
              <p><strong>Pre-existing IP and third-party components:</strong> Deliverables may incorporate pre-existing IP owned by the Company (including frameworks, libraries, templates, and proprietary tools) or open-source/third-party components licensed under their respective terms. The Company retains all rights in its pre-existing IP and grants the Client a non-exclusive, perpetual, royalty-free licence to use such components as incorporated in the deliverable. Open-source licences pass through to the Client in accordance with their original terms.</p>
              <p><strong>Portfolio licence:</strong> Unless the Client notifies the Company in writing prior to project completion, the Company retains the right to display the deliverables in its portfolio, marketing materials, and social media, crediting the Client as appropriate.</p>
              <p><strong>Trade marks:</strong> "NAZY EMPIRE" and "NAZY EMPIRE DIGITAL" are trade names of the Company. Nothing in these Terms grants you any right to use these names or marks.</p>
            </>
          ),
        },
        {
          heading: "10. Digital Music Distribution Agreement",
          content: (
            <>
              <p>This section constitutes the binding Digital Music Distribution Agreement ("Distribution Agreement") between NAZY EMPIRE DIGITAL ("the Distributor") and any individual or entity ("Artist", "you") who submits recorded music through our platform for distribution. By submitting a release, you agree to be bound by this Distribution Agreement in addition to all other provisions of these Terms.</p>

              <h3>10.1 Grant of Rights</h3>
              <p>By submitting a release, you grant NAZY EMPIRE DIGITAL an <strong>exclusive, worldwide, royalty-bearing licence</strong> to:</p>
              <ul>
                <li>Deliver, transmit, encode, and store your recordings to Digital Service Providers (DSPs) including but not limited to Spotify, Apple Music, Amazon Music, YouTube Music, Boomplay, Audiomack, Tidal, Deezer, Pandora, TikTok, and any other platform we operate on at the time of submission;</li>
                <li>Authorise DSPs to stream, sell, synchronise, and otherwise exploit the recordings in any digital format now known or hereafter developed;</li>
                <li>Collect, receive, and account for all royalties, revenues, and other monies generated from such exploitation;</li>
                <li>Use your name, likeness, artist name, biographical information, and cover artwork solely for the purpose of marketing and distributing the release.</li>
              </ul>
              <p>This licence is <strong>exclusive for the purpose of digital distribution only</strong>. You retain full ownership and copyright in the recordings and underlying compositions at all times. Nothing in this licence transfers copyright or any ownership rights to the Distributor.</p>
              <p>You represent and warrant that you hold or have secured all necessary rights, clearances, licences, and permissions to grant the above licence, including rights in the master recording, the underlying musical composition, any samples used, and any featured artist performances.</p>

              <h3>10.2 Territory and Duration</h3>
              <p>The licence granted under Clause 10.1 applies <strong>worldwide</strong> — across all territories and countries in which the DSPs operate, without geographic restriction.</p>
              <p>The licence commences on the date your release is submitted and accepted by the Distributor and continues in full force until you submit a valid takedown request in accordance with Clause 10.4 below and all DSPs have confirmed removal of the release. The Distributor will use commercially reasonable efforts to effect removal, but cannot guarantee precise timing as each DSP operates on its own content management schedule.</p>
              <p>Termination of the distribution licence does not extinguish any accrued royalty obligation. Royalties earned on streams or sales that occurred before the effective takedown date remain payable to you in accordance with Clause 10.3, even after the release is removed from all platforms.</p>

              <h3>10.3 Royalties, Payout Terms, and Accounting</h3>
              <p>The Company operates on a <strong>revenue-share model</strong>. The royalty split is as follows:</p>
              <ul>
                <li><strong>Artist share: 85%</strong> of all net royalties received by the Distributor from DSPs in respect of your releases.</li>
                <li><strong>Distributor share: 15%</strong> retained by NAZY EMPIRE DIGITAL as a platform and distribution fee. There are no other deductions.</li>
              </ul>
              <p>"Net royalties" means the gross amounts received by the Distributor from DSPs after deduction of any mandatory withholding taxes, currency conversion fees, or DSP-imposed administrative charges. The Distributor will make reasonable efforts to minimise such deductions.</p>
              <p><strong>Accounting and reporting:</strong> The Distributor will update your royalty balance in your artist dashboard as royalties are received from each DSP. DSPs typically report and remit on a monthly or quarterly cycle, with a processing lag of approximately 2–3 months from the stream or sale date. The Distributor is not responsible for delays in reporting caused by DSP schedules.</p>
              <p><strong>Payout threshold:</strong> Royalty withdrawals become available once your accrued balance reaches a minimum of <strong>₦10,000 (ten thousand Naira)</strong>. Balances below this threshold carry forward to the next accounting period without expiry. Withdrawal requests are processed within 7–14 business days of submission to your nominated Nigerian bank account or other approved payment method.</p>
              <p><strong>Withholding and set-off:</strong> The Distributor reserves the right to withhold royalty payments where: (a) there is a pending copyright infringement claim or dispute concerning your release; (b) your account is under investigation for fraudulent streaming activity under Clause 11; or (c) an outstanding balance is owed by you to the Distributor. Withheld amounts will be released or forfeited upon resolution of the relevant matter in accordance with these Terms.</p>

              <h3>10.4 Takedown Policy and Release Removal</h3>
              <p>You have the right to request removal of your release from distribution at any time. Takedown requests must be submitted as follows:</p>
              <ol>
                <li><strong>Submit a written takedown request</strong> to <a href="mailto:info@nazyempire.com">info@nazyempire.com</a> with the subject line <strong>"TAKEDOWN REQUEST – [Artist Name] – [Release Title]"</strong>. Include your registered account email address, the release title, UPC/ISRC codes if known, and the reason for removal.</li>
                <li>The Distributor will <strong>acknowledge your request within 3 business days</strong>.</li>
                <li>The Distributor will <strong>submit the removal order to all relevant DSPs within 7 business days</strong> of acknowledgement.</li>
                <li>Complete removal from all DSPs typically takes <strong>14 days or more</strong> from the date of acknowledgement, as each platform operates on its own content management schedule. Some platforms with catalogue caching systems may take up to 30 days or longer. The Distributor has no control over individual DSP processing times.</li>
                <li>The Distributor will notify you by email once it receives confirmation from major DSPs that the release has been removed. Minor or regional platforms may update on a further delayed basis outside the Distributor's reasonable control.</li>
              </ol>
              <p>Royalties earned on streams or sales up to the effective takedown date remain payable to you and are not affected by the takedown request.</p>
              <p>The Distributor may also initiate an <strong>emergency takedown</strong> of any release — without prior notice to the Artist — where required by law, by a DSP, or in response to a valid third-party copyright infringement notice. In such cases, the Artist will be notified as soon as reasonably practicable, and Clause 11 or the DMCA Policy (as applicable) will govern the consequences.</p>
            </>
          ),
        },
        {
          heading: "11. Anti-Fraud and Artificial Streaming Policy",
          content: (
            <>
              <p>The integrity of streaming data is fundamental to the Distributor's relationships with DSPs and to the fairness of royalty payouts across the platform. Streaming fraud — including but not limited to the use of bots, click farms, stream-ripping loops, automated playback scripts, playlist manipulation, or any other method to artificially inflate stream counts, play counts, save counts, or listener numbers — is <strong>strictly prohibited</strong> and constitutes a material breach of these Terms.</p>

              <h3>11.1 Prohibited Conduct</h3>
              <p>The following activities are expressly prohibited in connection with any release distributed through NAZY EMPIRE DIGITAL:</p>
              <ul>
                <li>Using bots, automated scripts, click farms, or any artificial means to generate streams, plays, downloads, saves, or follows;</li>
                <li>Paying, incentivising, or organising individuals or services to stream your music in exchange for compensation or reciprocal streaming;</li>
                <li>Creating or using fake listener accounts, fake playlists, or fake follower profiles to manipulate algorithmic discovery or chart placement;</li>
                <li>Engaging in "stream farming" — looping a track repeatedly from a single or limited number of devices — to artificially inflate play counts;</li>
                <li>Misrepresenting the geographic origin of streams or otherwise manipulating territory-specific royalty rates;</li>
                <li>Any other activity designed to defraud DSPs, the Distributor, or other artists of legitimate royalty income.</li>
              </ul>

              <h3>11.2 Detection and Account Consequences</h3>
              <p>DSPs including Spotify and Apple Music actively monitor for and flag fraudulent streaming activity. Where a DSP notifies the Distributor of suspected fraud, flags, removes, or reduces royalties associated with your release, the Distributor may, at its sole discretion:</p>
              <ul>
                <li><strong>Immediately freeze all royalty payouts</strong> from your account, pending investigation;</li>
                <li><strong>Remove the affected release(s) from all platforms</strong> without prior notice to you;</li>
                <li><strong>Permanently terminate your artist account</strong> and all associated releases with immediate effect;</li>
                <li><strong>Forfeit your entire outstanding royalty balance</strong> where the investigation determines that any portion of the accrued balance was derived from fraudulent streams. Forfeited balances will not be returned.</li>
              </ul>

              <h3>11.3 Artist Liability for DSP Fines and Penalties</h3>
              <p>You are <strong>solely and personally liable</strong> for any fines, penalties, chargebacks, content takedowns, or other sanctions imposed on NAZY EMPIRE DIGITAL by any DSP or regulatory body as a direct or indirect result of fraudulent streaming activity originating from or associated with your account or releases. You agree to <strong>fully indemnify and hold harmless</strong> NAZY EMPIRE DIGITAL and its officers, employees, and agents from and against any such losses, costs, and reasonable legal fees, without limitation of amount. This indemnity survives the termination of your account and the removal of any release.</p>

              <h3>11.4 No Liability for DSP Royalty Adjustments</h3>
              <p>Where a DSP retroactively adjusts, deducts, or reverses royalty payments on the grounds of suspected fraudulent activity — whether or not fraud is ultimately proven — the Distributor is not liable to you for any resulting shortfall in royalties, even where the Distributor has previously credited a provisional balance to your dashboard. The Distributor reserves the right to deduct previously credited provisional amounts from your future earnings or to demand immediate repayment of any over-disbursed amounts.</p>
            </>
          ),
        },
        {
          heading: "12. Web Hosting — Host Liability, Acceptable Use Policy, and Safe Harbour",
          content: (
            <>
              <p>This section governs all web hosting services provided by NAZY EMPIRE DIGITAL, including shared hosting, VPS hosting, email hosting, and any associated managed services. By activating a hosting plan, you agree to this policy in full.</p>

              <h3>12.1 Client Responsibility for Hosted Content</h3>
              <p>You are <strong>solely and exclusively responsible</strong> for all content, data, software, scripts, and applications you upload, install, or publish on the server space allocated to you. NAZY EMPIRE DIGITAL does not proactively monitor the content of hosted websites but reserves the right to do so for abuse prevention and legal compliance purposes.</p>

              <h3>12.2 Acceptable Use Policy (AUP)</h3>
              <p>You must not use your hosting account to host, store, transmit, or distribute any of the following:</p>
              <ul>
                <li><strong>Phishing and fraud infrastructure</strong> — including phishing pages, credential-harvesting forms, fake login portals, advance-fee fraud ("419") content, or any website designed to deceive or defraud individuals;</li>
                <li><strong>Malware and attack tools</strong> — including malicious scripts, ransomware, spyware, trojans, DDoS amplification tools, spam relays, or any software designed to compromise third-party systems;</li>
                <li><strong>Copyright-infringing material</strong> — including pirated software, unlicensed music files, cracked applications, torrent indexing sites, or any content that reproduces protected works without licence. This includes music blogs, stream-ripping tools, or MP3 download portals;</li>
                <li><strong>Adult and obscene content</strong> — unless the Client has received prior written authorisation from NAZY EMPIRE DIGITAL and complies with all applicable laws governing such content;</li>
                <li><strong>Illegal content under Nigerian or applicable international law</strong> — including content that incites violence, promotes terrorism, discriminates on prohibited grounds, or violates the Cybercrimes (Prohibition, Prevention, Etc.) Act 2015 of Nigeria;</li>
                <li><strong>Resource abuse</strong> — running cryptocurrency mining scripts, automated crawlers, bulk email senders, or any process that monopolises server CPU, memory, or bandwidth beyond what is reasonable for your hosting plan.</li>
              </ul>

              <h3>12.3 Right to Suspend and Terminate</h3>
              <p>NAZY EMPIRE DIGITAL reserves the absolute right to <strong>immediately suspend or terminate a hosting account — without prior notice — where:</strong></p>
              <ul>
                <li>The hosted website or application is found or credibly reported to contain phishing pages, malware, spam infrastructure, or any content that poses an active security risk to third parties or the Company's infrastructure;</li>
                <li>A valid copyright takedown notice is received in respect of hosted content and the Client does not respond within 24 hours of notification;</li>
                <li>The account is engaging in resource abuse that affects the performance of other clients on shared infrastructure;</li>
                <li>The hosted content is deemed unlawful under Nigerian law or the laws of any jurisdiction to which the Company is subject;</li>
                <li>A government authority, law enforcement agency, or court issues an instruction, notice, or order requiring suspension or removal of content.</li>
              </ul>
              <p>Suspension does not waive any outstanding payment obligations. The Company may terminate the account and delete all associated data after 7 days of unresolved suspension for cause, with no obligation to retain or restore data. The Company is not liable for data loss resulting from a suspension or termination carried out under this clause.</p>

              <h3>12.4 DMCA Safe Harbour and Abuse Agent</h3>
              <p>NAZY EMPIRE DIGITAL operates as a hosting provider and qualifies for safe harbour protection under the United States <strong>Digital Millennium Copyright Act (DMCA), 17 U.S.C. § 512</strong>, and equivalent protections under international e-commerce frameworks, subject to compliance with the notice-and-takedown process described in our <a href="/dmca">DMCA Policy</a>.</p>
              <p>To notify us of copyright-infringing content hosted on our servers, submit a valid takedown notice to our designated Abuse and Copyright Agent:</p>
              <p><strong>Abuse / Copyright Agent — NAZY EMPIRE DIGITAL</strong><br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a><br />
              Subject line: <strong>DMCA TAKEDOWN NOTICE</strong> or <strong>ABUSE REPORT</strong></p>
              <p>We will acknowledge valid notices within 3 business days and act to remove or disable access to confirmed infringing content as quickly as practicable. Safe harbour protection is contingent on the Company acting expeditiously upon receipt of valid notices — which we are committed to doing. Our full DMCA notice and counter-notification procedure is set out in our <a href="/dmca">DMCA Notice &amp; Takedown Policy</a>.</p>

              <h3>12.5 No Liability for Third-Party Hosted Content</h3>
              <p>The Company is not responsible for the content, legality, accuracy, or suitability of any website, application, or data hosted on your behalf. You agree to fully indemnify and hold harmless NAZY EMPIRE DIGITAL and its proprietor, employees, and agents from and against any and all claims, liabilities, costs, damages, and expenses (including legal fees) brought by any third party arising from or in connection with content you host on our infrastructure.</p>
            </>
          ),
        },
        {
          heading: "13. Web Development — Service Warranty, Liability Cap, and Third-Party Software",
          content: (
            <>
              <p>This section applies to all website and application development engagements ("Development Projects") undertaken by NAZY EMPIRE DIGITAL for clients. It supplements the general provisions in Clauses 8 (Delivery), 9 (Intellectual Property), and 18 (Limitation of Liability).</p>

              <h3>13.1 Limitation of Liability to Contract Value</h3>
              <p>For Development Projects, the Company's total aggregate liability to you for any claim — including claims for breach of contract, negligence, errors and omissions, or any other cause — shall not, under any circumstances, exceed the <strong>total amount paid by you to the Company for the specific Development Project</strong> giving rise to the claim. This cap applies regardless of the nature of the claim or the form of action.</p>
              <p>In particular, the Company shall not be liable for any <strong>consequential or economic loss</strong> claimed to have arisen from a website or application being unavailable, malfunctioning, or delayed — including but not limited to loss of sales, loss of business opportunities, loss of customers, loss of revenue, or reputational harm. If a website you commissioned goes offline or fails to function as expected for any period, your claim is capped at the contract value, not at any economic losses you assert during that period.</p>

              <h3>13.2 Post-Launch Bug Fix Warranty</h3>
              <p>The Company provides a <strong>30-day limited warranty</strong> following the date on which the completed deliverable is handed over to the Client or made live ("Launch Date"). During this warranty period, the Company will rectify, at no additional charge, any defect or malfunction in the deliverable that: (a) is attributable to the Company's own code or implementation; (b) was not caused by Client modifications, third-party interference, or changes to the hosting environment; and (c) is reported to us in writing within the 30-day period.</p>
              <p><strong>After the 30-day warranty period</strong>, all maintenance, updates, modifications, or bug fixes — however caused — require a <strong>separate paid maintenance agreement or project instruction</strong>. Requests for post-warranty fixes will be quoted and invoiced at the Company's standard rates at the time of the request.</p>
              <p>The warranty does not cover: (a) changes you or a third party make to the deliverable after handover; (b) issues arising from changes to third-party APIs, platforms, or external services the deliverable integrates with; (c) issues caused by your hosting environment, server configuration, or ISP; (d) feature requests or scope changes presented as bugs.</p>

              <h3>13.3 Third-Party Software, Plugins, and APIs</h3>
              <p>Development deliverables routinely incorporate <strong>third-party software components</strong>, including content management systems (e.g. WordPress), themes, plugins, packages, frameworks, libraries, and external APIs. You acknowledge and agree that:</p>
              <ul>
                <li>The Company is <strong>not responsible</strong> for the ongoing maintenance, security, or availability of any third-party software, plugin, API, or service after handover. If a third-party developer ceases to update or support a plugin, or if a security vulnerability is discovered in an external tool after handover, remediation is not covered by the Company's obligations under the original contract;</li>
                <li>API availability and performance are controlled by third-party providers (e.g. payment gateways, mapping services, social media platforms). The Company cannot guarantee that such APIs will remain available, free, or functionally compatible with your application indefinitely;</li>
                <li>Open-source and third-party licences incorporated into the deliverable are passed through to you in accordance with their original terms. You are responsible for ongoing licence compliance after handover;</li>
                <li>The Company recommends that you maintain a paid maintenance contract to ensure timely updates to third-party components. The Company accepts no liability for security breaches, data loss, or service failures arising from unpatched or outdated third-party components after the project handover date.</li>
              </ul>
            </>
          ),
        },
        {
          heading: "14. Domain Registration — UDRP, Trademark Disputes, and WHOIS Privacy",
          content: (
            <>
              <p>This section applies where NAZY EMPIRE DIGITAL registers, transfers, or manages domain names on your behalf, whether as a direct registrar or through an upstream accredited registrar or reseller channel.</p>

              <h3>14.1 Client Responsibility for Domain Selection</h3>
              <p>You are solely responsible for the domain name(s) you choose to register. By requesting registration of a domain name, you represent and warrant that: (a) the registration and use of the domain name does not infringe the trademark, trade name, or other intellectual property rights of any third party; (b) you have not selected the domain in bad faith to profit from, traffic on, or disparage any third-party brand or mark; and (c) you will use the domain for lawful purposes only.</p>

              <h3>14.2 ICANN UDRP Pass-Through</h3>
              <p>All generic top-level domain (gTLD) registrations are subject to the <strong>ICANN Uniform Domain-Name Dispute-Resolution Policy (UDRP)</strong>, which is incorporated into your domain registration by operation of ICANN's Registrar Accreditation Agreement. By completing a domain registration through NAZY EMPIRE DIGITAL, you irrevocably agree to be bound by the UDRP and any applicable dispute resolution procedure for the specific TLD you register.</p>
              <p>Where a trademark owner or other rights holder initiates a UDRP, URS, or equivalent domain dispute proceeding against a domain registered through us, <strong>the dispute is between you (the registrant) and the complainant</strong>. NAZY EMPIRE DIGITAL is not a party to such proceedings and accepts no liability for any domain suspension, transfer, or cancellation resulting from a UDRP or similar proceeding. You agree to indemnify and hold harmless the Company from any costs, losses, or claims arising from domain disputes relating to registrations you have requested.</p>
              <p>The Company is required to comply with the outcome of any UDRP or court order affecting a domain name. Such compliance — including transferring or cancelling a domain as directed — does not constitute a breach of these Terms and carries no right of refund.</p>

              <h3>14.3 WHOIS Privacy and Legal Disclosure</h3>
              <p>Where the Company or its upstream registrar offers <strong>WHOIS domain privacy</strong> (also known as domain privacy protection or privacy proxy service), this service substitutes our or our proxy provider's contact details in place of your personal information in the public WHOIS database, shielding your details from public scrapers and unsolicited contact.</p>
              <p>You expressly acknowledge and agree that WHOIS privacy does <strong>not</strong> provide absolute anonymity, and that the Company is <strong>legally obligated</strong> to disclose your true registrant details to:</p>
              <ul>
                <li>Law enforcement agencies presenting a valid legal notice, court order, or warrant;</li>
                <li>A court of competent jurisdiction pursuant to a lawful order;</li>
                <li>ICANN or the applicable domain registry in accordance with their policies;</li>
                <li>A UDRP provider requiring registrant contact details as part of dispute proceedings.</li>
              </ul>
              <p>The Company accepts no liability for any consequences arising from such mandatory disclosure. WHOIS privacy is a privacy-convenience service only — it is not a means to evade legal process, conceal infringement, or frustrate legitimate legal claims.</p>

              <h3>14.4 No Liability for Domain Disputes or Expiry</h3>
              <p>The Company is not liable for: (a) any loss of a domain name arising from your failure to renew it before the expiry date; (b) a domain being claimed or registered by a third party during any redemption or deletion period following expiry; (c) UDRP transfers or cancellations initiated by third parties; or (d) changes in registry policies, pricing, or availability for specific TLDs. Renewal reminders are a courtesy service and failure to receive or act on a reminder does not create liability for the Company.</p>
            </>
          ),
        },
        {
          heading: "15. Refunds and Cancellations",
          content: (
            <>
              <p>Please also refer to our separate <Link href="/terms-of-sale">Terms of Sale</Link> for detailed refund procedures.</p>
              <ul>
                <li><strong>Development projects (pre-commencement):</strong> Full refund if cancellation is requested within 24 hours of payment and before any work has commenced.</li>
                <li><strong>Development projects (post-commencement):</strong> No refund once work has commenced. Where a Client cancels mid-project, the Company may invoice for work completed to the date of cancellation.</li>
                <li><strong>Domain registration:</strong> No refund once the domain has been registered with the registry, as registration fees are passed directly to the registry.</li>
                <li><strong>Hosting:</strong> Pro-rata refund for unused complete months may be considered at the Company's sole discretion, minus a ₦5,000 administration fee. No refund for the first month.</li>
                <li><strong>Music distribution:</strong> No upfront fee is charged; therefore no monetary refund applies. Artists may request release removal under the takedown procedure in Clause 10.4. The Anti-Fraud Policy in Clause 11 governs forfeiture of royalty balances in cases of streaming fraud.</li>
              </ul>
              <p>All refund requests must be made in writing to <a href="mailto:info@nazyempire.com"><strong>info@nazyempire.com</strong></a> with full details of the order and the grounds for the request.</p>
            </>
          ),
        },
        {
          heading: "16. Confidentiality",
          content: (
            <>
              <p>Each party agrees to keep confidential any proprietary or non-public information disclosed by the other party in connection with the services ("Confidential Information") and not to disclose such information to any third party without prior written consent, except where required by applicable law or court order.</p>
              <p>This obligation does not apply to information that: (a) is or becomes publicly known through no breach of this clause; (b) was already known to the receiving party prior to disclosure; or (c) is independently developed by the receiving party without use of the Confidential Information.</p>
            </>
          ),
        },
        {
          heading: "17. Warranties and Disclaimer",
          content: (
            <>
              <p>The Company warrants that services will be performed with reasonable skill and care in accordance with industry standards.</p>
              <p><strong>EXCEPT AS EXPRESSLY STATED IN THESE TERMS, ALL SERVICES AND DELIVERABLES ARE PROVIDED "AS IS" AND "AS AVAILABLE". TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, THE COMPANY DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.</strong></p>
              <p>The Company does not warrant that: (a) services will be uninterrupted or error-free; (b) third-party platforms, registrars, or payment gateways will perform as expected; (c) any website or application will achieve specific search engine rankings or business outcomes.</p>
            </>
          ),
        },
        {
          heading: "18. Limitation of Liability",
          content: (
            <>
              <p><strong>TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW:</strong></p>

              <h3>18.1 General Cap</h3>
              <p>The Company's total aggregate liability to you for any and all claims arising under or in connection with these Terms — regardless of the form of action, whether in contract, tort (including negligence), statute, or otherwise — shall not exceed the <strong>total amount actually paid by you to the Company for the specific service giving rise to the claim in the 12 months immediately preceding the event giving rise to the claim</strong>. Where you have paid nothing (e.g. as a music distribution artist on the revenue-share model), the Company's maximum aggregate liability to you is <strong>zero naira (₦0)</strong>, except as provided in Clause 18.3.</p>

              <h3>18.2 Service-Specific Liability Caps</h3>
              <ul>
                <li><strong>Web Development:</strong> Liability is capped at the <strong>exact total contract value paid</strong> for the specific Development Project, as set out in Clause 13.1. The Company is not liable for consequential economic losses arising from website unavailability or malfunction.</li>
                <li><strong>Web Hosting:</strong> Liability is capped at the <strong>total hosting fees paid in the 6 months preceding the claim</strong>. The Company is not liable for lost data, lost revenue, or business interruption arising from hosting suspension, outage, or termination under Clause 12.</li>
                <li><strong>Domain Registration:</strong> Liability is capped at the <strong>registration or renewal fee paid</strong> for the specific domain. The Company is not liable for loss of a domain name resulting from expiry, UDRP proceedings, or registry actions.</li>
                <li><strong>Music Distribution (Artist):</strong> Artists use the distribution service at no upfront fee. The Company's maximum aggregate liability to any Artist for any claim relating to the distribution of their recordings — including disputes over royalty calculation, payout delay, or takedown timing — is <strong>capped at the total royalties actually received and credited to the Artist's dashboard in the 6 months preceding the claim</strong>, not the gross earnings on any streaming platform.</li>
              </ul>

              <h3>18.3 Exclusion of Consequential Loss</h3>
              <p>The Company shall not be liable — under any circumstances — for any <strong>indirect, incidental, special, consequential, or punitive damages</strong>, including but not limited to: loss of profits, loss of revenue, loss of data, loss of goodwill, loss of business opportunity, business interruption, reputational harm, or the cost of procuring substitute services. This exclusion applies even if the Company has been advised of the possibility of such damages.</p>

              <h3>18.4 Excluded Grounds</h3>
              <p>The Company shall not be liable for any claim arising from: (i) your breach of these Terms; (ii) your negligence, fraud, or wilful misconduct; (iii) the acts or omissions of third-party platforms, DSPs, registrars, plugin developers, or payment processors; (iv) your failure to maintain adequate backups of your data; or (v) force majeure events under Clause 21.</p>

              <h3>18.5 Savings</h3>
              <p>Nothing in these Terms limits or excludes liability for: (a) death or personal injury caused by the Company's negligence; (b) fraud or fraudulent misrepresentation; or (c) any other liability that cannot be limited or excluded under applicable Nigerian law.</p>
            </>
          ),
        },
        {
          heading: "19. Indemnification",
          content: (
            <>
              <p>You agree to indemnify, defend, and hold harmless NAZY EMPIRE DIGITAL, its proprietor, employees, contractors, and agents from and against any and all claims, damages, losses, liabilities, costs, and expenses (including reasonable legal fees and disbursements) arising out of or relating to: (a) your use of the services; (b) your breach of any provision of these Terms; (c) any content or materials you provide to the Company; (d) your infringement of any third-party intellectual property, privacy, or other rights; or (e) your violation of any applicable law or regulation.</p>

              <h3>19.1 Artist IP Indemnification (Non-Negotiable)</h3>
              <p>This clause is a <strong>non-negotiable condition</strong> of using the music distribution service. By submitting any recording for distribution, you warrant that you own or have fully licensed all rights in that recording — including the master recording, all underlying musical compositions, all samples, interpolations, guest artist performances, and producer contributions — and that distributing the recording will not infringe the copyright, moral rights, or any other rights of any third party.</p>
              <p>If any third party brings or threatens any claim, demand, action, proceeding, or legal process against NAZY EMPIRE DIGITAL arising from or in connection with your recording — including copyright infringement claims, takedown demands, DSP penalties, or regulatory proceedings — you agree to:</p>
              <ul>
                <li><strong>Fully indemnify</strong> NAZY EMPIRE DIGITAL for all resulting losses, damages, settlements, fines, and penalties;</li>
                <li><strong>Pay all reasonable legal fees and disbursements</strong> incurred by NAZY EMPIRE DIGITAL in investigating, defending, or settling the claim, including solicitor's fees, expert fees, and court costs;</li>
                <li><strong>Reimburse all operational losses</strong> suffered by NAZY EMPIRE DIGITAL as a direct result of the infringement, including DSP-imposed deductions, chargebacks, account suspensions, and reputational remediation costs.</li>
              </ul>
              <p>This indemnity is unlimited in amount. It is not capped by the general Limitation of Liability in Clause 18. It applies whether or not the infringement was intentional. It survives the termination of your account and the removal of any release from distribution.</p>

              <h3>19.2 Web Hosting Indemnification</h3>
              <p>Where you use NAZY EMPIRE DIGITAL's hosting services, you agree to indemnify the Company against all claims, costs, and legal fees arising from content you host on our infrastructure that is found to be unlawful, infringing, or in breach of this Acceptable Use Policy in Clause 12. This indemnity applies regardless of whether NAZY EMPIRE DIGITAL was notified of the content prior to the claim arising.</p>

              <h3>19.3 Right to Control Defence</h3>
              <p>NAZY EMPIRE DIGITAL reserves the right, at its election, to assume sole control of the defence of any claim to which Clause 19.1 or 19.2 applies, including the choice of legal counsel and any settlement negotiations. You agree to cooperate fully with the Company's defence and not to take any action or make any admission that could prejudice the Company's position. Any settlement by you of a claim affecting NAZY EMPIRE DIGITAL requires the Company's prior written consent.</p>
            </>
          ),
        },
        {
          heading: "20. Acceptable Use",
          content: (
            <>
              <p>You agree not to use the Company's services to:</p>
              <ul>
                <li>Violate any applicable local, national, or international law or regulation.</li>
                <li>Infringe any intellectual property, privacy, or other third-party rights.</li>
                <li>Transmit or distribute malware, spyware, viruses, or other harmful code.</li>
                <li>Conduct phishing, spamming, or any other fraudulent activity.</li>
                <li>Circumvent, disable, or interfere with security features of the website or our systems.</li>
                <li>Engage in any activity that unreasonably burdens the Company's infrastructure.</li>
                <li>Reproduce, duplicate, copy, sell, or exploit any portion of the website without the Company's express written consent.</li>
              </ul>
              <p>Violation of this clause may result in immediate termination of services without refund and may be reported to the relevant authorities.</p>
            </>
          ),
        },
        {
          heading: "21. Force Majeure",
          content: (
            <p>Neither party shall be in breach of these Terms or liable for any delay or failure to perform any obligation under these Terms if such delay or failure results from circumstances beyond that party's reasonable control, including but not limited to acts of God, governmental actions, war, civil unrest, fire, flood, pandemic, power outages, internet disruption, or failure of third-party services. The affected party shall give prompt written notice to the other party and use reasonable efforts to mitigate the impact of the force majeure event.</p>
          ),
        },
        {
          heading: "22. Governing Law and Dispute Resolution",
          content: (
            <>
              <p>These Terms shall be governed by and construed in accordance with the laws of the <strong>Federal Republic of Nigeria</strong>, without regard to its conflict of law provisions.</p>
              <p><strong>Informal resolution:</strong> In the event of any dispute, the parties agree to first attempt resolution through good-faith negotiation. Either party may initiate this process by sending written notice to the other describing the dispute and the resolution sought. The parties shall have 30 days from receipt of such notice to resolve the dispute informally.</p>
              <p><strong>Arbitration:</strong> If the dispute is not resolved informally within 30 days, it shall be referred to and finally resolved by arbitration in Lagos, Nigeria, under the Arbitration and Mediation Act 2023 of Nigeria, with a single arbitrator agreed upon by the parties or, failing agreement, appointed by the Lagos Court of Arbitration. The arbitration shall be conducted in English. The arbitrator's award shall be final and binding.</p>
              <p><strong>Courts:</strong> Notwithstanding the foregoing, either party may seek emergency injunctive or other equitable relief from a court of competent jurisdiction in Lagos State without prejudice to the right to arbitrate. Subject thereto, the parties irrevocably submit to the exclusive jurisdiction of the courts of Lagos State, Nigeria.</p>
            </>
          ),
        },
        {
          heading: "23. Privacy",
          content: (
            <p>Your use of our services is also governed by our <Link href="/privacy">Privacy Policy</Link> and <Link href="/cookie-policy">Cookie Policy</Link>, which are incorporated into these Terms by reference.</p>
          ),
        },
        {
          heading: "24. Modifications to Terms",
          content: (
            <p>The Company reserves the right to amend these Terms at any time. Material changes will be notified to registered users by email and/or by a prominent notice on the website at least 14 days before taking effect. Your continued use of the services after the effective date of any changes constitutes your acceptance of the revised Terms. If you do not accept the revised Terms, you must stop using the services and notify us in writing.</p>
          ),
        },
        {
          heading: "25. Severability",
          content: (
            <p>If any provision of these Terms is held to be invalid, unlawful, or unenforceable under applicable law, that provision shall be severed from these Terms and shall not affect the validity or enforceability of the remaining provisions, which shall continue in full force and effect.</p>
          ),
        },
        {
          heading: "26. Entire Agreement",
          content: (
            <p>These Terms, together with any Order Confirmation, Service Agreement, Privacy Policy, Cookie Policy, and Terms of Sale, constitute the entire agreement between you and the Company with respect to the subject matter hereof and supersede all prior agreements, representations, and understandings of any kind, whether written or oral.</p>
          ),
        },
        {
          heading: "27. Contact",
          content: (
            <>
              <p>For questions, complaints, or legal notices under these Terms, please contact:</p>
              <p><strong>NAZY EMPIRE DIGITAL</strong><br />
              CAC BN 9657494<br />
              Enugu, Nigeria<br />
              Email: <a href="mailto:info@nazyempire.com">info@nazyempire.com</a></p>
            </>
          ),
        },
      ]}
    />
  );
}
