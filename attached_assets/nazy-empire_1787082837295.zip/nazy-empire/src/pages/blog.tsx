import { useEffect, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Calendar, Tag, ArrowRight, BookOpen, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { api, type BlogPost } from "@/lib/api";

function formatDate(d: string | null | undefined) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-NG", { year: "numeric", month: "long", day: "numeric" });
}

function CategoryBadge({ category }: { category?: string | null }) {
  if (!category) return null;
  return (
    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium">
      <Tag className="w-3 h-3" />
      {category}
    </span>
  );
}

export default function Blog() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    document.title = "Blog | Nazy Empire — Digital Insights & Industry News";
    const desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute("content", "Expert insights on music distribution, web development, domain registration, and web hosting from Africa's leading digital company.");

    api.blog.list().then(setPosts).catch(() => setPosts([])).finally(() => setLoading(false));
    return () => { document.title = "Nazy Empire"; };
  }, []);

  const [featured, ...rest] = posts;

  return (
    <div className="min-h-screen bg-black">
      {/* Hero */}
      <section className="relative pt-28 pb-16 bg-gradient-to-b from-zinc-950 to-black border-b border-white/5">
        <div className="container mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
              <BookOpen className="w-4 h-4" /> The Nazy Empire Blog
            </span>
            <h1 className="font-display text-5xl md:text-7xl text-white mb-4">BLOG &amp; INSIGHTS</h1>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">
              Expert knowledge on music distribution, web development, hosting, domains, and Africa's digital economy.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16 container mx-auto px-4">
        {loading && (
          <div className="flex justify-center py-24">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        {!loading && posts.length === 0 && (
          <div className="text-center py-24 text-white/40">
            <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p className="text-lg">No posts yet — check back soon.</p>
          </div>
        )}

        {!loading && featured && (
          <>
            {/* Featured post */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-14"
            >
              <p className="text-primary text-xs font-semibold uppercase tracking-widest mb-4">Featured Post</p>
              <Link href={`/blog/${featured.slug}`}>
                <div className="group grid grid-cols-1 lg:grid-cols-2 gap-0 bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/40 transition-colors cursor-pointer">
                  {featured.featuredImage ? (
                    <div className="relative h-72 lg:h-full overflow-hidden bg-zinc-900">
                      <img
                        src={featured.featuredImage}
                        alt={featured.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  ) : (
                    <div className="h-72 lg:h-full bg-gradient-to-br from-primary/10 to-zinc-900 flex items-center justify-center">
                      <BookOpen className="w-16 h-16 text-primary/20" />
                    </div>
                  )}
                  <div className="p-8 flex flex-col justify-center">
                    <CategoryBadge category={featured.category} />
                    <h2 className="font-display text-3xl text-white mt-3 mb-3 group-hover:text-primary transition-colors">
                      {featured.title}
                    </h2>
                    {featured.excerpt && (
                      <p className="text-white/50 leading-relaxed mb-6 line-clamp-3">{featured.excerpt}</p>
                    )}
                    <div className="flex items-center gap-4 text-white/30 text-sm mb-6">
                      <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" />{featured.author || "Nazy Empire"}</span>
                      <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />{formatDate(featured.publishedAt)}</span>
                    </div>
                    <span className="flex items-center gap-2 text-primary font-semibold text-sm">
                      Read Article <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>

            {/* Rest of posts */}
            {rest.length > 0 && (
              <div>
                <h2 className="font-display text-2xl text-white mb-8">MORE ARTICLES</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {rest.map((post, i) => (
                    <motion.div
                      key={post.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.08 }}
                    >
                      <Link href={`/blog/${post.slug}`}>
                        <div className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/40 transition-colors h-full cursor-pointer flex flex-col">
                          {post.featuredImage ? (
                            <div className="h-48 overflow-hidden bg-zinc-900">
                              <img
                                src={post.featuredImage}
                                alt={post.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              />
                            </div>
                          ) : (
                            <div className="h-48 bg-gradient-to-br from-primary/10 to-zinc-900 flex items-center justify-center">
                              <BookOpen className="w-10 h-10 text-primary/20" />
                            </div>
                          )}
                          <div className="p-5 flex flex-col flex-1">
                            <CategoryBadge category={post.category} />
                            <h3 className="font-semibold text-white mt-2 mb-2 group-hover:text-primary transition-colors line-clamp-2">
                              {post.title}
                            </h3>
                            {post.excerpt && (
                              <p className="text-white/40 text-sm leading-relaxed mb-4 line-clamp-2 flex-1">{post.excerpt}</p>
                            )}
                            <div className="flex items-center justify-between text-white/30 text-xs mt-auto pt-4 border-t border-border">
                              <span className="flex items-center gap-1"><User className="w-3 h-3" />{post.author || "Nazy Empire"}</span>
                              <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{formatDate(post.publishedAt)}</span>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </section>

      {/* CTA */}
      <section className="py-20 bg-zinc-950 border-t border-white/5">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-4xl md:text-5xl text-white mb-4">READY TO GET STARTED?</h2>
          <p className="text-white/50 mb-8 max-w-xl mx-auto">
            Whether you need a website, domain, hosting, or music distribution — we have you covered.
          </p>
          <Link href="/order">
            <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold px-10">
              Start Your Project <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
