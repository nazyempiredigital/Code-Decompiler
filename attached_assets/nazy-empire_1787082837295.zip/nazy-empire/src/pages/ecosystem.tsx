import { motion } from "framer-motion";
import { Users, Code2, Music2, HeadphonesIcon, Shield, ChevronRight } from "lucide-react";
import { LegalPage } from "@/components/legal-page";

const DEPARTMENTS = [
  {
    icon: Users,
    label: "Executive & Infrastructure Leadership",
    subtitle: "The Vision & Core Tech",
    color: "from-amber-500/20 to-amber-900/10",
    border: "border-amber-500/30",
    iconColor: "text-amber-400",
    roles: [
      {
        title: "FOUNDER",
        growth: "Strategic expansion, brand partnerships, and scaling.",
        impact:
          "As the ultimate decision-maker, your focus is on high-level growth—negotiating direct deals with major DSPs, expanding the infrastructure, driving marketing direction, and ensuring the music and tech wings work seamlessly under one empire.",
      },
      {
        title: "CHIEF TECHNOLOGY OFFICER (CTO)",
        growth: "Technical architecture, server scalability, and data security.",
        impact:
          "Ensures the platform can handle thousands of concurrent users, web hosting nodes, and massive music file uploads without crashing. They map out the technical future of the company and protect user data from breaches.",
      },
      {
        title: "CTO II — Infrastructure & DevOps",
        growth: "Server automation and hosting optimization.",
        impact:
          "Focuses purely on automated provisioning for domain registrations and hosting plans. By ensuring fast loading speeds, zero downtime, and seamless automated scaling, they directly improve hosting client retention.",
      },
      {
        title: "CTO III — Data & Integrations",
        growth: "API integrations and database scaling.",
        impact:
          "Optimizes the massive databases storing user accounts, music metadata, and financial tracking codes. They ensure smooth API communication between the backend, external domain registrars, and digital streaming networks.",
      },
    ],
  },
  {
    icon: Code2,
    label: "Engineering Team",
    subtitle: "Building & Optimizing the Platform",
    color: "from-blue-500/20 to-blue-900/10",
    border: "border-blue-500/30",
    iconColor: "text-blue-400",
    roles: [
      {
        title: "DEVELOPER — Lead Architect / Full-Stack",
        growth: "Feature deployment and core system upgrades.",
        impact:
          "Translates business needs into clean code. They bridge the backend logic with the frontend client dashboard, building new tools that attract premium clients (e.g., custom website builders for artists).",
      },
      {
        title: "DEVELOPER I — Backend Specialist",
        growth: "Backend automation and stability.",
        impact:
          "Works heavily on the backend architecture. They ensure that when an artist submits an album or a client purchases hosting, the underlying data processes flawlessly and securely.",
      },
      {
        title: "DEVELOPER II — Frontend & UI/UX",
        growth: "User interface and checkout funnel optimization.",
        impact:
          "Focuses on making the client dashboard beautifully intuitive. A clean, easy-to-use interface drastically reduces customer drop-off rates during domain registration or music uploading.",
      },
      {
        title: "DEVELOPER III — Mobile / Tools Developer",
        growth: "Developing dedicated apps and utility tools.",
        impact:
          "Expands the company's reach by developing peripheral tools—like a dedicated mobile app for artists to track their streams and web hosting analytics on the go.",
      },
    ],
  },
  {
    icon: Music2,
    label: "Music Operations & Finance",
    subtitle: "Catalog & Financial Growth",
    color: "from-primary/20 to-primary/5",
    border: "border-primary/30",
    iconColor: "text-primary",
    roles: [
      {
        title: "HEAD OF MUSIC OPERATIONS",
        growth: "Catalog monetization and distribution pipeline scaling.",
        impact:
          "Responsible for scaling the volume of distributed music. They handle major distribution issues, ensure fast ingestion times to DSPs, and help pitch independent artists for editorial playlists, which increases the company's streaming market share.",
      },
      {
        title: "CONTENT SPECIALIST",
        growth: "Quality assurance and catalog health.",
        impact:
          "The essential gatekeeper. By thoroughly checking audio quality, cover art, and metadata for streaming guidelines, they prevent platform bans, reduce copyright flags, and keep the company in excellent standing with DSPs.",
      },
      {
        title: "ACCOUNTING SPECIALIST",
        growth: "Royalty split automation and financial trust.",
        impact:
          "Manages complex music streaming royalty payouts (15%/85% split). Fast, transparent, and accurate wallet payouts build industry trust, turning existing clients into the company's biggest promoters.",
      },
    ],
  },
  {
    icon: HeadphonesIcon,
    label: "Frontline Support & Marketing",
    subtitle: "Client Retention & Acquisition",
    color: "from-green-500/20 to-green-900/10",
    border: "border-green-500/30",
    iconColor: "text-green-400",
    roles: [
      {
        title: "TECHNICAL CUSTOMER SUPPORT — Tier 2",
        growth: "Advanced troubleshooting and hosting recovery.",
        impact:
          "Handles technical issues like server configuration, DNS zone edits, and cPanel anomalies. Resolving complex tech problems quickly keeps high-paying business and corporate clients from leaving for competitors.",
      },
      {
        title: "CUSTOMER SUPPORT — Tier 1 / General",
        growth: "Day-to-day client satisfaction and onboarding.",
        impact:
          "Manages live chat and basic ticket queues for both hosting questions and music upload assistance. They ensure new users have a friction-free experience from day one.",
      },
      {
        title: "MARKETER",
        growth: "User acquisition, lead generation, and ad campaigns.",
        impact:
          "The engine behind platform traffic. They run targeted campaigns to attract independent music artists needing distribution, alongside businesses seeking affordable, reliable web hosting and domain registration.",
      },
    ],
  },
  {
    icon: Shield,
    label: "Compliance",
    subtitle: "Legal Protection & Risk Management",
    color: "from-purple-500/20 to-purple-900/10",
    border: "border-purple-500/30",
    iconColor: "text-purple-400",
    roles: [
      {
        title: "COMPLIANCE OFFICER",
        growth: "Legal protection and risk management.",
        impact:
          "Manages DMCA takedowns for the hosting wing and copyright/anti-piracy claims for the music distribution wing. By keeping the platform legally clean, they protect the company from crippling lawsuits and operational shutdowns.",
      },
    ],
  },
];

export default function Ecosystem() {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24 text-center border-b border-white/10">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <span className="inline-block px-4 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
              The People Behind the Empire
            </span>
            <h1 className="font-display text-6xl md:text-7xl text-white mb-4">OUR ECOSYSTEM</h1>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">
              A structured team of specialists across technology, music operations, support, and compliance — each
              playing a critical role in scaling Nazy Empire into Africa's leading digital & entertainment company.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Departments */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4 max-w-5xl space-y-14">
          {DEPARTMENTS.map((dept, di) => {
            const Icon = dept.icon;
            return (
              <motion.div
                key={dept.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: di * 0.05 }}
              >
                {/* Department header */}
                <div className={`flex items-center gap-4 mb-6 p-5 rounded-xl bg-gradient-to-r ${dept.color} border ${dept.border}`}>
                  <div className="w-10 h-10 rounded-lg bg-black/40 flex items-center justify-center shrink-0">
                    <Icon className={`w-5 h-5 ${dept.iconColor}`} />
                  </div>
                  <div>
                    <h2 className="text-white font-display text-xl tracking-wide">{dept.label}</h2>
                    <p className="text-white/40 text-sm">{dept.subtitle}</p>
                  </div>
                </div>

                {/* Roles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-2">
                  {dept.roles.map((role, ri) => (
                    <motion.div
                      key={role.title}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: di * 0.05 + ri * 0.04 }}
                      className="bg-zinc-950 border border-white/10 rounded-xl p-5"
                    >
                      <div className="flex items-start gap-2 mb-3">
                        <ChevronRight className={`w-4 h-4 ${dept.iconColor} shrink-0 mt-0.5`} />
                        <h3 className="text-white font-semibold text-sm leading-snug">{role.title}</h3>
                      </div>
                      <p className="text-primary/80 text-xs font-medium mb-2">
                        Role for Growth: <span className="text-white/60 font-normal">{role.growth}</span>
                      </p>
                      <p className="text-white/45 text-xs leading-relaxed">{role.impact}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-zinc-950 text-center border-t border-white/10">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white mb-4">WANT TO JOIN THE EMPIRE?</h2>
          <p className="text-white/50 mb-8 max-w-xl mx-auto">
            We're always looking for talented individuals who share our vision for Africa's digital future.
          </p>
          <a
            href="mailto:info@nazyempire.com?subject=Career%20Inquiry%20—%20Nazy%20Empire"
            className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-black font-bold rounded-lg hover:bg-primary/90 transition-colors"
          >
            Get in Touch
          </a>
        </div>
      </section>
    </div>
  );
}
