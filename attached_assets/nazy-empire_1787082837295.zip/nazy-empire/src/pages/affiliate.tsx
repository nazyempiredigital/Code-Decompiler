import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DollarSign, Users, Share2, TrendingUp, CheckCircle, ArrowRight,
  GraduationCap, Smartphone, Globe, Wallet, Star, Zap, Shield,
  BadgePercent, ChevronDown, ChevronUp, Music, Code, Server,
} from "lucide-react";
import { useState } from "react";

const HOW_IT_WORKS = [
  {
    step: "01",
    icon: Users,
    title: "Create a Free Account",
    description: "Sign up on Nazy Empire and instantly get your unique affiliate referral link. No fees, no monthly charges — it's completely free.",
    color: "from-amber-500 to-orange-500",
  },
  {
    step: "02",
    icon: Share2,
    title: "Share Your Link",
    description: "Post your referral link on WhatsApp, TikTok, Instagram, your blog, or anywhere your audience hangs out. Every click is tracked.",
    color: "from-blue-500 to-indigo-500",
  },
  {
    step: "03",
    icon: DollarSign,
    title: "Earn Commissions",
    description: "Every time someone buys through your link, you earn a commission. Payouts go straight to your bank account monthly.",
    color: "from-green-500 to-emerald-500",
  },
];

const COMMISSIONS = [
  { icon: Code, label: "Website & App Development", rate: "10%", color: "bg-amber-500/10 border-amber-500/30 text-amber-400", badge: "bg-amber-500" },
  { icon: Globe, label: "Domain Registration", rate: "8%", color: "bg-blue-500/10 border-blue-500/30 text-blue-400", badge: "bg-blue-500" },
  { icon: Server, label: "Web Hosting Plans", rate: "15%", color: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400", badge: "bg-emerald-500" },
  { icon: Music, label: "Music Distribution", rate: "12%", color: "bg-purple-500/10 border-purple-500/30 text-purple-400", badge: "bg-purple-500" },
];

const WHO_FOR = [
  {
    icon: GraduationCap,
    title: "Students",
    description: "Pay your tuition, buy data, or fund your side projects. Refer classmates and earn while you study.",
    color: "text-amber-400",
    bg: "bg-amber-500/10",
  },
  {
    icon: Smartphone,
    title: "Content Creators",
    description: "Monetise your TikTok, YouTube, or Instagram audience. Add your link to your bio and let it work 24/7.",
    color: "text-blue-400",
    bg: "bg-blue-500/10",
  },
  {
    icon: Globe,
    title: "Bloggers & Website Owners",
    description: "Drop your affiliate link in relevant blog posts and earn passive income every time a reader converts.",
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
  },
  {
    icon: Wallet,
    title: "Side Hustlers",
    description: "No product to create, no stock to hold. Just share a link and let Nazy Empire handle fulfilment and support.",
    color: "text-purple-400",
    bg: "bg-purple-500/10",
  },
];

const PERKS = [
  "30-day tracking cookie — get credit even if they buy weeks later",
  "Real-time dashboard to track clicks, conversions, and earnings",
  "Monthly bank payouts with no minimum threshold",
  "Promotional materials, banners, and copy provided free",
  "Dedicated affiliate support team",
  "Lifetime commissions on recurring services",
];

const FAQS = [
  {
    q: "How much can I actually earn?",
    a: "There's no cap. Affiliates promoting web hosting can earn up to 15% per sale. If you refer 10 hosting customers at ₦50,000/year, that's ₦75,000 in your pocket — and recurring every renewal.",
  },
  {
    q: "When and how do I get paid?",
    a: "Payouts are processed monthly directly to your Nigerian bank account. There is no minimum threshold — even your first ₦500 commission gets paid out.",
  },
  {
    q: "Do I need a website or large audience?",
    a: "Not at all. Many of our top affiliates share their links via WhatsApp groups, TikTok videos, and Twitter threads. If you know people who need a website, domain, or hosting, you're ready.",
  },
  {
    q: "Is the affiliate programme free to join?",
    a: "100% free. There are no sign-up fees, no monthly subscriptions, and no targets you must hit to stay active.",
  },
  {
    q: "How long does the tracking cookie last?",
    a: "30 days. If someone clicks your link today and buys anytime within 30 days, you earn the commission — even if they close the browser and come back later.",
  },
  {
    q: "Can I be an affiliate and also use Nazy Empire services?",
    a: "Absolutely. Many of our affiliates are also customers. You can build your own site with us and refer others at the same time.",
  },
];

const STATS = [
  { value: "₦0", label: "Cost to Join" },
  { value: "15%", label: "Top Commission Rate" },
  { value: "30 days", label: "Cookie Window" },
  { value: "Monthly", label: "Payout Frequency" },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className="border border-white/10 rounded-xl overflow-hidden cursor-pointer"
      onClick={() => setOpen(!open)}
    >
      <div className="flex items-center justify-between px-6 py-4 hover:bg-white/5 transition-colors">
        <span className="text-white font-medium text-sm">{q}</span>
        {open ? (
          <ChevronUp className="w-4 h-4 text-primary shrink-0 ml-4" />
        ) : (
          <ChevronDown className="w-4 h-4 text-white/40 shrink-0 ml-4" />
        )}
      </div>
      {open && (
        <div className="px-6 pb-5 text-white/60 text-sm leading-relaxed border-t border-white/10 pt-4">
          {a}
        </div>
      )}
    </div>
  );
}

export default function Affiliate() {
  return (
    <div className="overflow-hidden bg-zinc-950">

      {/* SEO meta context — targeting students & money-seekers */}
      {/* Page targets: "earn money online Nigeria", "affiliate marketing for students", "make money referring", "passive income Nigeria" */}

      {/* ── Hero ── */}
      <section className="relative min-h-[92vh] flex items-center justify-center text-center px-4 py-24">
        {/* Gradient orbs */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-amber-500/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-emerald-500/8 rounded-full blur-[100px]" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 rounded-full px-4 py-1.5 text-amber-400 text-sm font-medium mb-6">
            <BadgePercent className="w-4 h-4" />
            Affiliate Programme — Now Open
          </div>

          <h1 className="text-5xl md:text-7xl font-black text-white leading-tight mb-6">
            Earn Money Online<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500">
              Just By Sharing a Link
            </span>
          </h1>

          <p className="text-white/60 text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-4">
            Refer businesses, artists, and students to Nazy Empire — and earn up to <strong className="text-white">15% commission</strong> on every successful sale. No product, no stock, no experience needed.
          </p>
          <p className="text-white/40 text-sm mb-10">
            Perfect for Nigerian students, content creators, bloggers, and anyone looking for a real online income stream.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <Button size="lg" className="bg-primary text-black font-bold px-8 py-4 text-base hover:bg-primary/90">
                Start Earning Free <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <a href="#how-it-works">
              <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8 py-4 text-base">
                See How It Works
              </Button>
            </a>
          </div>

          {/* Stat strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 max-w-2xl mx-auto">
            {STATS.map((s) => (
              <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <p className="text-2xl font-black text-primary mb-0.5">{s.value}</p>
                <p className="text-white/50 text-xs">{s.label}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ── How It Works ── */}
      <section id="how-it-works" className="py-24 px-4 bg-black">
        <div className="container mx-auto max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Three Steps to Your First Payout
            </h2>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              No technical skills required. If you can send a WhatsApp message, you can earn with Nazy Empire.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {HOW_IT_WORKS.map((step, i) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative bg-white/5 border border-white/10 rounded-2xl p-8 text-center"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center mx-auto mb-5`}>
                  <step.icon className="w-7 h-7 text-white" />
                </div>
                <div className={`absolute top-6 right-6 text-4xl font-black text-transparent bg-clip-text bg-gradient-to-br ${step.color} opacity-30`}>
                  {step.step}
                </div>
                <h3 className="text-white font-bold text-lg mb-3">{step.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Commission Rates ── */}
      <section className="py-24 px-4 bg-zinc-950">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">What You Earn Per Sale</h2>
            <p className="text-white/50 text-lg">Competitive commissions across all our services.</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {COMMISSIONS.map((c, i) => (
              <motion.div
                key={c.label}
                initial={{ opacity: 0, scale: 0.97 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`flex items-center gap-4 border rounded-2xl p-5 ${c.color}`}
              >
                <div className={`w-12 h-12 rounded-xl ${c.badge} flex items-center justify-center shrink-0`}>
                  <c.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-white font-semibold text-sm">{c.label}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-white">{c.rate}</p>
                  <p className="text-white/40 text-xs">commission</p>
                </div>
              </motion.div>
            ))}
          </div>

          <p className="text-center text-white/30 text-sm mt-6">
            Rates apply to the net sale value. Commissions are credited 14 days after the order is fulfilled.
          </p>
        </div>
      </section>

      {/* ── Who It's For ── */}
      <section className="py-24 px-4 bg-black">
        <div className="container mx-auto max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">Built for You</h2>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              Whether you're a student trying to cover rent or a creator building passive income — this works for you.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {WHO_FOR.map((w, i) => (
              <motion.div
                key={w.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`${w.bg} border border-white/10 rounded-2xl p-6`}
              >
                <w.icon className={`w-8 h-8 ${w.color} mb-4`} />
                <h3 className="text-white font-bold mb-2">{w.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{w.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Perks ── */}
      <section className="py-24 px-4 bg-zinc-950">
        <div className="container mx-auto max-w-4xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-black text-white mb-4 leading-tight">
                Everything in Your Favour
              </h2>
              <p className="text-white/50 text-lg leading-relaxed mb-8">
                We make it as easy as possible to earn. Here's what's included when you join.
              </p>
              <Link href="/signup">
                <Button className="bg-primary text-black font-bold px-8">
                  Join Free <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </motion.div>

            <motion.ul
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-4"
            >
              {PERKS.map((perk) => (
                <li key={perk} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-white/70 text-sm leading-relaxed">{perk}</span>
                </li>
              ))}
            </motion.ul>
          </div>
        </div>
      </section>

      {/* ── Social Proof / Earnings Example ── */}
      <section className="py-24 px-4 bg-black">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">See What's Possible</h2>
            <p className="text-white/50 text-lg">Real numbers, real earnings potential.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                scenario: "Student Scenario",
                icon: GraduationCap,
                color: "border-amber-500/40 bg-amber-500/5",
                badge: "text-amber-400 bg-amber-500/10",
                desc: "You refer 5 classmates who each buy hosting for ₦30,000/year.",
                calc: "5 × ₦30,000 × 15%",
                earn: "₦22,500/year",
              },
              {
                scenario: "Content Creator",
                icon: Smartphone,
                color: "border-blue-500/40 bg-blue-500/5",
                badge: "text-blue-400 bg-blue-500/10",
                desc: "Your TikTok video drives 3 website development orders at ₦150,000 each.",
                calc: "3 × ₦150,000 × 10%",
                earn: "₦45,000",
              },
              {
                scenario: "Blogger / Hustler",
                icon: TrendingUp,
                color: "border-emerald-500/40 bg-emerald-500/5",
                badge: "text-emerald-400 bg-emerald-500/10",
                desc: "Your blog drives 10 hosting + 5 music distribution orders monthly.",
                calc: "Mixed commissions",
                earn: "₦80,000+/month",
              },
            ].map((s, i) => (
              <motion.div
                key={s.scenario}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className={`border rounded-2xl p-6 ${s.color}`}
              >
                <div className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold mb-4 ${s.badge}`}>
                  <s.icon className="w-3.5 h-3.5" />
                  {s.scenario}
                </div>
                <p className="text-white/60 text-sm mb-4 leading-relaxed">{s.desc}</p>
                <p className="text-white/40 text-xs mb-1">{s.calc} =</p>
                <p className="text-3xl font-black text-white">{s.earn}</p>
              </motion.div>
            ))}
          </div>

          <p className="text-center text-white/25 text-xs mt-6">Illustrative examples based on published commission rates. Actual earnings depend on your referrals and order values.</p>
        </div>
      </section>

      {/* ── Trust Signals ── */}
      <section className="py-16 px-4 bg-zinc-950 border-y border-white/10">
        <div className="container mx-auto max-w-3xl">
          <div className="flex flex-wrap justify-center gap-8 text-center">
            {[
              { icon: Shield, label: "Secure & Transparent", sub: "No hidden fees or clawbacks" },
              { icon: Zap, label: "Instant Tracking", sub: "Real-time clicks and conversions" },
              { icon: Star, label: "CAC Registered", sub: "Legitimate Nigerian business" },
            ].map((t) => (
              <div key={t.label} className="flex items-center gap-3">
                <t.icon className="w-6 h-6 text-primary shrink-0" />
                <div className="text-left">
                  <p className="text-white text-sm font-semibold">{t.label}</p>
                  <p className="text-white/40 text-xs">{t.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-24 px-4 bg-black">
        <div className="container mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl font-black text-white mb-4">Frequently Asked Questions</h2>
            <p className="text-white/50">Everything you need to know before joining.</p>
          </motion.div>

          <div className="space-y-3">
            {FAQS.map((faq) => (
              <FAQItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section className="py-28 px-4 bg-zinc-950 text-center relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-amber-500/10 rounded-full blur-[100px]" />
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-2xl mx-auto"
        >
          <h2 className="text-4xl md:text-6xl font-black text-white mb-4 leading-tight">
            Your Link Is Waiting.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500">
              Start Earning Today.
            </span>
          </h2>
          <p className="text-white/50 text-lg mb-10">
            Join hundreds of Nigerians already earning passive income with Nazy Empire. Sign up free in under 2 minutes.
          </p>
          <Link href="/signup">
            <Button size="lg" className="bg-primary text-black font-bold px-10 py-4 text-base hover:bg-primary/90">
              Create Free Affiliate Account <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <p className="text-white/25 text-sm mt-4">No credit card required · Free forever · Payouts to any Nigerian bank</p>
        </motion.div>
      </section>

    </div>
  );
}
