import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Music, ArrowRight, CheckCircle, DollarSign, BarChart2, Globe } from "lucide-react";

const PLATFORMS = [
  "Spotify", "Apple Music / iTunes", "YouTube Music", "Amazon Music", "Tidal Music",
  "Deezer", "SoundCloud", "Boomplay", "Anghami", "KKBOX",
  "JioSaavn", "Pandora", "iHeart Radio", "Snap", "NetEase Cloud Music",
  "QQ Music", "KuGou", "JOOX", "VK Music", "Yandex.Music", "ACR Cloud",
  "MediaNet", "Trebel Music", "Peloton", "Soundtrack Your Brand",
  "Kuaishou", "Audible Magic", "WeSing", "Zvuk", "FLO", "ROXI",
];


export default function MusicDistribution() {
  return (
    <div className="pt-16">
      <section className="bg-gradient-to-b from-zinc-950 to-black py-24 text-center">
        <div className="container mx-auto px-4">
          <Music className="w-16 h-16 text-primary mx-auto mb-6" />
          <h1 className="font-display text-6xl md:text-7xl text-white mb-4">MUSIC DISTRIBUTION</h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Get your music on Spotify, Apple Music, Boomplay, and 100+ platforms worldwide. Artists keep 85% of their royalties.
          </p>
        </div>
      </section>

      <section className="py-16 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-8">AVAILABLE PLATFORMS</h2>
          <div className="flex flex-wrap gap-3 justify-center max-w-3xl mx-auto">
            {PLATFORMS.map((p, i) => (
              <motion.span
                key={p}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="px-4 py-2 bg-card border border-border rounded-full text-white/70 text-sm hover:border-primary/40 hover:text-primary transition-colors"
              >
                {p}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl text-white text-center mb-4">PRICING</h2>
          <p className="text-white/50 text-center mb-12">Zero Upfront Costs. Start distributing your music today without spending a dime.</p>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative bg-card border border-primary shadow-xl shadow-primary/10 rounded-2xl p-8 max-w-xl mx-auto"
          >
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-black text-xs font-bold px-6 py-1 rounded-full tracking-widest">ALL-INCLUSIVE</span>
            <div className="text-center mb-8">
              <div className="font-display text-6xl text-primary mb-1">FREE</div>
              <p className="text-white/50 text-sm">No pocket expenses. We retain a 15% split of earned royalties to cover global distribution logistics, precise data reporting, and ongoing artist infrastructure.</p>
            </div>
            <ul className="space-y-3 mb-8">
              {[
                "Unlimited Releases (Singles, EPs, and Albums)",
                "Global Distribution to 100+ Digital Service Providers (DSPs)",
                "Keep 85% of Your Royalties",
                "Free ISRC & UPC Codes",
                "Advanced Analytics Dashboard",
                "Transparent Royalty Reporting",
                "Priority Artist Support",
                "No Hidden Fees, Ever",
              ].map((f) => (
                <li key={f} className="flex items-center gap-3 text-white/80 text-sm">
                  <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Link href="/signup" className="block">
              <Button className="w-full bg-primary text-black hover:bg-primary/90 font-bold text-base py-3">
                Get Started
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-zinc-950">
        <div className="container mx-auto px-4 max-w-4xl">
          <h2 className="font-display text-4xl text-white text-center mb-4">HOW IT WORKS</h2>
          <p className="text-white/50 text-center mb-12">From upload to payout in four simple steps</p>
          <div className="relative">
            <div className="hidden md:block absolute top-8 left-[calc(12.5%+1rem)] right-[calc(12.5%+1rem)] h-0.5 bg-primary/20" />
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                { step: "01", title: "Apply", description: "Submit your artist profile for review. Once verified, you will gain full access to unlimited distribution, analytics, and revenue collection." },
                { step: "02", title: "Submit Your Music", description: "Upload your tracks, artwork, and metadata via our contact form. We review within 24 hours." },
                { step: "03", title: "We Distribute", description: "Your music goes live on Spotify, Apple Music, Boomplay, TikTok, and 100+ platforms worldwide within days." },
                { step: "04", title: "Collect Royalties", description: "Streams and downloads generate royalties. You keep 85% — paid out monthly, tracked in your dashboard." },
              ].map((item, i) => (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.12 }}
                  className="flex flex-col items-center text-center"
                >
                  <div className="relative z-10 w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-4 shadow-lg shadow-primary/30">
                    <span className="font-display text-black text-xl">{item.step}</span>
                  </div>
                  <h3 className="text-white font-bold text-base mb-2">{item.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { icon: DollarSign, title: "85% Royalties", description: "You keep 85% of your earnings. We retain 15% to power platform maintenance, royalty reporting, and ongoing support — no hidden fees, just transparent revenue sharing." },
              { icon: Globe, title: "Global Reach", description: "Your music reaches 100+ platforms in 200+ countries worldwide." },
              { icon: BarChart2, title: "Analytics", description: "Track streams, downloads, and earnings in real-time." },
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="text-center p-6 bg-card border border-border rounded-xl"
                >
                  <Icon className="w-10 h-10 text-primary mx-auto mb-4" />
                  <h3 className="text-white font-semibold text-lg mb-2">{f.title}</h3>
                  <p className="text-white/50 text-sm">{f.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary/5 text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-5xl text-white mb-4">DISTRIBUTE YOUR MUSIC</h2>
          <p className="text-white/50 mb-8">Sign up and apply for an artist account to start your music distribution journey today.</p>
          <Link href="/signup">
            <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold">
              APPLY NOW <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
