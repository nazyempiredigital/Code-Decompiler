import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { BrandLockup } from "@/components/mic-logo";
import { Checkbox } from "@/components/ui/checkbox";

export default function Signup() {
  const { register, user } = useAuth();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [form, setForm] = useState({
    name: "", email: "", password: "", phone: "", company: "", country: "",
  });

  // Already logged in — redirect
  useEffect(() => {
    if (user) setLocation("/dashboard");
  }, [user]);

  function handleChange(key: string, val: string) {
    setForm((f) => ({ ...f, [key]: val }));
    setError("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!agreed) {
      setError("You must agree to the Terms of Service and Privacy Policy to continue");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await register({
        name: form.name,
        email: form.email,
        password: form.password,
        phone: form.phone || undefined,
        company: form.company || undefined,
        country: form.country || undefined,
      });
      setLocation("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12">
      {/* Logo */}
      <Link href="/" className="flex items-center gap-2 mb-10">
        <BrandLockup iconSize="w-7 h-8" textSize="text-2xl" />
      </Link>

      <div className="w-full max-w-md bg-card border border-border rounded-2xl p-8 shadow-xl">
        <h1 className="text-white text-2xl font-bold mb-1">Create an account</h1>
        <p className="text-white/50 text-sm mb-6">Get started with Nazy Empire today</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              placeholder="John Doe"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              required
              autoFocus
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => handleChange("email", e.target.value)}
              required
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={(e) => handleChange("password", e.target.value)}
              required
              minLength={6}
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="phone">Phone <span className="text-white/30">(optional)</span></Label>
            <Input
              id="phone"
              placeholder="+234 800 000 0000"
              value={form.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="company">Company <span className="text-white/30">(optional)</span></Label>
              <Input
                id="company"
                placeholder="Acme Inc."
                value={form.company}
                onChange={(e) => handleChange("company", e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                placeholder="Nigeria"
                value={form.country}
                onChange={(e) => handleChange("country", e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-start gap-2 pt-1">
            <Checkbox
              id="agree"
              checked={agreed}
              onCheckedChange={(v) => { setAgreed(v === true); setError(""); }}
              className="mt-0.5"
            />
            <Label htmlFor="agree" className="text-white/60 text-xs font-normal leading-relaxed cursor-pointer">
              I agree to the{" "}
              <Link href="/terms" target="_blank" className="text-primary hover:underline">Terms of Service</Link>
              {", "}
              <Link href="/privacy" target="_blank" className="text-primary hover:underline">Privacy Policy</Link>
              {", and "}
              <Link href="/terms-of-sale" target="_blank" className="text-primary hover:underline">Terms of Sale</Link>
            </Label>
          </div>

          {error && <p className="text-destructive text-sm">{error}</p>}

          <Button
            type="submit"
            disabled={loading || !agreed}
            className="w-full bg-primary text-black hover:bg-primary/90 font-semibold mt-2 disabled:opacity-50"
          >
            {loading ? "Creating account…" : "Create Account"}
          </Button>
        </form>

        <p className="text-center text-sm text-white/50 mt-6">
          Already have an account?{" "}
          <Link href="/login" className="text-primary hover:underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
