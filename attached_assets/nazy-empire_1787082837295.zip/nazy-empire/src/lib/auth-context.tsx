import { createContext, useState, useEffect, type ReactNode } from "react";
import { api, setToken, getToken, type User } from "./api";

export interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: Partial<User> & { password: string }) => Promise<void>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setTokenState] = useState<string | null>(getToken());
  const [isLoading, setIsLoading] = useState(!!getToken());

  useEffect(() => {
    if (!token) { setIsLoading(false); return; }
    api.auth.me()
      .then((u) => setUser(u))
      .catch(() => {
        setToken(null);
        setTokenState(null);
      })
      .finally(() => setIsLoading(false));
  }, [token]);

  async function login(email: string, password: string) {
    const { token: t, user: u } = await api.auth.login(email, password);
    setToken(t);
    setTokenState(t);
    setUser(u);
  }

  async function register(data: Partial<User> & { password: string }) {
    const { token: t, user: u } = await api.auth.register(data);
    setToken(t);
    setTokenState(t);
    setUser(u);
  }

  function logout() {
    setToken(null);
    setTokenState(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
