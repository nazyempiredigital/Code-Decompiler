export const API_BASE = "/api";

export interface User {
  id: number;
  name: string;
  email: string;
  role: "client" | "admin" | "verified_artist" | "moderator";
  phone?: string;
  company?: string;
  country?: string;
  isBlocked?: boolean;
  blockedReason?: string;
  createdAt?: string;
}

export interface Project {
  id: number;
  projectId: string;
  userId: number;
  websiteType: string;
  developmentFee: string;
  includesDomainHosting: boolean;
  domainName?: string;
  domainPrice: string;
  hostingPrice: string;
  servicePeriod: number;
  totalAmount: string;
  status: string;
  paystackRef?: string;
  paymentStatus: string;
  projectTitle?: string;
  description?: string;
  preferredCompletionDate?: string;
  files: string[];
  completedFiles: string[];
  internalNotes?: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  clientCompany?: string;
  clientCountry?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: number;
  projectId: number;
  userId: number;
  content: string;
  isAdmin: boolean;
  createdAt: string;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface Payment {
  id: number;
  projectId: number;
  paystackRef: string;
  amount: string;
  status: string;
  createdAt: string;
}

export interface HostingPlan {
  monthly: number;
  annual: number;
  features: string[];
}

export interface PublicSettings {
  businessName: string;
  adminEmail: string;
  currency: string;
  websitePrices: Record<string, number>;
  tldPrices: Record<string, number>;
  hostingPlans: Record<string, HostingPlan>;
  paystackPublicKey: string;
  contactPhone: string;
  contactAddress: string;
  facebookUrl: string;
  twitterUrl: string;
  instagramUrl: string;
}

export interface AdminStats {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  deliveredProjects: number;
  totalRevenue: string;
  totalClients: number;
  totalArtists: number;
  pendingArtistApplications: number;
  pendingReleases: number;
  openSupportTickets: number;
  recentOrders: Project[];
}

export interface RawSetting {
  id: number;
  key: string;
  value: string;
  updatedAt: string;
}

export interface ArtistApplication {
  id: number;
  userId: number;
  stageName: string;
  bio: string;
  genre: string;
  socialLinks?: string;
  status: "pending" | "approved" | "rejected";
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userEmail?: string;
}

export interface TrackInfo {
  title: string;
  version?: string;
  isrc?: string;
  explicitContent?: boolean;
  audioUrl?: string;
}

export interface Release {
  id: number;
  userId: number;
  releaseType: "single" | "ep" | "album";
  releaseTitle?: string;
  title: string;
  version?: string;
  genre: string;
  language: string;
  explicitContent: boolean;
  isrc?: string;
  upc?: string;
  releaseDate?: string;
  originalReleaseDate?: string;
  copyright?: string;
  copyrightRecordingYear?: string;
  publisher?: string;
  composer?: string;
  songwriter?: string;
  producer?: string;
  lyrics?: string;
  mainArtists?: string;
  featuredArtists?: string;
  streamingProfiles?: string;
  collaborators?: string;
  stores?: string[];
  territory?: string;
  selectedCountries?: string[];
  tracks?: TrackInfo[];
  audioUrl?: string;
  artworkUrl?: string;
  status: "draft" | "pending_review" | "changes_requested" | "approved" | "rejected" | "live";
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userEmail?: string;
}

export interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt?: string | null;
  content: string;
  featuredImage?: string | null;
  category?: string | null;
  tags?: string | null;
  author?: string | null;
  metaTitle?: string | null;
  metaDescription?: string | null;
  metaKeywords?: string | null;
  ogTitle?: string | null;
  ogDescription?: string | null;
  ogImage?: string | null;
  canonicalUrl?: string | null;
  isPublished: boolean;
  publishedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface EarningsUpload {
  id: number;
  uploadedBy: number;
  filename: string;
  totalRows: number;
  matchedRows: number;
  unmatchedRows: number;
  unmatched: Array<{ isrc: string; title?: string; earnings: number }> | null;
  createdAt: string;
}

export interface EarningsUploadResult {
  uploadId: number;
  totalRows: number;
  matchedRows: number;
  unmatchedRows: number;
  unmatched: Array<{ isrc: string; title?: string; earnings: number }>;
}

export interface ArtistEarnings {
  totalEarningsNgn: number;
  artistShareNgn: number;
  platformFeeNgn: number;
  totalRequestedNgn: number;
  availableBalanceNgn: number;
  byRelease: Array<{ releaseId: number; title: string; earningsNgn: number }>;
}

export interface PayoutMethod {
  id: number;
  userId: number;
  method: "paypal" | "bank_transfer";
  currency: "NGN" | "USD" | null;
  bankDetailType: "naira" | "ach" | "wire" | "swift" | null;
  details: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export interface AffiliateApplication {
  id: number;
  userId: number;
  reason: string;
  platform?: string | null;
  status: "pending" | "approved" | "rejected";
  adminNotes?: string | null;
  userName?: string | null;
  userEmail?: string | null;
  createdAt: string;
  updatedAt?: string | null;
}

export interface AffiliateCommission {
  id: number;
  affiliateUserId: number;
  projectId: number;
  projectRef: string;
  projectAmount: number;
  commission: number;
  status: "pending" | "paid";
  createdAt: string;
  affiliateName?: string | null;
  affiliateEmail?: string | null;
}

export interface AffiliateWithdrawal {
  id: number;
  userId: number;
  amount: number;
  notes?: string | null;
  status: "pending" | "approved" | "paid" | "rejected";
  adminNotes?: string | null;
  paidAt?: string | null;
  createdAt: string;
  updatedAt?: string | null;
  userName?: string | null;
  userEmail?: string | null;
}

export interface AffiliateEarnings {
  totalCommissions: number;
  alreadyRequested: number;
  availableBalance: number;
  canWithdraw: boolean;
  minWithdrawal: number;
  shortfall: number;
  commissionRate: number;
  referredProjects: number;
  commissions: AffiliateCommission[];
}

export interface ReferredAccount {
  userId: number;
  name: string;
  email: string;
  joinedAt: string;
  totalProjects: number;
}

export interface ArtistPaymentRequest {
  id: number;
  userId: number;
  amountNgn: number;
  status: "pending" | "paid";
  payoutMethodSnapshot: string | null;
  adminNotes: string | null;
  createdAt: string;
  paidAt: string | null;
  userName?: string;
  userEmail?: string;
}

export interface ArtistOrder {
  id: number;
  orderId: string;
  userId: number;
  serviceType: "mixing_mastering" | "cover_art" | "playlist_pitching";
  status: "pending_payment" | "paid" | "in_progress" | "confirmed" | "delivered";
  paymentStatus: string;
  paystackRef?: string | null;
  formData: Record<string, unknown>;
  artistFiles: string[];
  resultFiles: string[];
  firstDownloadAt?: string | null;
  adminNotes?: string | null;
  artistName: string;
  artistEmail: string;
  createdAt: string;
  updatedAt: string;
}

export interface ArtistOrderPayInit {
  reference: string;
  publicKey: string;
  amountKobo: number;
  amountNgn: number;
  email: string;
  authorizationUrl: string;
}

export interface SupportTicket {
  id: number;
  userId: number;
  subject: string;
  status: "open" | "in_progress" | "resolved" | "closed";
  priority: "low" | "normal" | "high" | "urgent";
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userEmail?: string;
}

export interface TicketMessage {
  id: number;
  ticketId: number;
  userId: number;
  message: string;
  isStaff: boolean;
  createdAt: string;
}

export interface CreateProjectData {
  websiteType: string;
  developmentFee: number;
  includesDomainHosting: boolean;
  domainName?: string;
  domainTld?: string;
  domainPeriod?: number;
  domainPrice: number;
  hostingPlan?: string;
  hostingPrice: number;
  hostingPeriod?: number;
  servicePeriod: number;
  totalAmount: number;
  projectTitle?: string;
  description?: string;
  preferredCompletionDate?: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  clientCompany?: string;
  clientCountry?: string;
  affiliateRef?: string;
}

export interface PaystackInitResponse {
  reference: string;
  publicKey: string;
  amountKobo: number;
  amountNgn: number;
  email: string;
  authorizationUrl: string;
}

export interface PortfolioProject {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  link?: string | null;
  sortOrder: number;
  isVisible: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ArtistAnalytics {
  totalStreams: number;
  byOutlet: { outlet: string; streams: number }[];
  byRelease: { releaseId: number; title: string; streams: number }[];
}

export interface AnalyticsUpload {
  id: number;
  uploadedBy: number;
  filename: string;
  totalRows: number;
  matchedRows: number;
  unmatchedRows: number;
  unmatched?: { isrc: string; title?: string; outlet?: string; streams?: number }[] | null;
  createdAt: string;
}

export interface AnalyticsUploadResult {
  uploadId: number;
  totalRows: number;
  matchedRows: number;
  unmatchedRows: number;
  unmatched: { isrc: string; title?: string; outlet?: string; streams?: number }[];
}

export interface DomainCheckResult {
  domain: string;
  isAvailable: boolean | null;
  available: boolean | null;   // kept for backward compat
  tld: string;
  price: number;
  error?: string;
}

let _token: string | null = null;
try {
  if (typeof window !== "undefined") {
    _token = localStorage.getItem("ne_auth_token");
  }
} catch {
  // localStorage may be blocked in sandboxed / cross-origin iframe contexts
}

export function setToken(token: string | null) {
  _token = token;
  if (typeof window !== "undefined") {
    try {
      if (token) localStorage.setItem("ne_auth_token", token);
      else localStorage.removeItem("ne_auth_token");
    } catch {
      // localStorage may be blocked in sandboxed / cross-origin iframe contexts
    }
  }
}

export function getToken() {
  return _token;
}

async function req<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (_token) headers["Authorization"] = `Bearer ${_token}`;
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    let err: { error?: string } = {};
    try { err = await res.json(); } catch {}
    throw new Error(err.error ?? `Request failed (${res.status})`);
  }
  return res.json() as Promise<T>;
}

async function upload<T = { url: string; filename: string }>(path: string, formData: FormData): Promise<T> {
  const headers: Record<string, string> = {};
  if (_token) headers["Authorization"] = `Bearer ${_token}`;
  const res = await fetch(`${API_BASE}${path}`, { method: "POST", headers, body: formData });
  if (!res.ok) throw new Error("Upload failed");
  return res.json();
}

export const api = {
  auth: {
    login: (email: string, password: string) =>
      req<{ token: string; user: User }>("POST", "/auth/login", { email, password }),
    register: (data: Partial<User> & { password: string }) =>
      req<{ token: string; user: User }>("POST", "/auth/register", data),
    me: () => req<User>("GET", "/auth/me"),
    updateProfile: (data: Partial<User>) =>
      req<{ success: boolean }>("PATCH", "/auth/profile", data),
    changePassword: (currentPassword: string, newPassword: string) =>
      req<{ success: boolean }>("POST", "/auth/change-password", { currentPassword, newPassword }),
  },

  projects: {
    create: (data: CreateProjectData) => req<Project>("POST", "/projects", data),
    list: () => req<Project[]>("GET", "/projects"),
    get: (id: number) => req<Project>("GET", `/projects/${id}`),
    messages: (id: number) => req<Message[]>("GET", `/projects/${id}/messages`),
    sendMessage: (id: number, content: string) =>
      req<Message>("POST", `/projects/${id}/messages`, { content }),
    uploadFile: (projectId: number, file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload(`/projects/${projectId}/files`, fd);
    },
    delete: (id: number) => req<{ success: boolean }>("DELETE", `/projects/${id}`),
  },

  payments: {
    initialize: (projectId: number) =>
      req<PaystackInitResponse>("POST", "/payments/initialize", { projectId }),
    verify: (reference: string) =>
      req<{ success: boolean; projectId: string }>("POST", "/payments/verify", { reference }),
  },

  settings: {
    getPublic: () => req<PublicSettings>("GET", "/settings"),
    getAll: () => req<RawSetting[]>("GET", "/settings/all"),
    update: (key: string, value: string) =>
      req<{ success: boolean }>("PATCH", "/settings", { key, value }),
    bulk: (settings: Record<string, string>) =>
      req<{ success: boolean }>("POST", "/settings/bulk", settings),
  },

  domains: {
    /** POST full user input — backend handles parsing, TLD validation, and API call */
    check: (domain: string) =>
      req<DomainCheckResult>("GET", `/check-domain?domain=${encodeURIComponent(domain)}`),
    tlds: () => req<Record<string, number>>("GET", "/domains/tlds"),
  },

  admin: {
    stats: () => req<AdminStats>("GET", "/admin/stats"),
    projects: (search?: string, status?: string) => {
      const qs = new URLSearchParams();
      if (search) qs.set("search", search);
      if (status) qs.set("status", status);
      const q = qs.toString();
      return req<Project[]>("GET", `/admin/projects${q ? `?${q}` : ""}`);
    },
    updateProject: (id: number, data: { status?: string; internalNotes?: string }) =>
      req<{ success: boolean }>("PATCH", `/admin/projects/${id}`, data),
    uploadCompletedFile: (projectId: number, file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload(`/admin/projects/${projectId}/completed-files`, fd);
    },
    clients: () => req<User[]>("GET", "/admin/clients"),
    users: () => req<User[]>("GET", "/admin/users"),
    updateUserRole: (id: number, role: string) =>
      req<User>("PATCH", `/admin/users/${id}/role`, { role }),
    blockUser: (id: number, reason?: string) =>
      req<User>("PATCH", `/admin/users/${id}/block`, { reason }),
    unblockUser: (id: number) =>
      req<User>("PATCH", `/admin/users/${id}/unblock`, {}),
    deleteUser: (id: number) =>
      req<{ success: boolean }>("DELETE", `/admin/users/${id}`),
    payments: () => req<Payment[]>("GET", "/admin/payments"),
  },

  notifications: {
    list: () => req<Notification[]>("GET", "/notifications"),
    markRead: (id: number) => req<{ success: boolean }>("PATCH", `/notifications/${id}/read`, {}),
    markAllRead: () => req<{ success: boolean }>("POST", "/notifications/read-all", {}),
  },

  artistApplications: {
    apply: (data: { stageName: string; bio: string; genre: string; socialLinks?: string }) =>
      req<ArtistApplication>("POST", "/artist-applications/apply", data),
    my: () => req<ArtistApplication | null>("GET", "/artist-applications/my"),
    list: () => req<ArtistApplication[]>("GET", "/artist-applications"),
    review: (id: number, status: "approved" | "rejected", adminNotes?: string) =>
      req<ArtistApplication>("PATCH", `/artist-applications/${id}/review`, { status, adminNotes }),
  },

  releases: {
    create: (data: Partial<Release>) => req<Release>("POST", "/releases", data),
    my: () => req<Release[]>("GET", "/releases/my"),
    list: () => req<Release[]>("GET", "/releases"),
    get: (id: number) => req<Release>("GET", `/releases/${id}`),
    update: (id: number, data: Partial<Release>) =>
      req<Release>("PATCH", `/releases/${id}`, data),
    delete: (id: number) =>
      req<{ success: boolean }>("DELETE", `/releases/${id}`),
    uploadFile: (file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload("/upload", fd);
    },
  },

  portfolio: {
    list: () => req<PortfolioProject[]>("GET", "/portfolio"),
    listAll: () => req<PortfolioProject[]>("GET", "/portfolio/all"),
    create: (data: Omit<PortfolioProject, "id" | "createdAt" | "updatedAt">) =>
      req<PortfolioProject>("POST", "/portfolio", data),
    update: (id: number, data: Partial<Omit<PortfolioProject, "id" | "createdAt" | "updatedAt">>) =>
      req<PortfolioProject>("PATCH", `/portfolio/${id}`, data),
    delete: (id: number) => req<{ success: boolean }>("DELETE", `/portfolio/${id}`),
    uploadImage: (file: File) => {
      const fd = new FormData();
      fd.append("image", file);
      return upload("/portfolio/upload-image", fd);
    },
  },

  earnings: {
    me: () => req<ArtistEarnings>("GET", "/earnings/me"),
    uploads: () => req<EarningsUpload[]>("GET", "/earnings/admin/uploads"),
    summary: () => req<{ totalEarningsNgn: number }>("GET", "/earnings/admin/summary"),
    upload: (file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload<EarningsUploadResult>("/earnings/admin/upload", fd);
    },
  },

  payoutMethod: {
    me: () => req<PayoutMethod | null>("GET", "/payout-methods/me"),
    save: (data: Record<string, unknown>) => req<PayoutMethod>("PUT", "/payout-methods/me", data),
    forUser: (userId: number) => req<PayoutMethod | null>("GET", `/payout-methods/admin/${userId}`),
  },

  paymentRequests: {
    my: () => req<ArtistPaymentRequest[]>("GET", "/payment-requests/me"),
    create: (amountNgn: number) => req<ArtistPaymentRequest>("POST", "/payment-requests/me", { amountNgn }),
    adminList: () => req<ArtistPaymentRequest[]>("GET", "/payment-requests/admin"),
    markPaid: (id: number) => req<ArtistPaymentRequest>("PATCH", `/payment-requests/admin/${id}`, { status: "paid" }),
  },

  analytics: {
    me: () => req<ArtistAnalytics>("GET", "/analytics/me"),
    uploads: () => req<AnalyticsUpload[]>("GET", "/analytics/admin/uploads"),
    summary: () => req<{ totalStreams: number; byOutlet: { outlet: string; streams: number }[] }>("GET", "/analytics/admin/summary"),
    upload: (file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload<AnalyticsUploadResult>("/analytics/admin/upload", fd);
    },
  },

  blog: {
    list: (limit?: number) =>
      req<BlogPost[]>("GET", `/blog${limit ? `?limit=${limit}` : ""}`),
    bySlug: (slug: string) => req<BlogPost>("GET", `/blog/slug/${slug}`),
    adminAll: () => req<BlogPost[]>("GET", "/blog/admin/all"),
    adminGet: (id: number) => req<BlogPost>("GET", `/blog/admin/${id}`),
    create: (data: Partial<BlogPost>) => req<BlogPost>("POST", "/blog", data),
    update: (id: number, data: Partial<BlogPost>) => req<BlogPost>("PATCH", `/blog/${id}`, data),
    delete: (id: number) => req<{ success: boolean }>("DELETE", `/blog/${id}`),
  },

  support: {
    create: (subject: string, message: string, priority?: string) =>
      req<SupportTicket>("POST", "/support/tickets", { subject, message, priority }),
    myTickets: () => req<SupportTicket[]>("GET", "/support/tickets/my"),
    allTickets: () => req<SupportTicket[]>("GET", "/support/tickets"),
    messages: (ticketId: number) =>
      req<TicketMessage[]>("GET", `/support/tickets/${ticketId}/messages`),
    sendMessage: (ticketId: number, message: string) =>
      req<TicketMessage>("POST", `/support/tickets/${ticketId}/messages`, { message }),
    updateStatus: (id: number, status: string) =>
      req<SupportTicket>("PATCH", `/support/tickets/${id}`, { status }),
  },

  affiliates: {
    myApplication: () =>
      req<{ application: AffiliateApplication | null; isAffiliate: boolean; referralCode: string | null }>("GET", "/affiliates/my-application"),
    apply: (reason: string, platform?: string) =>
      req<AffiliateApplication>("POST", "/affiliates/apply", { reason, platform }),
    referralLink: () =>
      req<{ referralCode: string | null; referralLink: string | null }>("GET", "/affiliates/referral-link"),
    earnings: () =>
      req<AffiliateEarnings>("GET", "/affiliates/earnings"),
    withdrawals: () =>
      req<AffiliateWithdrawal[]>("GET", "/affiliates/withdrawals"),
    withdraw: (amount: number, notes?: string) =>
      req<AffiliateWithdrawal>("POST", "/affiliates/withdraw", { amount, notes }),
    referredAccounts: () =>
      req<ReferredAccount[]>("GET", "/affiliates/referred-accounts"),
    adminApplications: () =>
      req<AffiliateApplication[]>("GET", "/affiliates/admin/applications"),
    adminReviewApplication: (id: number, status: "approved" | "rejected", adminNotes?: string) =>
      req<AffiliateApplication>("PATCH", `/affiliates/admin/applications/${id}`, { status, adminNotes }),
    adminWithdrawals: () =>
      req<AffiliateWithdrawal[]>("GET", "/affiliates/admin/withdrawals"),
    adminUpdateWithdrawal: (id: number, status: "approved" | "paid" | "rejected", adminNotes?: string) =>
      req<AffiliateWithdrawal>("PATCH", `/affiliates/admin/withdrawals/${id}`, { status, adminNotes }),
    adminCommissions: () =>
      req<AffiliateCommission[]>("GET", "/affiliates/admin/commissions"),
  },

  artistOrders: {
    create: (serviceType: "mixing_mastering" | "cover_art" | "playlist_pitching", formData: Record<string, unknown>) =>
      req<ArtistOrder>("POST", "/artist-orders", { serviceType, formData }),
    list: () => req<ArtistOrder[]>("GET", "/artist-orders"),
    get: (id: number) => req<ArtistOrder>("GET", `/artist-orders/${id}`),
    uploadFile: (orderId: number, file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload<{ url: string; filename: string; originalName: string }>(`/artist-orders/${orderId}/files`, fd);
    },
    initPayment: (orderId: number) =>
      req<ArtistOrderPayInit>("POST", `/artist-orders/${orderId}/pay-init`, {}),
    verifyPayment: (orderId: number, reference: string) =>
      req<{ success: boolean; orderId: string }>("POST", `/artist-orders/${orderId}/pay-verify`, { reference }),
    acknowledgeDownload: (orderId: number) =>
      req<{ resultFiles: string[] }>("POST", `/artist-orders/${orderId}/download-result`, {}),

    // Admin
    adminList: (status?: string, serviceType?: string) => {
      const qs = new URLSearchParams();
      if (status) qs.set("status", status);
      if (serviceType) qs.set("serviceType", serviceType);
      const q = qs.toString();
      return req<ArtistOrder[]>("GET", `/artist-orders/admin/all${q ? `?${q}` : ""}`);
    },
    adminGet: (id: number) => req<ArtistOrder>("GET", `/artist-orders/admin/${id}`),
    adminUpdateStatus: (id: number, data: { status?: string; adminNotes?: string }) =>
      req<ArtistOrder>("PATCH", `/artist-orders/admin/${id}/status`, data),
    adminConfirmPayment: (id: number) =>
      req<ArtistOrder>("PATCH", `/artist-orders/admin/${id}/confirm-payment`, {}),
    adminUploadResult: (orderId: number, file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      return upload<{ url: string; filename: string; originalName: string; order: ArtistOrder }>(`/artist-orders/admin/${orderId}/upload-result`, fd);
    },
  },
};
