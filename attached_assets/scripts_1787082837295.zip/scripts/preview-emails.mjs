import nodemailer from "nodemailer";

const APP_URL = "https://nazyempire.com";
const TO = "hestrovamusic@gmail.com";

const account = await nodemailer.createTestAccount();
const transport = nodemailer.createTransport({
  host: "smtp.ethereal.email",
  port: 587,
  auth: { user: account.user, pass: account.pass },
});

const FROM = '"Nazy Empire" <hello@nazyempire.com>';

const emails = [
  {
    label: "1. Welcome",
    subject: "Welcome to Nazy Empire!",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Welcome to Nazy Empire, Hestro!</h2>
        <p>We're glad you're here. Your account is ready — you can now explore our services, submit projects, and manage your work all in one place.</p>
        <p><a href="${APP_URL}/dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">Go to Dashboard</a></p>
        <p>If you have any questions, our support team is always available.</p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "2. Artist Application Received",
    subject: "Artist Application Received — Nazy Empire",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Artist Application Received</h2>
        <p>Hi Hestro,</p>
        <p>We've received your artist application for <strong>Hestro Vamusic</strong>. Our team will review it and get back to you as soon as possible.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Application</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "3. Artist Application — Approved",
    subject: "Artist Application Approved — Nazy Empire",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Artist Application Approved</h2>
        <p>Hi Hestro,</p>
        <p>Great news! Your artist application for <strong>Hestro Vamusic</strong> has been <strong>approved</strong>. You can now upload and distribute your music on Nazy Empire.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">Start Distributing</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "4. Artist Application — Rejected",
    subject: "Artist Application Update — Nazy Empire",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Artist Application Not Approved</h2>
        <p>Hi Hestro,</p>
        <p>Thank you for applying. Unfortunately, your artist application for <strong>Hestro Vamusic</strong> was not approved at this time.</p>
        <p><strong>Notes from our team:</strong> Please resubmit with a more detailed bio and at least one social media link.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Dashboard</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "5. Release Submitted",
    subject: "Release Submitted — Midnight Drive",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Release Submitted for Review</h2>
        <p>Hi Hestro,</p>
        <p>Your release <strong>Midnight Drive</strong> has been submitted and is now under review. We'll notify you once it's been processed.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Release</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "6. Release — Approved",
    subject: "Release Approved — Midnight Drive",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Release Approved — Midnight Drive</h2>
        <p>Hi Hestro,</p>
        <p>Your release <strong>Midnight Drive</strong> has been <strong>approved</strong> and is being prepared for distribution.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Release</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "7. Release — Distributed (Live)",
    subject: "Release Live — Midnight Drive",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Release Live — Midnight Drive</h2>
        <p>Hi Hestro,</p>
        <p>Your release <strong>Midnight Drive</strong> is now <strong>live</strong> and distributed across streaming platforms.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Release</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "8. Release — Changes Requested",
    subject: "Changes Requested — Midnight Drive",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Changes Requested — Midnight Drive</h2>
        <p>Hi Hestro,</p>
        <p>Our team has requested changes to your release <strong>Midnight Drive</strong>. Please review the notes and resubmit.</p>
        <p><strong>Notes:</strong> The artwork does not meet the minimum resolution requirement of 3000×3000px. Please upload a higher quality cover image.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Release</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "9. Release — Rejected",
    subject: "Release Update — Midnight Drive",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Release Update — Midnight Drive</h2>
        <p>Hi Hestro,</p>
        <p>Your release <strong>Midnight Drive</strong> could not be approved at this time.</p>
        <p><strong>Notes:</strong> This release contains content that conflicts with our distribution policy. Please review our guidelines and contact support if you have questions.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Release</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "10. Support Ticket Received",
    subject: "Support Ticket Received — #42",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Support Ticket Received — #42</h2>
        <p>Hi Hestro,</p>
        <p>We've received your support request: <strong>My release is stuck in review</strong>.</p>
        <p>Our team will get back to you as soon as possible. You can track the conversation in your dashboard.</p>
        <p><a href="${APP_URL}/dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Ticket</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "11. Support Ticket Reply",
    subject: "Reply on Ticket #42 — My release is stuck in review",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">New Reply on Ticket #42</h2>
        <p>Hi Hestro,</p>
        <p>Our support team has replied to your ticket: <strong>My release is stuck in review</strong>.</p>
        <blockquote style="border-left:3px solid #d4a017;padding-left:12px;color:#555;margin:16px 0">Hi Hestro, thanks for reaching out! We've reviewed your release and it should be approved within 24 hours. Apologies for the delay.</blockquote>
        <p><a href="${APP_URL}/dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Conversation</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "12. Withdrawal Request Received",
    subject: "Withdrawal Request Received — Nazy Empire",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Withdrawal Request Received</h2>
        <p>Hi Hestro,</p>
        <p>Your withdrawal request of <strong>₦50,000.00</strong> has been received and is being processed. We'll notify you once the payment has been sent.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Request</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
  {
    label: "13. Withdrawal Paid",
    subject: "Payment Sent — ₦50,000.00",
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <h2 style="color:#d4a017">Payment Sent!</h2>
        <p>Hi Hestro,</p>
        <p>Your withdrawal of <strong>₦50,000.00</strong> has been processed and the payment has been sent to your account on file.</p>
        <p>Please allow 1–3 business days for the funds to reflect depending on your bank.</p>
        <p><a href="${APP_URL}/artist-dashboard" style="background:#d4a017;color:#000;padding:10px 20px;text-decoration:none;border-radius:4px;font-weight:bold">View Earnings</a></p>
        <p>Best regards,<br/>Nazy Empire Team</p>
      </div>`,
  },
];

const results = [];
for (const email of emails) {
  const info = await transport.sendMail({ from: FROM, to: TO, subject: email.subject, html: email.html });
  const url = nodemailer.getTestMessageUrl(info);
  results.push({ label: email.label, url });
  process.stdout.write(`✓ ${email.label}\n  ${url}\n\n`);
}
