import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });

async function main() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS blog_posts (
        id              SERIAL PRIMARY KEY,
        title           VARCHAR(500) NOT NULL,
        slug            VARCHAR(500) NOT NULL UNIQUE,
        excerpt         TEXT,
        content         TEXT NOT NULL,
        featured_image  TEXT,
        category        VARCHAR(100) DEFAULT 'General',
        tags            TEXT,
        author          VARCHAR(255) DEFAULT 'Nazy Empire',
        meta_title      VARCHAR(500),
        meta_description TEXT,
        meta_keywords   TEXT,
        og_title        VARCHAR(500),
        og_description  TEXT,
        og_image        TEXT,
        canonical_url   TEXT,
        is_published    BOOLEAN NOT NULL DEFAULT FALSE,
        published_at    TIMESTAMP,
        created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    console.log("✅ blog_posts table created (or already exists)");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
