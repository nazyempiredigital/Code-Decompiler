#!/bin/bash
# setup.sh — run this once after cloning or after a clean environment restore.
# It installs dependencies, builds TypeScript project references, and pushes the
# DB schema.  The post-merge.sh script reuses these same steps automatically on
# every task-agent merge.
set -e

echo "==> Installing workspace dependencies..."
pnpm install --frozen-lockfile

echo "==> Building TypeScript project references (lib/db, lib/api-zod)..."
node_modules/.bin/tsc --build lib/db lib/api-zod

echo "==> Pushing DB schema (drizzle-kit push)..."
pnpm --filter @workspace/db run push

echo ""
echo "Setup complete. Start the app with the Replit run button, or manually:"
echo "  API server : PORT=8080 pnpm --filter @workspace/api-server run dev"
echo "  Frontend   : PORT=18129 BASE_PATH=/ pnpm --filter @workspace/nazy-empire run dev"
