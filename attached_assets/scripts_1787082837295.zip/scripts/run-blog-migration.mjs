import pg from "/home/runner/workspace/node_modules/.pnpm/pg@8.22.0/node_modules/pg/lib/index.js";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const client = await pool.connect();

const __dirname = dirname(fileURLToPath(import.meta.url));
const posts = JSON.parse(readFileSync(join(__dirname, "blog-seed-data.json"), "utf8"));

try {
  // Create table
  await client.query(`
    CREATE TABLE IF NOT EXISTS blog_posts (
      id               SERIAL PRIMARY KEY,
      title            VARCHAR(500) NOT NULL,
      slug             VARCHAR(500) NOT NULL UNIQUE,
      excerpt          TEXT,
      content          TEXT NOT NULL,
      featured_image   TEXT,
      category         VARCHAR(100) DEFAULT 'General',
      tags             TEXT,
      author           VARCHAR(255) DEFAULT 'Nazy Empire',
      meta_title       VARCHAR(500),
      meta_description TEXT,
      meta_keywords    TEXT,
      og_title         VARCHAR(500),
      og_description   TEXT,
      og_image         TEXT,
      canonical_url    TEXT,
      is_published     BOOLEAN NOT NULL DEFAULT FALSE,
      published_at     TIMESTAMP,
      created_at       TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at       TIMESTAMP NOT NULL DEFAULT NOW()
    );
  `);
  console.log("blog_posts table ready");

  // Seed posts
  for (const post of posts) {
    await client.query(
      `INSERT INTO blog_posts
        (title, slug, excerpt, content, category, tags, author,
         meta_title, meta_description, meta_keywords,
         og_title, og_description,
         canonical_url, is_published, published_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,NOW())
       ON CONFLICT (slug) DO NOTHING`,
      [
        post.title,
        post.slug,
        post.excerpt,
        post.content,
        post.category,
        post.tags,
        post.author,
        post.metaTitle,
        post.metaDescription,
        post.metaKeywords,
        post.metaTitle,
        post.metaDescription,
        post.canonicalUrl,
        true,
      ]
    );
    console.log("Seeded: " + post.title.slice(0, 60) + "...");
  }

  console.log("Done.");
} finally {
  client.release();
  await pool.end();
}
