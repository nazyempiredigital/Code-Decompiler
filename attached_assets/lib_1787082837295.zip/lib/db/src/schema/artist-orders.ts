import {
  pgTable, serial, integer, varchar, text, timestamp, json, pgEnum,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const artistOrderServiceTypeEnum = pgEnum("artist_order_service_type", [
  "mixing_mastering",
  "cover_art",
  "playlist_pitching",
]);

export const artistOrderStatusEnum = pgEnum("artist_order_status", [
  "pending_payment",
  "paid",
  "in_progress",
  "confirmed",
  "delivered",
]);

export const artistOrdersTable = pgTable("artist_orders", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 50 }).unique().notNull(),
  userId: integer("user_id").references(() => usersTable.id).notNull(),
  serviceType: artistOrderServiceTypeEnum("service_type").notNull(),
  status: artistOrderStatusEnum("status").default("pending_payment").notNull(),
  paymentStatus: varchar("payment_status", { length: 50 }).default("unpaid").notNull(),
  paystackRef: varchar("paystack_ref", { length: 255 }),
  formData: json("form_data").$type<Record<string, unknown>>().default({}).notNull(),
  artistFiles: json("artist_files").$type<string[]>().default([]).notNull(),
  resultFiles: json("result_files").$type<string[]>().default([]).notNull(),
  firstDownloadAt: timestamp("first_download_at"),
  adminNotes: text("admin_notes"),
  artistName: varchar("artist_name", { length: 255 }).notNull(),
  artistEmail: varchar("artist_email", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type ArtistOrder = typeof artistOrdersTable.$inferSelect;
