import {
  pgTable, serial, text, varchar, integer, numeric,
  timestamp, boolean, json, pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const projectStatusEnum = pgEnum("project_status", [
  "pending_review",
  "awaiting_payment",
  "in_progress",
  "waiting_for_client_feedback",
  "completed",
  "delivered",
]);

export const projectsTable = pgTable("projects", {
  id: serial("id").primaryKey(),
  projectId: varchar("project_id", { length: 50 }).unique().notNull(),
  userId: integer("user_id").references(() => usersTable.id).notNull(),
  websiteType: varchar("website_type", { length: 100 }).notNull(),
  developmentFee: numeric("development_fee", { precision: 10, scale: 2 }).notNull(),
  includesDomainHosting: boolean("includes_domain_hosting").default(false).notNull(),
  domainName: varchar("domain_name", { length: 255 }),
  domainPrice: numeric("domain_price", { precision: 10, scale: 2 }).default("0").notNull(),
  hostingPrice: numeric("hosting_price", { precision: 10, scale: 2 }).default("0").notNull(),
  servicePeriod: integer("service_period").default(1).notNull(),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  status: projectStatusEnum("status").default("pending_review").notNull(),
  paystackRef: varchar("paystack_ref", { length: 255 }),
  paymentStatus: varchar("payment_status", { length: 50 }).default("unpaid").notNull(),
  projectTitle: varchar("project_title", { length: 255 }),
  description: text("description"),
  preferredCompletionDate: varchar("preferred_completion_date", { length: 100 }),
  files: json("files").$type<string[]>().default([]).notNull(),
  completedFiles: json("completed_files").$type<string[]>().default([]).notNull(),
  internalNotes: text("internal_notes"),
  affiliateRef: varchar("affiliate_ref", { length: 20 }),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  clientEmail: varchar("client_email", { length: 255 }).notNull(),
  clientPhone: varchar("client_phone", { length: 50 }),
  clientCompany: varchar("client_company", { length: 255 }),
  clientCountry: varchar("client_country", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;
