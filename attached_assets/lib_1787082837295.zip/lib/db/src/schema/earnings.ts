import { pgTable, serial, integer, varchar, real, timestamp, json } from "drizzle-orm/pg-core";

export const earningsUploadsTable = pgTable("earnings_uploads", {
  id: serial("id").primaryKey(),
  uploadedBy: integer("uploaded_by").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  totalRows: integer("total_rows").default(0).notNull(),
  matchedRows: integer("matched_rows").default(0).notNull(),
  unmatchedRows: integer("unmatched_rows").default(0).notNull(),
  unmatched: json("unmatched").$type<Array<{ isrc: string; title?: string; earnings: number }>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const earningsEntriesTable = pgTable("earnings_entries", {
  id: serial("id").primaryKey(),
  uploadId: integer("upload_id").notNull(),
  userId: integer("user_id").notNull(),
  releaseId: integer("release_id").notNull(),
  isrc: varchar("isrc", { length: 50 }).notNull(),
  trackTitle: varchar("track_title", { length: 255 }),
  earningsNgn: real("earnings_ngn").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type EarningsUpload = typeof earningsUploadsTable.$inferSelect;
export type EarningsEntry = typeof earningsEntriesTable.$inferSelect;
