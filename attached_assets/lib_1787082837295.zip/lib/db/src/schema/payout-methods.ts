import { pgTable, serial, integer, varchar, json, timestamp } from "drizzle-orm/pg-core";

// One active payout method per artist. Artists can only have a single method
// at a time, but can replace it (change payment method) whenever they like —
// so this is an upsert-on-userId table, not a history log.
export const payoutMethodsTable = pgTable("payout_methods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  method: varchar("method", { length: 20 }).notNull(), // "paypal" | "bank_transfer"
  currency: varchar("currency", { length: 10 }), // "NGN" | "USD" — bank_transfer only
  bankDetailType: varchar("bank_detail_type", { length: 10 }), // "naira" | "ach" | "wire" | "swift" — bank_transfer only
  // Flexible bag for the fields specific to each method/type, e.g.:
  //  paypal        -> { email }
  //  naira         -> { bankName, accountNumber, accountName }
  //  ach            -> { receiverType, routingNumber, accountNumber, accountType, accountName }
  //  wire           -> { receiverType, routingNumber, accountNumber, accountName }
  //  swift          -> { receiverType, swiftBicCode, accountNumber, accountName }
  details: json("details").$type<Record<string, string>>().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type PayoutMethod = typeof payoutMethodsTable.$inferSelect;
