import {
  pgTable, serial, integer, text, varchar, numeric, boolean,
  timestamp, pgEnum,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { projectsTable } from "./projects";

export const affiliateApplicationStatusEnum = pgEnum("affiliate_application_status", [
  "pending", "approved", "rejected",
]);

export const affiliateWithdrawalStatusEnum = pgEnum("affiliate_withdrawal_status", [
  "pending", "approved", "paid", "rejected",
]);

export const affiliateCommissionStatusEnum = pgEnum("affiliate_commission_status", [
  "pending", "paid",
]);

// ── Affiliate Applications ─────────────────────────────────────────────────
export const affiliateApplicationsTable = pgTable("affiliate_applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id, { onDelete: "cascade" }).notNull(),
  reason: text("reason").notNull(),
  platform: varchar("platform", { length: 255 }),
  status: affiliateApplicationStatusEnum("status").default("pending").notNull(),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ── Affiliate Commissions ──────────────────────────────────────────────────
export const affiliateCommissionsTable = pgTable("affiliate_commissions", {
  id: serial("id").primaryKey(),
  affiliateUserId: integer("affiliate_user_id").references(() => usersTable.id, { onDelete: "cascade" }).notNull(),
  projectId: integer("project_id").references(() => projectsTable.id, { onDelete: "cascade" }).notNull(),
  projectRef: varchar("project_ref", { length: 50 }).notNull(),
  projectAmount: numeric("project_amount", { precision: 15, scale: 2 }).notNull(),
  commission: numeric("commission", { precision: 15, scale: 2 }).notNull(),
  status: affiliateCommissionStatusEnum("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Affiliate Withdrawal Requests ─────────────────────────────────────────
export const affiliateWithdrawalsTable = pgTable("affiliate_withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => usersTable.id, { onDelete: "cascade" }).notNull(),
  amount: numeric("amount", { precision: 15, scale: 2 }).notNull(),
  notes: text("notes"),
  status: affiliateWithdrawalStatusEnum("status").default("pending").notNull(),
  adminNotes: text("admin_notes"),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type AffiliateApplication = typeof affiliateApplicationsTable.$inferSelect;
export type AffiliateCommission  = typeof affiliateCommissionsTable.$inferSelect;
export type AffiliateWithdrawal  = typeof affiliateWithdrawalsTable.$inferSelect;
