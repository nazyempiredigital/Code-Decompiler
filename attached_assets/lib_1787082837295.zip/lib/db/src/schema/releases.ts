import { pgTable, serial, integer, text, varchar, boolean, timestamp, json, pgEnum } from "drizzle-orm/pg-core";

export const releaseStatusEnum = pgEnum("release_status", [
  "draft", "pending_review", "changes_requested", "approved", "rejected", "live",
]);

export const releasesTable = pgTable("releases", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),

  // Release-level info
  releaseType: varchar("release_type", { length: 20 }).default("single").notNull(), // single | ep | album
  releaseTitle: varchar("release_title", { length: 255 }),

  // Primary track info (for singles; EP/Album use `tracks`)
  title: varchar("title", { length: 255 }).notNull(),
  version: varchar("version", { length: 100 }),
  genre: varchar("genre", { length: 100 }).notNull(),
  language: varchar("language", { length: 100 }).notNull(),
  explicitContent: boolean("explicit_content").default(false).notNull(),
  isrc: varchar("isrc", { length: 50 }),
  upc: varchar("upc", { length: 50 }),
  releaseDate: varchar("release_date", { length: 50 }),
  originalReleaseDate: varchar("original_release_date", { length: 50 }),

  // Credits & Rights
  copyright: varchar("copyright", { length: 255 }),
  copyrightRecordingYear: varchar("copyright_recording_year", { length: 255 }),
  publisher: varchar("publisher", { length: 255 }),
  composer: varchar("composer", { length: 255 }),
  songwriter: varchar("songwriter", { length: 255 }),
  producer: varchar("producer", { length: 255 }),
  lyrics: text("lyrics"),
  mainArtists: text("main_artists"),
  featuredArtists: text("featured_artists"),

  // Distribution
  stores: json("stores").$type<string[]>(),
  territory: varchar("territory", { length: 50 }).default("worldwide").notNull(),
  selectedCountries: json("selected_countries").$type<string[]>(),

  // For EPs/Albums: JSON array of track objects
  tracks: json("tracks").$type<Array<{
    title: string;
    version?: string;
    isrc?: string;
    explicitContent?: boolean;
  }>>(),

  // Files
  audioUrl: text("audio_url"),
  artworkUrl: text("artwork_url"),

  // Misc legacy
  streamingProfiles: text("streaming_profiles"),
  collaborators: text("collaborators"),

  // Status
  status: releaseStatusEnum("status").default("draft").notNull(),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Release = typeof releasesTable.$inferSelect;
