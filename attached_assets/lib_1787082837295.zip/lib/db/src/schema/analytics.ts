import { pgTable, serial, integer, text, varchar, timestamp, json } from "drizzle-orm/pg-core";

// One row per CSV file the admin uploads
export const analyticsUploadsTable = pgTable("analytics_uploads", {
  id: serial("id").primaryKey(),
  uploadedBy: integer("uploaded_by").notNull(), // admin user id
  filename: varchar("filename", { length: 255 }).notNull(),
  totalRows: integer("total_rows").default(0).notNull(),
  matchedRows: integer("matched_rows").default(0).notNull(),
  unmatchedRows: integer("unmatched_rows").default(0).notNull(),
  unmatched: json("unmatched").$type<Array<{ isrc: string; title?: string; outlet?: string; streams?: number }>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// One row per (isrc, outlet) line item matched to an artist/release within an upload
export const analyticsEntriesTable = pgTable("analytics_entries", {
  id: serial("id").primaryKey(),
  uploadId: integer("upload_id").notNull(),
  userId: integer("user_id").notNull(), // matched artist
  releaseId: integer("release_id").notNull(),
  isrc: varchar("isrc", { length: 50 }).notNull(),
  trackTitle: varchar("track_title", { length: 255 }),
  outlet: varchar("outlet", { length: 100 }).notNull(),
  streams: integer("streams").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AnalyticsUpload = typeof analyticsUploadsTable.$inferSelect;
export type AnalyticsEntry = typeof analyticsEntriesTable.$inferSelect;
