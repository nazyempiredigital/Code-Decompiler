import { pgTable, serial, text, varchar, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", ["client", "admin", "verified_artist", "moderator"]);

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  phone: varchar("phone", { length: 50 }),
  company: varchar("company", { length: 255 }),
  country: varchar("country", { length: 100 }),
  role: userRoleEnum("role").default("client").notNull(),
  emailVerified: boolean("email_verified").default(false).notNull(),
  isBlocked: boolean("is_blocked").default(false).notNull(),
  blockedReason: text("blocked_reason"),
  referralCode: varchar("referral_code", { length: 20 }).unique(),
  isAffiliate: boolean("is_affiliate").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
