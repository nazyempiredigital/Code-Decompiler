import { pgTable, serial, varchar, numeric, text, integer, timestamp, json } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";
import { usersTable } from "./users";

export const paymentsTable = pgTable("payments", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projectsTable.id).notNull(),
  userId: integer("user_id").references(() => usersTable.id).notNull(),
  paystackRef: varchar("paystack_ref", { length: 255 }).unique().notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("NGN").notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(),
  paystackData: json("paystack_data"),
  meta: text("meta"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Payment = typeof paymentsTable.$inferSelect;
