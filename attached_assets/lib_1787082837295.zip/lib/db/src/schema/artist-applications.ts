import { pgTable, serial, integer, text, varchar, timestamp, pgEnum } from "drizzle-orm/pg-core";

export const artistApplicationStatusEnum = pgEnum("artist_application_status", [
  "pending", "approved", "rejected",
]);

export const artistApplicationsTable = pgTable("artist_applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  stageName: varchar("stage_name", { length: 255 }).notNull(),
  bio: text("bio").notNull(),
  genre: varchar("genre", { length: 100 }).notNull(),
  socialLinks: text("social_links"),
  status: artistApplicationStatusEnum("status").default("pending").notNull(),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type ArtistApplication = typeof artistApplicationsTable.$inferSelect;
