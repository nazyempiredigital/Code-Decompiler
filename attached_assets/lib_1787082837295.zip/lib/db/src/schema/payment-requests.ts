import { pgTable, serial, integer, varchar, real, text, timestamp } from "drizzle-orm/pg-core";

// A withdrawal request from an artist. The requested amount is deducted from
// the artist's available balance the moment the request is created —
// regardless of status — since the money is already earmarked for payout.
export const paymentRequestsTable = pgTable("payment_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amountNgn: real("amount_ngn").notNull(),
  status: varchar("status", { length: 20 }).default("pending").notNull(), // "pending" | "paid"
  // Snapshot of the payout method used for this request, so later changes to
  // the artist's on-file method don't retroactively alter historical requests.
  payoutMethodSnapshot: text("payout_method_snapshot"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  paidAt: timestamp("paid_at"),
});

export type PaymentRequest = typeof paymentRequestsTable.$inferSelect;
