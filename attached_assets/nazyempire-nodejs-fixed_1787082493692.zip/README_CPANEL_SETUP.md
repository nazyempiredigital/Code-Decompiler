# Nazy Empire Digital — corrected Node.js + MySQL deployment

This package preserves the supplied public UI and rebuilds the API against MySQL/MariaDB. It does not contain your previous `.env` or any credentials.

## Fresh deployment

1. **Rotate any credentials that were present in either previous upload** before going live: database password, SMTP password, Paystack keys, admin password, and JWT secret.
2. Back up the existing site and database. Upload this ZIP into the intended application root and extract it. Do not extract it inside another nested folder.
3. Copy `.env.example` to `.env` and fill in the new credentials. Use the exact cPanel database name, username, host, and password. Keep `.env` outside public downloads if your host supports a separate app root.
4. Import `database_schema.sql` in phpMyAdmin into the selected MySQL/MariaDB database. The fixed schema includes the missing comma from the previous package and uses an unverified default for new accounts.
5. In **Setup Node.js App**, use:
   - Node.js: 18.x, 20.x, or 22.x
   - Application mode: Production
   - Application root: the folder containing `server.js`
   - Startup file: `server.js`
   - Application URL: your domain
6. Run **NPM Install**, then restart the application. Do not use the old `app.js`, `server-bundle.cjs`, or `server-dist` files from either previous archive.
7. Check `https://your-domain.example/api/healthz`; it must return `{"status":"ok"}`. Then test registration, verification, login, project creation, upload, payment initialization, and the Paystack webhook.

## Environment names

The server accepts `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, and `DB_PASSWORD`. It also accepts the older `SQL_*` names for compatibility, but use the `DB_*` names in this package.

SMTP and Paystack are optional for the public site, but the corresponding features require their values. `JWT_SECRET` must be changed from the example value.

## Notes

- The server no longer falls back to a fake empty Express app when the bundle fails; startup errors are visible and actionable.
- Database queries are real MySQL queries. There is no in-memory fallback, so a missing or incorrect database configuration fails closed instead of silently losing data.
- Upload files are stored in `uploads/`; ensure the Node process can write to that directory.
