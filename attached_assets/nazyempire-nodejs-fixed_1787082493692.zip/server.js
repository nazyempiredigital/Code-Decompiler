/**
 * Nazy Empire Digital — cPanel / DirectAdmin Passenger entry point.
 * Requires Node.js 18+ and the dependencies in package.json.
 */
const path = require("path");
const fs = require("fs");
const http = require("http");
require("dotenv").config({ path: path.join(__dirname, ".env") });
// Passenger may start the process from a parent directory. Keep uploads and
// static assets anchored to this deployment folder.
process.chdir(__dirname);

const imported = require("./server-bundle.cjs");
const app = imported.default || imported;
const publicDir = path.join(__dirname, "public");

if (fs.existsSync(publicDir)) {
  const express = require("express");
  app.use(express.static(publicDir, { maxAge: "1d" }));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api") || req.path === "/sitemap.xml") return next();
    res.sendFile(path.join(publicDir, "index.html"));
  });
}

const server = http.createServer(app);
const portValue = process.env.PORT || 3000;
if (typeof portValue === "string" && Number.isNaN(Number(portValue))) {
  server.listen(portValue, () => console.log("Nazy Empire listening on Passenger socket", portValue));
} else {
  server.listen(Number(portValue), "0.0.0.0", () => console.log("Nazy Empire listening on port", portValue));
}

module.exports = server;
