-- Nazy Empire Digital Database Schema for MySQL / MariaDB
-- Target Database: nazyempi_nazyempiredigital

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` TEXT NOT NULL,
  `phone` VARCHAR(50) NULL,
  `company` VARCHAR(255) NULL,
  `country` VARCHAR(100) NULL,
  `role` ENUM('client', 'admin', 'verified_artist', 'moderator') NOT NULL DEFAULT 'client',
  `email_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `is_blocked` TINYINT(1) NOT NULL DEFAULT 0,
  `blocked_reason` TEXT NULL,
  `referral_code` VARCHAR(20) NULL UNIQUE,
  `is_affiliate` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings Table
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(255) NOT NULL UNIQUE,
  `value` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Web Development & App Projects Table
CREATE TABLE IF NOT EXISTS `projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` VARCHAR(50) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `website_type` VARCHAR(100) NOT NULL,
  `development_fee` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `includes_domain_hosting` TINYINT(1) NOT NULL DEFAULT 0,
  `domain_name` VARCHAR(255) NULL,
  `domain_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `hosting_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `service_period` INT NOT NULL DEFAULT 1,
  `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `status` ENUM('pending_review', 'awaiting_payment', 'in_progress', 'waiting_for_client_feedback', 'completed', 'delivered') NOT NULL DEFAULT 'pending_review',
  `paystack_ref` VARCHAR(255) NULL,
  `payment_status` VARCHAR(50) NOT NULL DEFAULT 'unpaid',
  `project_title` VARCHAR(255) NULL,
  `description` LONGTEXT NULL,
  `preferred_completion_date` VARCHAR(100) NULL,
  `files` JSON NULL,
  `completed_files` JSON NULL,
  `selected_addons` LONGTEXT NULL,
  `addon_fee` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `internal_notes` LONGTEXT NULL,
  `affiliate_ref` VARCHAR(20) NULL,
  `client_name` VARCHAR(255) NOT NULL,
  `client_email` VARCHAR(255) NOT NULL,
  `client_phone` VARCHAR(50) NULL,
  `client_company` VARCHAR(255) NULL,
  `client_country` VARCHAR(100) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_projects_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `paystack_ref` VARCHAR(255) NOT NULL UNIQUE,
  `amount` DECIMAL(15,2) NOT NULL,
  `currency` VARCHAR(10) NOT NULL DEFAULT 'NGN',
  `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
  `paystack_data` JSON NULL,
  `meta` LONGTEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_payments_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payments_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages Table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_messages_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` LONGTEXT NOT NULL,
  `read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Artist Applications Table
CREATE TABLE IF NOT EXISTS `artist_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `stage_name` VARCHAR(255) NOT NULL,
  `bio` LONGTEXT NOT NULL,
  `genre` VARCHAR(100) NOT NULL,
  `social_links` LONGTEXT NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `admin_notes` LONGTEXT NULL,
  `legal_name` VARCHAR(255) NULL,
  `signatory_phone` VARCHAR(50) NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` LONGTEXT NULL,
  `document_hash` VARCHAR(64) NULL,
  `signed_at` DATETIME NULL,
  `e_sign_consent` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Music Releases Table
CREATE TABLE IF NOT EXISTS `releases` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `release_type` VARCHAR(20) NOT NULL DEFAULT 'single',
  `release_title` VARCHAR(255) NULL,
  `title` VARCHAR(255) NOT NULL,
  `version` VARCHAR(100) NULL,
  `genre` VARCHAR(100) NOT NULL,
  `language` VARCHAR(100) NOT NULL,
  `explicit_content` TINYINT(1) NOT NULL DEFAULT 0,
  `isrc` VARCHAR(50) NULL,
  `upc` VARCHAR(50) NULL,
  `release_date` VARCHAR(50) NULL,
  `original_release_date` VARCHAR(50) NULL,
  `copyright` VARCHAR(255) NULL,
  `copyright_recording_year` VARCHAR(255) NULL,
  `publisher` VARCHAR(255) NULL,
  `composer` VARCHAR(255) NULL,
  `songwriter` VARCHAR(255) NULL,
  `producer` VARCHAR(255) NULL,
  `lyrics` LONGTEXT NULL,
  `main_artists` LONGTEXT NULL,
  `featured_artists` LONGTEXT NULL,
  `stores` JSON NULL,
  `territory` VARCHAR(50) NOT NULL DEFAULT 'worldwide',
  `selected_countries` JSON NULL,
  `tracks` JSON NULL,
  `audio_url` LONGTEXT NULL,
  `artwork_url` LONGTEXT NULL,
  `smart_link_url` LONGTEXT NULL,
  `spotify_pre_save_url` LONGTEXT NULL,
  `apple_music_pre_save_url` LONGTEXT NULL,
  `audiomack_pre_save_url` LONGTEXT NULL,
  `boomplay_pre_save_url` LONGTEXT NULL,
  `youtube_music_pre_save_url` LONGTEXT NULL,
  `deezer_pre_save_url` LONGTEXT NULL,
  `upstream_distributor` VARCHAR(100) NULL,
  `upc_upstream` VARCHAR(100) NULL,
  `streaming_profiles` LONGTEXT NULL,
  `collaborators` LONGTEXT NULL,
  `status` ENUM('draft', 'pending_review', 'changes_requested', 'approved', 'rejected', 'live') NOT NULL DEFAULT 'draft',
  `admin_notes` LONGTEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Support Tickets Table
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `status` ENUM('open', 'in_progress', 'resolved', 'closed') NOT NULL DEFAULT 'open',
  `priority` ENUM('low', 'normal', 'high', 'urgent') NOT NULL DEFAULT 'normal',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ticket Messages Table
CREATE TABLE IF NOT EXISTS `ticket_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ticket_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `message` LONGTEXT NOT NULL,
  `is_staff` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_ticket_messages_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Portfolio Projects Table
CREATE TABLE IF NOT EXISTS `portfolio_projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` LONGTEXT NOT NULL,
  `image_url` LONGTEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'Web Development',
  `link` VARCHAR(500) NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_visible` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Analytics Uploads & Entries
CREATE TABLE IF NOT EXISTS `analytics_uploads` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `uploaded_by` INT NOT NULL,
  `filename` VARCHAR(255) NOT NULL,
  `total_rows` INT NOT NULL DEFAULT 0,
  `matched_rows` INT NOT NULL DEFAULT 0,
  `unmatched_rows` INT NOT NULL DEFAULT 0,
  `unmatched` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `analytics_entries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `upload_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `release_id` INT NOT NULL,
  `isrc` VARCHAR(50) NOT NULL,
  `track_title` VARCHAR(255) NULL,
  `outlet` VARCHAR(100) NOT NULL,
  `streams` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Earnings Uploads & Entries
CREATE TABLE IF NOT EXISTS `earnings_uploads` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `uploaded_by` INT NOT NULL,
  `filename` VARCHAR(255) NOT NULL,
  `total_rows` INT NOT NULL DEFAULT 0,
  `matched_rows` INT NOT NULL DEFAULT 0,
  `unmatched_rows` INT NOT NULL DEFAULT 0,
  `unmatched` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `earnings_entries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `upload_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `release_id` INT NOT NULL,
  `isrc` VARCHAR(50) NOT NULL,
  `track_title` VARCHAR(255) NULL,
  `earnings_ngn` FLOAT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payout Methods Table
CREATE TABLE IF NOT EXISTS `payout_methods` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL UNIQUE,
  `method` VARCHAR(20) NOT NULL,
  `currency` VARCHAR(10) NULL,
  `bank_detail_type` VARCHAR(10) NULL,
  `details` JSON NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payment Requests (Artist Royalties Withdrawals) Table
CREATE TABLE IF NOT EXISTS `payment_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `amount_ngn` FLOAT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `payout_method_snapshot` LONGTEXT NULL,
  `admin_notes` LONGTEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog Posts Table
CREATE TABLE IF NOT EXISTS `blog_posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(500) NOT NULL,
  `slug` VARCHAR(500) NOT NULL UNIQUE,
  `excerpt` LONGTEXT NULL,
  `content` LONGTEXT NOT NULL,
  `featured_image` LONGTEXT NULL,
  `category` VARCHAR(100) DEFAULT 'General',
  `tags` LONGTEXT NULL,
  `author` VARCHAR(255) DEFAULT 'Nazy Empire',
  `meta_title` VARCHAR(500) NULL,
  `meta_description` LONGTEXT NULL,
  `meta_keywords` LONGTEXT NULL,
  `og_title` VARCHAR(500) NULL,
  `og_description` LONGTEXT NULL,
  `og_image` LONGTEXT NULL,
  `canonical_url` LONGTEXT NULL,
  `is_published` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Artist Orders Table
CREATE TABLE IF NOT EXISTS `artist_orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(50) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `service_type` ENUM('mixing_mastering', 'cover_art', 'playlist_pitching', 'lyrics_video', 'youtube_visualizer', 'official_youtube_music_video', 'official_professional_music_video') NOT NULL,
  `status` ENUM('pending_payment', 'paid', 'in_progress', 'confirmed', 'delivered') NOT NULL DEFAULT 'pending_payment',
  `payment_status` VARCHAR(50) NOT NULL DEFAULT 'unpaid',
  `paystack_ref` VARCHAR(255) NULL,
  `form_data` JSON NULL,
  `artist_files` JSON NULL,
  `result_files` JSON NULL,
  `first_download_at` DATETIME NULL,
  `admin_notes` LONGTEXT NULL,
  `artist_name` VARCHAR(255) NOT NULL,
  `artist_email` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_artist_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Affiliate Tables
CREATE TABLE IF NOT EXISTS `affiliate_applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `reason` LONGTEXT NOT NULL,
  `platform` VARCHAR(255) NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `admin_notes` LONGTEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_affiliate_app_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `affiliate_commissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `affiliate_user_id` INT NOT NULL,
  `project_id` INT NOT NULL,
  `project_ref` VARCHAR(50) NOT NULL,
  `project_amount` DECIMAL(15,2) NOT NULL,
  `commission` DECIMAL(15,2) NOT NULL,
  `status` ENUM('pending', 'paid') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_affiliate_comm_user` FOREIGN KEY (`affiliate_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_affiliate_comm_proj` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `affiliate_withdrawals` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `amount` DECIMAL(15,2) NOT NULL,
  `notes` LONGTEXT NULL,
  `status` ENUM('pending', 'approved', 'paid', 'rejected') NOT NULL DEFAULT 'pending',
  `admin_notes` LONGTEXT NULL,
  `paid_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_affiliate_w_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Auth & Verification Tokens
CREATE TABLE IF NOT EXISTS `email_verification_tokens` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `token` VARCHAR(64) NOT NULL UNIQUE,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_evt_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `signature_otps` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `otp` VARCHAR(6) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_sotp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `token` VARCHAR(128) NOT NULL UNIQUE,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_prt_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
